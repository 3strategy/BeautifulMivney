package com.example.hex;

import android.content.Context;
import android.content.res.AssetFileDescriptor;

import org.json.JSONArray;
import org.json.JSONObject;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.Tensor;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.List;

/** Loads and evaluates TFLite models that satisfy the strict {@code hex-value-v1} contract. */
public final class TfliteValueModel implements ValueModel {
    /** Default bundled TFLite model asset. */
    public static final String MODEL_ASSET = "hex_value_v1.tflite";
    /** Default bundled metadata asset. */
    public static final String METADATA_ASSET = "model_info.json";
    private static final String CONTRACT = "hex-value-v1";
    private static final int ENCODED_FLOATS = HexGame.CELL_COUNT * 3;

    private final Interpreter interpreter;
    private final boolean untrainedMock;
    private final boolean dynamicBatch;
    private boolean closed;

    /**
     * Loads the default bundled value model and metadata.
     *
     * @param context Android context used to open application assets
     * @throws Exception if the assets cannot be read or fail contract validation
     */
    public TfliteValueModel(Context context) throws Exception {
        this(context, MODEL_ASSET, METADATA_ASSET);
    }

    /**
     * Loads a value model and metadata from the specified bundled assets.
     *
     * @param context Android context used to open application assets
     * @param modelAsset relative asset path ending in {@code .tflite}
     * @param metadataAsset relative asset path ending in {@code .json}
     * @throws Exception if an asset cannot be read or the model, metadata, or hash is invalid
     */
    public TfliteValueModel(Context context, String modelAsset, String metadataAsset)
            throws Exception {
        modelAsset = checkedAssetPath(modelAsset, ".tflite");
        metadataAsset = checkedAssetPath(metadataAsset, ".json");
        JSONObject metadata = readMetadata(context, metadataAsset);
        validateMetadata(metadata);
        validateHashWhenPresent(context, modelAsset, metadata);
        untrainedMock = metadata.getBoolean("untrained_mock");

        Interpreter.Options options = new Interpreter.Options();
        options.setNumThreads(2);
        interpreter = new Interpreter(mapAsset(context, modelAsset), options);
        try {
            validateTensors(interpreter);
            dynamicBatch = interpreter.getInputTensor(0).shapeSignature()[0] == -1;
        } catch (Exception exception) {
            interpreter.close();
            throw exception;
        }
    }

    @Override
    public synchronized float[] evaluate(List<float[]> encodedStates) {
        if (closed) {
            throw new IllegalStateException("Model is closed");
        }
        if (encodedStates.isEmpty()) {
            return new float[0];
        }
        validateStates(encodedStates);
        if (dynamicBatch) {
            return evaluateDynamicBatch(encodedStates);
        }

        float[] values = new float[encodedStates.size()];
        for (int stateIndex = 0; stateIndex < encodedStates.size(); stateIndex++) {
            float[] state = encodedStates.get(stateIndex);
            ByteBuffer input = ByteBuffer.allocateDirect(ENCODED_FLOATS * Float.BYTES)
                    .order(ByteOrder.nativeOrder());
            for (float value : state) {
                input.putFloat(value);
            }
            input.rewind();

            ByteBuffer output = ByteBuffer.allocateDirect(Float.BYTES)
                    .order(ByteOrder.nativeOrder());
            interpreter.run(input, output);
            output.rewind();
            values[stateIndex] = checkedValue(output.getFloat());
        }
        return values;
    }

    private float[] evaluateDynamicBatch(List<float[]> encodedStates) {
        int batchSize = encodedStates.size();
        interpreter.resizeInput(0, new int[]{batchSize, 7, 7, 3}, true);
        interpreter.allocateTensors();

        ByteBuffer input = ByteBuffer
                .allocateDirect(batchSize * ENCODED_FLOATS * Float.BYTES)
                .order(ByteOrder.nativeOrder());
        for (float[] state : encodedStates) {
            for (float value : state) {
                input.putFloat(value);
            }
        }
        input.rewind();
        ByteBuffer output = ByteBuffer.allocateDirect(batchSize * Float.BYTES)
                .order(ByteOrder.nativeOrder());
        interpreter.run(input, output);
        output.rewind();

        float[] values = new float[batchSize];
        for (int i = 0; i < batchSize; i++) {
            values[i] = checkedValue(output.getFloat());
        }
        return values;
    }

    private static void validateStates(List<float[]> states) {
        for (float[] state : states) {
            if (state == null || state.length != ENCODED_FLOATS) {
                throw new IllegalArgumentException("Each model state must contain 147 floats");
            }
        }
    }

    private static float checkedValue(float value) {
        if (!Float.isFinite(value) || value < -1.05f || value > 1.05f) {
            throw new IllegalStateException("Model value is outside the [-1, 1] contract");
        }
        return Math.max(-1.0f, Math.min(1.0f, value));
    }

    @Override
    public boolean isUntrainedMock() {
        return untrainedMock;
    }

    @Override
    public synchronized void close() {
        if (!closed) {
            closed = true;
            interpreter.close();
        }
    }

    private static void validateTensors(Interpreter interpreter) {
        if (interpreter.getInputTensorCount() != 1 || interpreter.getOutputTensorCount() != 1) {
            throw new IllegalArgumentException("Model must have one input and one output tensor");
        }
        Tensor input = interpreter.getInputTensor(0);
        Tensor output = interpreter.getOutputTensor(0);
        if (input.dataType() != DataType.FLOAT32
                || !Arrays.equals(input.shape(), new int[]{1, 7, 7, 3})) {
            throw new IllegalArgumentException("Model input must be FLOAT32 [1,7,7,3]");
        }
        if (output.dataType() != DataType.FLOAT32
                || !Arrays.equals(output.shape(), new int[]{1, 1})) {
            throw new IllegalArgumentException("Model output must be FLOAT32 [1,1]");
        }
    }

    private static JSONObject readMetadata(Context context, String metadataAsset) throws Exception {
        StringBuilder jsonText = new StringBuilder();
        try (InputStreamReader reader = new InputStreamReader(
                context.getAssets().open(metadataAsset), StandardCharsets.UTF_8)) {
            char[] buffer = new char[1024];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                jsonText.append(buffer, 0, count);
            }
        }
        return new JSONObject(jsonText.toString());
    }

    private static void validateHashWhenPresent(Context context, String modelAsset,
                                                JSONObject metadata)
            throws Exception {
        if (!metadata.has("sha256")) {
            return;
        }
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream stream = context.getAssets().open(modelAsset)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = stream.read(buffer)) != -1) {
                digest.update(buffer, 0, count);
            }
        }
        StringBuilder actual = new StringBuilder(64);
        for (byte value : digest.digest()) {
            actual.append(String.format("%02x", value & 0xff));
        }
        if (!actual.toString().equalsIgnoreCase(metadata.getString("sha256"))) {
            throw new IllegalArgumentException("Model bytes do not match metadata SHA-256");
        }
    }

    private static void validateMetadata(JSONObject metadata) throws Exception {
        if (!CONTRACT.equals(metadata.getString("contract"))
                || metadata.getInt("board_size") != HexGame.SIZE
                || !"float32".equals(metadata.getString("input_dtype"))
                || !"float32".equals(metadata.getString("output_dtype"))
                || !metadata.has("untrained_mock")) {
            throw new IllegalArgumentException("Model metadata does not match hex-value-v1");
        }
        assertShape(metadata.getJSONArray("input_shape"), new int[]{1, 7, 7, 3});
        assertShape(metadata.getJSONArray("output_shape"), new int[]{1, 1});
    }

    private static void assertShape(JSONArray actual, int[] expected) throws Exception {
        if (actual.length() != expected.length) {
            throw new IllegalArgumentException("Model metadata tensor shape is invalid");
        }
        for (int i = 0; i < expected.length; i++) {
            if (actual.getInt(i) != expected[i]) {
                throw new IllegalArgumentException("Model metadata tensor shape is invalid");
            }
        }
    }

    private static String checkedAssetPath(String path, String suffix) {
        if (path == null || path.isEmpty() || path.startsWith("/")
                || path.contains("\\") || !path.endsWith(suffix)) {
            throw new IllegalArgumentException("Invalid model asset path");
        }
        for (String segment : path.split("/")) {
            if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment)) {
                throw new IllegalArgumentException("Invalid model asset path");
            }
        }
        return path;
    }

    private static MappedByteBuffer mapAsset(Context context, String name) throws IOException {
        try (AssetFileDescriptor descriptor = context.getAssets().openFd(name);
             FileInputStream input = new FileInputStream(descriptor.getFileDescriptor());
             FileChannel channel = input.getChannel()) {
            return channel.map(FileChannel.MapMode.READ_ONLY,
                    descriptor.getStartOffset(), descriptor.getDeclaredLength());
        }
    }
}
