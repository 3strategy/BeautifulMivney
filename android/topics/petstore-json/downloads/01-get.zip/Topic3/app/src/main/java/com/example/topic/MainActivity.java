package com.example.topic;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.topic.databinding.ActivityMainBinding;

import java.util.Collections;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final String BASE_URL = "https://petstore3.swagger.io/api/v3";
    private ActivityMainBinding binding;
    private RequestQueue queue;
    private int httpStatus;

    /** Creates the screen and connects its network action. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        queue = Volley.newRequestQueue(getApplicationContext());
        binding.getPets.setOnClickListener(v -> getPets());
    }

    /** Fetches JSON as text; no Java Pet objects are created here. */
    private void getPets() {
        queue.cancelAll(this);
        binding.status.setText("Sending GET...");
        StringRequest request = new StringRequest(Request.Method.GET,
                BASE_URL + "/pet/findByStatus?status=available", text -> {
            binding.responseJson.setText(text);
            binding.status.setText("GET HTTP " + httpStatus);
        }, this::showError) {
            @Override
            public Map<String, String> getHeaders() {
                return Collections.singletonMap("Accept", "application/json");
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                httpStatus = response.statusCode;
                return Response.success(
                        new String(response.data, java.nio.charset.StandardCharsets.UTF_8), null);
            }
        };
        request.setShouldCache(false);
        request.setTag(this);
        queue.add(request);
    }

    /** Keeps HTTP error bodies visible and distinguishes them from connection failures. */
    private void showError(VolleyError error) {
        NetworkResponse response = error.networkResponse;
        binding.status.setText(response == null
                ? "Network failure: " + error.getClass().getSimpleName()
                : "HTTP " + response.statusCode);
        binding.responseJson.setText(response == null ? "No HTTP response body received."
                : new String(response.data, java.nio.charset.StandardCharsets.UTF_8));
    }

    /** Cancels delivery to this screen when it is no longer visible. */
    @Override
    protected void onStop() {
        queue.cancelAll(this);
        binding.status.setText("Ready — requests cancelled when leaving the screen");
        super.onStop();
    }
}
