package com.example.connect4;

import android.view.View;
import android.widget.Button;
import com.example.connect4.databinding.ActivityMainBinding;
import com.example.connect4.multiplayer.*;
import java.util.ArrayList;
import java.util.List;

/** Screen subscriptions are Activity-owned; pending writes stay in the retained repository. */
final class OnlineController {
    interface Host { void changed(); void received(RoomSnapshot room); }
    private final ActivityMainBinding ui;
    private final GameSession session;
    private final Host host;
    private final GoogleSignIn googleSignIn;
    private boolean pickingGoogle;
    private final List<MultiplayerRepository.Subscription> subscriptions = new ArrayList<>();
    private MultiplayerRepository.Subscription screen = MultiplayerRepository.Subscription.EMPTY;
    private boolean active;
    private long screenGeneration;
    private final Runnable refreshCallback = this::refreshScreen;

    OnlineController(android.app.Activity activity, ActivityMainBinding ui, GameSession session, Host host) {
        this.ui = ui;
        this.session = session;
        this.host = host;
        googleSignIn = new GoogleSignIn(activity);
        ui.googleSignIn.setOnClickListener(v -> authenticateGoogle());
        ui.signIn.setOnClickListener(v -> authenticate(false));
        ui.signUp.setOnClickListener(v -> authenticate(true));
        ui.signOut.setOnClickListener(v -> {
            session.onlineGeneration++;
            session.roomId = null;
            session.room = null;
            if (session.repository != null) session.repository.signOut();
            googleSignIn.clearSession();
            refreshScreen();
        });
        ui.createRoom.setOnClickListener(v -> createRoom());
        ui.backToLobby.setOnClickListener(v -> lobby());
        ui.retryOnline.setOnClickListener(v -> { stop(); start(); });
    }

    void start() {
        if (active || session.mode != GameSession.MODE_ONLINE) return;
        active = true;
        session.refreshOnline = refreshCallback;
        session.connected = false;
        session.reconciled = false;
        try {
            if (session.repository == null) session.repository = new MultiplayerRepository();
            MultiplayerRepository repo = session.repository;
            subscriptions.add(repo.subscribeAuth(uid -> {
                if (!active) return;
                if (!java.util.Objects.equals(uid, session.onlineUid)) {
                    session.onlineGeneration++;
                    if (session.onlineUid != null) { session.roomId = null; session.room = null; }
                    session.onlineUid = uid;
                }
                refreshScreen();
            }));
            subscriptions.add(repo.subscribeConnection(new MultiplayerRepository.ConnectionListener() {
                @Override public void onConnectionChanged(boolean connected) {
                    if (!active) return;
                    session.connected = connected;
                    session.reconciled = false;
                    if (connected) refreshScreen();
                    else host.changed();
                }
                @Override public void onError(RepositoryError error) { showError(error); }
            }));
            refreshScreen();
        } catch (IllegalStateException exception) {
            session.onlineMessage = "Firebase setup unavailable. Add the registered Connect4 google-services.json and rebuild.";
            host.changed();
        }
    }

    void stop() {
        active = false;
        if (session.refreshOnline == refreshCallback) session.refreshOnline = null;
        screenGeneration++;
        screen.close();
        screen = MultiplayerRepository.Subscription.EMPTY;
        for (MultiplayerRepository.Subscription subscription : subscriptions) subscription.close();
        subscriptions.clear();
        session.reconciled = false;
    }

    void modeChanged() {
        session.onlineGeneration++;
        if (session.mode == GameSession.MODE_ONLINE) start(); else stop();
    }

    private void refreshScreen() {
        screen.close();
        screen = MultiplayerRepository.Subscription.EMPTY;
        long token = ++screenGeneration;
        session.reconciled = false;
        if (!active || session.repository == null || session.repository.currentUid() == null) { host.changed(); return; }
        if (session.roomId == null) {
            screen = session.repository.subscribeLobby(new MultiplayerRepository.LobbyListener() {
                @Override public void onRooms(List<RoomSummary> rooms) {
                    if (!active || token != screenGeneration) return;
                    session.reconciled = session.connected;
                    ui.rooms.removeAllViews();
                    for (RoomSummary room : rooms) {
                        Button button = new Button(ui.getRoot().getContext());
                        button.setText(room.getName() + " · " + (room.isValid() ? room.getStatus().toString().toLowerCase(java.util.Locale.ROOT) : "invalid room"));
                        button.setEnabled(room.isValid() && session.connected && !pending());
                        button.setOnClickListener(v -> open(room.getRoomId()));
                        ui.rooms.addView(button);
                    }
                    host.changed();
                }
                @Override public void onError(RepositoryError error) { if (token == screenGeneration) showError(error); }
            });
        } else {
            screen = session.repository.subscribeRoom(session.roomId, new MultiplayerRepository.RoomListener() {
                @Override public void onRoom(RoomSnapshot room) {
                    if (!active || token != screenGeneration) return;
                    session.room = room;
                    host.received(room);
                }
                @Override public void onError(RepositoryError error) { if (token == screenGeneration) showError(error); }
            });
            if (session.connected) {
                session.repository.getRoom(session.roomId, new MultiplayerRepository.ResultCallback<RoomSnapshot>() {
                    @Override public void onSuccess(RoomSnapshot room) {
                        if (!active || token != screenGeneration || !session.connected) return;
                        session.room = room;
                        session.reconciled = true;
                        host.received(room);
                    }
                    @Override public void onError(RepositoryError error) {
                        if (active && token == screenGeneration) showError(error);
                    }
                });
            }
        }
        host.changed();
    }

    private void refreshLatestScreen() {
        if (session.refreshOnline != null) session.refreshOnline.run();
    }

    private void authenticate(boolean create) {
        if (session.repository == null || session.authPending) return;
        session.authPending = true;
        String email = ui.email.getText().toString();
        String password = ui.password.getText().toString();
        ui.password.setText("");
        MultiplayerRepository.ResultCallback<String> callback = new MultiplayerRepository.ResultCallback<String>() {
            @Override public void onSuccess(String uid) {
                session.authPending = false;
                session.onlineMessage = "Signed in";
                refreshLatestScreen();
            }
            @Override public void onError(RepositoryError error) {
                session.authPending = false;
                showError(error);
                refreshLatestScreen();
            }
        };
        if (create) session.repository.createAccount(email, password, callback);
        else session.repository.signIn(email, password, callback);
        host.changed();
    }

    private void authenticateGoogle() {
        if (session.repository == null || session.authPending) return;
        session.authPending = true;
        pickingGoogle = true;
        long request = ++session.googleRequestGeneration;
        long generation = session.onlineGeneration;
        googleSignIn.signIn(new GoogleSignIn.Callback() {
            @Override public void token(String token) {
                if (request != session.googleRequestGeneration) return;
                pickingGoogle = false;
                if (generation != session.onlineGeneration || session.mode != GameSession.MODE_ONLINE) {
                    session.authPending = false;
                    refreshLatestScreen();
                    return;
                }
                session.repository.signInWithGoogle(token, new MultiplayerRepository.ResultCallback<String>() {
                    @Override public void onSuccess(String uid) {
                        session.authPending = false;
                        session.onlineMessage = "Signed in with Google";
                        refreshLatestScreen();
                    }
                    @Override public void onError(RepositoryError error) {
                        session.authPending = false;
                        showError(error);
                        refreshLatestScreen();
                    }
                });
            }
            @Override public void error(String message) {
                if (request != session.googleRequestGeneration) return;
                pickingGoogle = false;
                session.authPending = false;
                session.onlineMessage = message;
                refreshLatestScreen();
            }
        });
        host.changed();
    }

    void destroy() {
        if (pickingGoogle) {
            session.googleRequestGeneration++;
            session.authPending = false;
            pickingGoogle = false;
        }
        googleSignIn.cancel();
    }

    void createRoom() {
        if (!session.connected || pending() || session.repository == null) return;
        long token = session.onlineGeneration;
        session.onlineMessage = "Creating room…";
        session.repository.createRoom(ui.roomName.getText().toString(), new MultiplayerRepository.ResultCallback<String>() {
            @Override public void onSuccess(String roomId) {
                if (token != session.onlineGeneration) return;
                session.roomId = roomId;
                session.room = null;
                session.onlineMessage = "Room created";
                refreshLatestScreen();
            }
            @Override public void onError(RepositoryError error) {
                if (token == session.onlineGeneration) { showError(error); refreshLatestScreen(); }
            }
        });
        host.changed();
    }

    void newRoom() {
        if (session.room != null && session.connected && !pending()) {
            ui.roomName.setText(session.room.getRoom().getName());
            createRoom();
        } else {
            lobby();
        }
    }

    private void open(String roomId) {
        if (!session.connected || pending()) return;
        session.onlineGeneration++;
        long token = session.onlineGeneration;
        session.roomId = roomId;
        session.room = null;
        session.onlineMessage = "Opening room…";
        session.repository.joinRoom(roomId, new MultiplayerRepository.ResultCallback<RoomRole>() {
            @Override public void onSuccess(RoomRole role) {
                if (token != session.onlineGeneration) return;
                session.onlineMessage = "Joined as " + role.toString().toLowerCase(java.util.Locale.ROOT);
                refreshLatestScreen();
            }
            @Override public void onError(RepositoryError error) {
                if (token != session.onlineGeneration) return;
                showError(error);
                refreshLatestScreen();
            }
        });
        refreshScreen();
    }

    void lobby() {
        session.onlineGeneration++;
        session.roomId = null;
        session.room = null;
        session.onlineMessage = "Choose a room or create a new one. Previous rooms are preserved.";
        refreshScreen();
    }

    void move(int column) {
        if (!canMove()) return;
        long token = session.onlineGeneration;
        String prefix = session.room.getRoom().getMoves();
        session.onlineMessage = "Sending move…";
        session.repository.submitMove(session.roomId, column, prefix, new MultiplayerRepository.ResultCallback<String>() {
            @Override public void onSuccess(String moves) {
                if (token != session.onlineGeneration) return;
                session.onlineMessage = "Move accepted";
                refreshLatestScreen();
            }
            @Override public void onError(RepositoryError error) {
                if (token != session.onlineGeneration) return;
                showError(error);
                refreshLatestScreen();
            }
        });
        host.changed();
    }

    boolean canMove() {
        return active && session.connected && session.reconciled && !pending()
                && session.room != null && session.room.canMove();
    }

    private boolean pending() {
        MultiplayerRepository repo = session.repository;
        return repo != null && (repo.pendingCreateRoomId() != null || repo.pendingJoinRoomId() != null || repo.pendingMoveRoomId() != null);
    }

    private void showError(RepositoryError error) {
        session.onlineMessage = error.getMessage();
        session.reconciled = false;
        if (active) host.changed();
    }

    void render() {
        boolean signedIn = session.repository != null && session.repository.currentUid() != null;
        boolean inRoom = signedIn && session.roomId != null;
        ui.authPanel.setVisibility(signedIn ? View.GONE : View.VISIBLE);
        ui.lobbyPanel.setVisibility(signedIn && !inRoom ? View.VISIBLE : View.GONE);
        ui.backToLobby.setVisibility(inRoom ? View.VISIBLE : View.GONE);
        ui.signOut.setVisibility(signedIn ? View.VISIBLE : View.GONE);
        ui.signIn.setEnabled(session.repository != null && !session.authPending);
        ui.signUp.setEnabled(session.repository != null && !session.authPending);
        ui.googleSignIn.setEnabled(session.repository != null && !session.authPending);
        ui.createRoom.setEnabled(session.connected && !pending());
        ui.signOut.setEnabled(!pending() && !session.authPending);
        for (int i = 0; i < ui.rooms.getChildCount(); i++) {
            // Invalid rooms are never actionable; each button also guards connection in open().
            ui.rooms.getChildAt(i).setAlpha(session.connected && !pending() ? 1f : .5f);
        }
        String roomLabel = session.room == null || !inRoom ? "" : session.room.getRoom().getName() + " · "
                + session.room.getRole().toString().toLowerCase(java.util.Locale.ROOT) + " · "
                + session.room.getStatus().toString().toLowerCase(java.util.Locale.ROOT) + "\n";
        ui.onlineStatus.setText(roomLabel + (session.connected ? "Connected" : "Disconnected")
                + (pending() ? " · write pending / uncertain" : "") + "\n" + session.onlineMessage);
        ui.offlineGame.setVisibility(inRoom ? View.VISIBLE : View.GONE);
        ui.restart.setText("New room");
        ui.restart.setEnabled(session.connected && session.reconciled && session.room != null && !pending());
        ui.aiStatus.setText("Online · " + (session.room == null ? "reconciling room" : session.room.getRole().toString().toLowerCase(java.util.Locale.ROOT)));
    }
}
