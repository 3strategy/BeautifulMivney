package com.example.connect4.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.example.connect4.core.GameState;
import com.example.connect4.R;

/** Rendering and column hit testing only; GameEngine owns every rule. */
public final class BoardView extends View {
    /** Receives the zero-based column selected by the player. */
    public interface ColumnListener { void onColumn(int column); }
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private GameState state;
    private ColumnListener listener;
    private boolean inputEnabled;

    /** Constructs the XML-inflated board view and its accessibility description. */
    public BoardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setContentDescription("Connect Four board. Tap a column to drop a disc.");
    }

    /** Replaces the rendered snapshot and enables or disables touch input. */
    public void show(GameState state, boolean enabled) {
        this.state = state;
        inputEnabled = enabled;
        invalidate();
    }

    /** Assigns the controller callback used after a column tap. */
    public void setColumnListener(ColumnListener listener) { this.listener = listener; }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        setMeasuredDimension(width, resolveSize(width * GameState.ROWS / GameState.COLUMNS, heightSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float size = cellSize();
        float radius = size * .32f;
        paint.setColor(getContext().getColor(R.color.board_edge));
        canvas.drawRoundRect(0, 0, size * GameState.COLUMNS, size * GameState.ROWS, radius, radius, paint);
        paint.setColor(getContext().getColor(R.color.board));
        canvas.drawRoundRect(0, 0, size * GameState.COLUMNS,
                size * GameState.ROWS - size * .08f, radius, radius, paint);
        for (int row = 0; row < GameState.ROWS; row++) {
            for (int col = 0; col < GameState.COLUMNS; col++) {
                int player = state == null ? GameState.EMPTY : state.cell(row, col);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(getContext().getColor(player == GameState.RED ? R.color.disc_red
                        : player == GameState.YELLOW ? R.color.disc_yellow : R.color.board_hole));
                float x = (col + .5f) * size, y = (row + .5f) * size;
                canvas.drawCircle(x, y, size * .38f, paint);
                if (player != GameState.EMPTY) {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * .025f);
                    paint.setColor(0x40FFFFFF);
                    canvas.drawCircle(x, y - size * .015f, size * .30f, paint);
                    paint.setStyle(Paint.Style.FILL);
                }
                if (state != null) {
                    for (GameState.Cell cell : state.winningCells()) {
                        if (cell.row() == row && cell.column() == col) {
                            paint.setStyle(Paint.Style.STROKE);
                            paint.setStrokeWidth(size * .07f);
                            paint.setColor(getContext().getColor(R.color.disc_ring));
                            canvas.drawCircle(x, y, size * .29f, paint);
                            paint.setStyle(Paint.Style.FILL);
                        }
                    }
                }
            }
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!inputEnabled) return false;
        if (event.getAction() == MotionEvent.ACTION_UP) {
            float size = cellSize();
            float x = event.getX();
            float y = event.getY();
            // Use the drawn board bounds, even when the View has extra space around it.
            if (size > 0 && x >= 0 && x < size * GameState.COLUMNS
                    && y >= 0 && y < size * GameState.ROWS) {
                performClick();
                int column = (int) (x / size);
                if (listener != null) listener.onColumn(column);
            }
        }
        return true;
    }

    private float cellSize() {
        return Math.min(getWidth() / (float) GameState.COLUMNS,
                getHeight() / (float) GameState.ROWS);
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}
