package com.example.connect4;

import androidx.lifecycle.ViewModel;
import com.example.connect4.core.GameEngine;

/** Retains the game across Activity recreation, without keeping a View or Activity. */
public final class GameSession extends ViewModel {
    public GameEngine engine = new GameEngine();
    public boolean restored;
}
