package com.example.connect4;

import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;

import com.example.connect4.databinding.ActivityMainBinding;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private GameSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        session = new ViewModelProvider(this).get(GameSession.class);
        if (!session.restored) {
            String moves = getPreferences(MODE_PRIVATE).getString("moves", "");
            GameEngine restored = new GameEngine();
            for (int i = 0; i < moves.length(); i++) {
                if (!restored.apply(new GameAction(moves.charAt(i) - '0'))) break;
            }
            session.engine = restored;
            session.restored = true;
        }
        binding.board.setColumnListener(column -> {
            if (session.engine.apply(new GameAction(column))) { persist(); render(); }
        });
        binding.restart.setOnClickListener(v -> {
            session.engine = new GameEngine();
            persist();
            render();
        });
        render();
    }
    /** Presents the model; drawing does not change the game. */
    private void render() {
        GameState state = session.engine.snapshot();
        binding.board.show(state);
        if (state.isDraw()) binding.status.setText("Draw — board full");
        else if (state.isTerminal()) binding.status.setText(state.winner() == GameState.RED ? "Red wins!" : "Yellow wins!");
        else binding.status.setText(state.currentPlayer() == GameState.RED ? "Red to play" : "Yellow to play");
    }

    /** Saves only accepted column history; the engine reconstructs the rest. */
    private void persist() {
        getPreferences(MODE_PRIVATE).edit().putString("moves", session.engine.snapshot().moves()).apply();
    }

    @Override protected void onStop() {
        persist();
        super.onStop();
    }
}
