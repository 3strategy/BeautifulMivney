package com.example.connect4.core;

import java.util.Objects;

/** One Connect Four decision: the zero-based column where a piece is dropped. */
public final class GameAction {
    private final int column;

    /** Stores a proposed column; the engine decides whether it is legal. */
    public GameAction(int column) {
        this.column = column;
    }

    /** Returns the proposed zero-based column. */
    public int column() {
        return column;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof GameAction && column == ((GameAction) other).column;
    }

    @Override
    public int hashCode() {
        return Objects.hash(column);
    }

    @Override
    public String toString() {
        return "GameAction{" + "column=" + column + '}';
    }
}
