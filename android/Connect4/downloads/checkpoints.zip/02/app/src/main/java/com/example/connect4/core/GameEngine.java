package com.example.connect4.core;

/** Owns gravity, alternating turns and the mutable board. */
public final class GameEngine {
    private final int[][] board = new int[GameState.ROWS][GameState.COLUMNS];
    private int currentPlayer = GameState.RED;

    /** Returns a detached copy for the screen. */
    public GameState snapshot() { return new GameState(board, currentPlayer); }

    /** Rejects invalid or full columns without changing the turn. */
    public boolean apply(GameAction action) {
        if (action == null) return false;
        int column = action.column();
        if (column < 0 || column >= GameState.COLUMNS) return false;
        for (int row = GameState.ROWS - 1; row >= 0; row--) {
            if (board[row][column] == GameState.EMPTY) {
                board[row][column] = currentPlayer;
                currentPlayer = currentPlayer == GameState.RED ? GameState.YELLOW : GameState.RED;
                return true;
            }
        }
        return false;
    }
}
