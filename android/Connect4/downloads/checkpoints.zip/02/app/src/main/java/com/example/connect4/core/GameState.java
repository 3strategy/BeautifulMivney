package com.example.connect4.core;

/** A detached board snapshot. Only GameEngine changes the live game. */
public final class GameState {
    public static final int ROWS = 6;
    public static final int COLUMNS = 7;
    public static final int EMPTY = 0;
    public static final int RED = 1;
    public static final int YELLOW = 2;
    private final int[][] board;
    private final int currentPlayer;

    /** Copies every row so future engine changes cannot change this snapshot. */
    GameState(int[][] source, int currentPlayer) {
        board = new int[ROWS][COLUMNS];
        for (int row = 0; row < ROWS; row++) board[row] = source[row].clone();
        this.currentPlayer = currentPlayer;
    }

    /** Returns the occupant of a zero-based cell. */
    public int cell(int row, int column) { return board[row][column]; }

    /** Returns whose turn comes next. */
    public int currentPlayer() { return currentPlayer; }
}
