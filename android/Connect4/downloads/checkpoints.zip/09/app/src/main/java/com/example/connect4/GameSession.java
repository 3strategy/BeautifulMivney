package com.example.connect4;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.MainThread;
import androidx.lifecycle.ViewModel;
import com.example.connect4.ai.ComputerMoveService;
import com.example.connect4.ai.ModelCatalog;
import com.example.connect4.multiplayer.MultiplayerRepository;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Survives rotation. Only MainActivity updates the live engine on the main thread. */
public final class GameSession extends ViewModel {
    public static final int MODE_LOCAL = 0;
    public static final int MODE_HEURISTIC = 1;
    public static final int MODE_MODEL = 2;
    public static final int MODE_ONLINE = 3;
    public MultiplayerRepository repository;
    public boolean authPending;
    public String onlineMessage = "";
    public String onlineUid;
    public long onlineGeneration;
    public long googleRequestGeneration;
    public Runnable refreshOnline;
    public String selectedModelId = ModelCatalog.DEFAULT_MODEL_ID;

    public GameEngine engine = new GameEngine();
    public int mode = MODE_LOCAL;
    public int humanSide = GameState.RED;
    public boolean restored;
    public String modelStatus = "Heuristic · win, block, then center";
    private final ExecutorService computerWorker = Executors.newSingleThreadExecutor();
    private final Handler mainThread = new Handler(Looper.getMainLooper());
    private Future<?> pendingComputerMove;
    private long computerRequestId;
    private boolean computerThinking;
    private boolean computerMoveFailed;

    @MainThread
    public boolean isComputerThinking() { return computerThinking; }

    @MainThread
    public boolean hasComputerMoveFailed() { return computerMoveFailed; }

    /**
     * Runs one calculation on the worker and delivers its result on the main thread.
     * Cancelling invalidates even results that have already been posted for delivery.
     * The callback still checks the position and applies the action through GameEngine.
     */
    @MainThread
    public void requestComputerMove(
            Supplier<ComputerMoveService.Result> calculation,
            Consumer<ComputerMoveService.Result> onMoveReady,
            Consumer<RuntimeException> onFailure) {
        if (computerThinking) throw new IllegalStateException("A computer move is already pending");
        long requestId = ++computerRequestId;
        computerThinking = true;
        computerMoveFailed = false;
        pendingComputerMove = computerWorker.submit(() -> {
            try {
                ComputerMoveService.Result result = calculation.get();
                mainThread.post(() -> {
                    if (!completeComputerMove(requestId)) return;
                    onMoveReady.accept(result);
                });
            } catch (RuntimeException failure) {
                mainThread.post(() -> {
                    if (!completeComputerMove(requestId)) return;
                    computerMoveFailed = true;
                    onFailure.accept(failure);
                });
            }
        });
    }

    private boolean completeComputerMove(long requestId) {
        if (requestId != computerRequestId) return false;
        computerThinking = false;
        pendingComputerMove = null;
        return true;
    }

    /** Called before restart, configuration changes, leaving the screen, or disposal. */
    @MainThread
    public void cancelComputerMove() {
        computerRequestId++;
        computerThinking = false;
        computerMoveFailed = false;
        if (pendingComputerMove != null) pendingComputerMove.cancel(true);
        pendingComputerMove = null;
    }

    @Override protected void onCleared() {
        cancelComputerMove();
        computerWorker.shutdownNow();
    }
}
