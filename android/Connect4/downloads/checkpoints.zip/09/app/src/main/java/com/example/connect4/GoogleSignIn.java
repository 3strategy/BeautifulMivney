package com.example.connect4;

import android.app.Activity;
import android.os.CancellationSignal;
import androidx.core.content.ContextCompat;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.ClearCredentialException;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

/** Presents Google's account chooser; Firebase verifies the returned ID token. */
final class GoogleSignIn {
    interface Callback {
        void token(String token);
        void error(String message);
    }
    private final Activity activity;
    private final CredentialManager manager;
    private CancellationSignal cancellation;

    GoogleSignIn(Activity activity) {
        this.activity = activity;
        manager = CredentialManager.create(activity);
    }

    void signIn(Callback callback) {
        // Dynamic lookup keeps offline builds valid when Firebase config is absent.
        int resource = activity.getResources().getIdentifier("default_web_client_id", "string", activity.getPackageName());
        if (resource == 0) {
            callback.error("Google sign-in needs the updated Firebase OAuth configuration.");
            return;
        }
        GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(activity.getString(resource)).build();
        GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
        cancellation = new CancellationSignal();
        manager.getCredentialAsync(activity, request, cancellation, ContextCompat.getMainExecutor(activity),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override public void onResult(GetCredentialResponse response) {
                        cancellation = null;
                        Credential credential = response.getCredential();
                        if (!(credential instanceof CustomCredential)) {
                            callback.error("Google returned an unsupported credential.");
                            return;
                        }
                        try {
                            callback.token(GoogleIdTokenCredential.createFrom(credential.getData()).getIdToken());
                        } catch (Exception invalid) {
                            callback.error("Google sign-in returned an invalid token. Please try again.");
                        }
                    }
                    @Override public void onError(GetCredentialException error) {
                        cancellation = null;
                        callback.error(error instanceof GetCredentialCancellationException ? "Google sign-in cancelled."
                                : "Google sign-in could not finish: " + error.getMessage());
                    }
                });
    }

    void clearSession() {
        manager.clearCredentialStateAsync(new ClearCredentialStateRequest(), null,
                ContextCompat.getMainExecutor(activity), new CredentialManagerCallback<Void, ClearCredentialException>() {
                    @Override public void onResult(Void ignored) { }
                    @Override public void onError(ClearCredentialException ignored) { }
                });
    }

    void cancel() { if (cancellation != null) { cancellation.cancel(); cancellation = null; } }
}
