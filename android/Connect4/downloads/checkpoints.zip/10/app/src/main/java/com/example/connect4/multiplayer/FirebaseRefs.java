package com.example.connect4.multiplayer;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/** Centralized, game-scoped Firebase locations. */
public final class FirebaseRefs {
    public static final String DATABASE_URL =
            "https://guysfbfinal-default-rtdb.firebaseio.com";
    public static final String GAME_ROOT = "Connect4Rtdb";
    public static final String GAMES_CHILD = "games";

    private FirebaseRefs() {
    }

    /** Returns the configured shared database, rather than Firebase's default URL. */
    public static FirebaseDatabase database() {
        return FirebaseDatabase.getInstance(DATABASE_URL);
    }

    /** Returns this game's isolated room collection under the shared database. */
    public static DatabaseReference games(FirebaseDatabase database) {
        return database.getReference(GAME_ROOT).child(GAMES_CHILD);
    }

    /** Returns Firebase's read-only connection-status location. */
    public static DatabaseReference connection(FirebaseDatabase database) {
        return database.getReference(".info/connected");
    }
}
