package com.example.connect4.multiplayer;

/** One stable-key lobby entry. Invalid rooms remain visible as errors. */
public final class RoomSummary {
    private final String roomId;
    private final String name;
    private final RoomStatus status;
    private final String error;

    RoomSummary(String roomId, String name, RoomStatus status, String error) {
        this.roomId = roomId;
        this.name = name;
        this.status = status;
        this.error = error;
    }

    public String getRoomId() {
        return roomId;
    }

    public String getName() {
        return name;
    }

    public RoomStatus getStatus() {
        return status;
    }

    public String getError() {
        return error;
    }

    public boolean isValid() {
        return error == null;
    }
}
