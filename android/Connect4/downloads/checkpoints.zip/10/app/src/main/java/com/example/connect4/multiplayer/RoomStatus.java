package com.example.connect4.multiplayer;

/** Status derived from seats and replayed game state. */
public enum RoomStatus {
    WAITING,
    PLAYING,
    FINISHED
}
