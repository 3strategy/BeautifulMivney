package com.example.connect4.multiplayer;

/** The signed-in user's relationship to a room. */
public enum RoomRole {
    RED,
    YELLOW,
    SPECTATOR
}
