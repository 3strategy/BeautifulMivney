package com.example.connect4.multiplayer;

/** Stable error shape for UI recovery without exposing Firebase callbacks. */
public final class RepositoryError {
    public enum Code {
        AUTH_REQUIRED,
        BUSY,
        INVALID_ARGUMENT,
        INVALID_ROOM,
        MISSING_ROOM,
        CONFLICT,
        PERMISSION_DENIED,
        CANCELLED,
        NETWORK,
        UNKNOWN
    }

    private final Code code;
    private final String message;
    private final String roomId;

    RepositoryError(Code code, String message, String roomId) {
        this.code = code;
        this.message = message;
        this.roomId = roomId;
    }

    public Code getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getRoomId() {
        return roomId;
    }
}
