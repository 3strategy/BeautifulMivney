package com.example.connect4.multiplayer;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Owns Firebase authentication, scoped room references, subscriptions and atomic writes.
 * The controller remains the only owner of a live game; this class only publishes replayed
 * snapshots produced by the pure Java engine.
 */
public final class MultiplayerRepository {
    private final FirebaseAuth auth;
    private final FirebaseDatabase database;
    private final DatabaseReference gamesReference;

    private String pendingCreateRoomId;
    private String pendingJoinRoomId;

    /** Creates a repository backed by the configured production Firebase instances. */
    public MultiplayerRepository() {
        this(FirebaseAuth.getInstance(), FirebaseRefs.database());
    }

    /** Allows debug builds and tests to inject Firebase instances configured for emulators. */
    public MultiplayerRepository(FirebaseAuth auth, FirebaseDatabase database) {
        this.auth = auth;
        this.database = database;
        this.gamesReference = FirebaseRefs.games(database);
    }

    /** Returns the authenticated Firebase user's UID, or {@code null} when signed out. */
    public String currentUid() {
        FirebaseUser user = auth.getCurrentUser();
        return user == null ? null : user.getUid();
    }

    /** Signs in with email/password and reports the resulting UID asynchronously. */
    public void signIn(String email, String password, ResultCallback<String> callback) {
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Email and password are required", null));
            return;
        }
        auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(result -> callback.onSuccess(result.getUser().getUid()))
                .addOnFailureListener(exception -> callback.onError(firebaseError(exception, null)));
    }

    /** Creates an email/password account and reports the resulting UID asynchronously. */
    public void createAccount(String email, String password, ResultCallback<String> callback) {
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Email and password are required", null));
            return;
        }
        auth.createUserWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(result -> callback.onSuccess(result.getUser().getUid()))
                .addOnFailureListener(exception -> callback.onError(firebaseError(exception, null)));
    }

    /** Exchanges a Google ID token obtained by the Android credential UI for Firebase Auth. */
    public void signInWithGoogle(String idToken, ResultCallback<String> callback) {
        if (idToken == null || idToken.trim().isEmpty()) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Google sign-in returned no ID token", null));
            return;
        }
        auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken.trim(), null))
                .addOnSuccessListener(result -> callback.onSuccess(result.getUser().getUid()))
                .addOnFailureListener(exception -> callback.onError(firebaseError(exception, null)));
    }

    /** Clears the current Firebase authentication session. */
    public void signOut() {
        auth.signOut();
    }

    /** Subscribes to authentication changes; callers must close the returned subscription. */
    public Subscription subscribeAuth(AuthListener listener) {
        FirebaseAuth.AuthStateListener firebaseListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            listener.onAuthChanged(user == null ? null : user.getUid());
        };
        auth.addAuthStateListener(firebaseListener);
        return once(() -> auth.removeAuthStateListener(firebaseListener));
    }


    /** Subscribes to the lobby's validated room summaries. */
    public Subscription subscribeLobby(LobbyListener listener) {
        if (currentUid() == null) {
            listener.onError(error(RepositoryError.Code.AUTH_REQUIRED,
                    "Sign in to view online rooms", null));
            return Subscription.EMPTY;
        }

        ValueEventListener firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<RoomSummary> rooms = new ArrayList<>();
                for (DataSnapshot roomSnapshot : snapshot.getChildren()) {
                    String roomId = roomSnapshot.getKey();
                    ParsedRoom parsed = parseRoom(roomSnapshot);
                    if (parsed.error != null) {
                        String name = parsed.room == null || parsed.room.getName() == null
                                ? "Invalid room" : parsed.room.getName();
                        rooms.add(new RoomSummary(roomId, name, null, parsed.error));
                    } else {
                        rooms.add(new RoomSummary(roomId, parsed.room.getName(),
                                parsed.validation.getStatus(), null));
                    }
                }
                listener.onRooms(Collections.unmodifiableList(rooms));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                listener.onError(databaseError(databaseError, null));
            }
        };
        gamesReference.addValueEventListener(firebaseListener);
        return once(() -> gamesReference.removeEventListener(firebaseListener));
    }

    /** Subscribes to one room after validating its data and replaying its move history. */
    public Subscription subscribeRoom(String roomId, RoomListener listener) {
        if (!validRoomId(roomId)) {
            listener.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Room ID is missing or invalid", roomId));
            return Subscription.EMPTY;
        }
        String uid = currentUid();
        if (uid == null) {
            listener.onError(error(RepositoryError.Code.AUTH_REQUIRED,
                    "Sign in to open an online room", roomId));
            return Subscription.EMPTY;
        }

        DatabaseReference roomReference = gamesReference.child(roomId);
        ValueEventListener firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    listener.onError(error(RepositoryError.Code.MISSING_ROOM,
                            "This room no longer exists", roomId));
                    return;
                }
                ParsedRoom parsed = parseRoom(snapshot);
                if (parsed.error != null) {
                    listener.onError(error(RepositoryError.Code.INVALID_ROOM,
                            parsed.error, roomId));
                    return;
                }
                RoomRole role = roleFor(parsed.room, uid);
                listener.onRoom(new RoomSnapshot(roomId, parsed.room,
                        parsed.validation.getState(), role, parsed.validation.getStatus()));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                listener.onError(databaseError(databaseError, roomId));
            }
        };
        roomReference.addValueEventListener(firebaseListener);
        return once(() -> roomReference.removeEventListener(firebaseListener));
    }

    /** Performs a one-shot server read used to gate input after reconnecting. */
    public void getRoom(String roomId, ResultCallback<RoomSnapshot> callback) {
        if (!validRoomId(roomId)) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Room ID is missing or invalid", roomId));
            return;
        }
        String uid = currentUid();
        if (uid == null) {
            callback.onError(error(RepositoryError.Code.AUTH_REQUIRED,
                    "Sign in to open an online room", roomId));
            return;
        }
        gamesReference.child(roomId).get().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                callback.onError(firebaseError(task.getException(), roomId));
                return;
            }
            DataSnapshot snapshot = task.getResult();
            if (!snapshot.exists()) {
                callback.onError(error(RepositoryError.Code.MISSING_ROOM,
                        "This room no longer exists", roomId));
                return;
            }
            ParsedRoom parsed = parseRoom(snapshot);
            if (parsed.error != null) {
                callback.onError(error(RepositoryError.Code.INVALID_ROOM,
                        parsed.error, roomId));
                return;
            }
            callback.onSuccess(new RoomSnapshot(roomId, parsed.room,
                    parsed.validation.getState(), roleFor(parsed.room, uid),
                    parsed.validation.getStatus()));
        });
    }

    /** Creates a Red-owned waiting room with a server-assigned identifier. */
    public void createRoom(String rawName, ResultCallback<String> callback) {
        String uid = currentUid();
        if (uid == null) {
            callback.onError(error(RepositoryError.Code.AUTH_REQUIRED,
                    "Sign in before creating a room", null));
            return;
        }
        String name = rawName == null ? "" : rawName.trim();
        if (name.isEmpty() || name.length() > RoomValidation.MAX_NAME_LENGTH) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Room name must contain 1-60 characters", null));
            return;
        }

        DatabaseReference newRoomReference;
        synchronized (this) {
            if (pendingCreateRoomId != null) {
                callback.onError(error(RepositoryError.Code.BUSY,
                        "A room creation is already pending", pendingCreateRoomId));
                return;
            }
            newRoomReference = gamesReference.push();
            pendingCreateRoomId = newRoomReference.getKey();
        }

        String roomId = newRoomReference.getKey();
        Map<String, Object> room = new LinkedHashMap<>();
        room.put("schemaVersion", RoomValidation.SCHEMA_VERSION);
        room.put("name", name);
        room.put("playerRed", uid);
        room.put("playerYellow", "");
        room.put("moves", "");
        room.put("createdAt", ServerValue.TIMESTAMP);
        room.put("updatedAt", ServerValue.TIMESTAMP);

        newRoomReference.setValue(room).addOnCompleteListener(task -> {
            clearPendingCreate(roomId);
            if (task.isSuccessful()) {
                callback.onSuccess(roomId);
            } else {
                callback.onError(firebaseError(task.getException(), roomId));
            }
        });
    }

    /** Claims Yellow atomically, or returns the caller's existing/spectator role. */
    public void joinRoom(String roomId, ResultCallback<RoomRole> callback) {
        String uid = currentUid();
        if (uid == null) {
            callback.onError(error(RepositoryError.Code.AUTH_REQUIRED,
                    "Sign in before joining a room", roomId));
            return;
        }
        if (!validRoomId(roomId)) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Room ID is missing or invalid", roomId));
            return;
        }
        synchronized (this) {
            if (pendingJoinRoomId != null) {
                callback.onError(error(RepositoryError.Code.BUSY,
                        "A room join is already pending", pendingJoinRoomId));
                return;
            }
            pendingJoinRoomId = roomId;
        }

        DatabaseReference roomReference = gamesReference.child(roomId);
        roomReference.get().addOnCompleteListener(readTask -> {
            if (!readTask.isSuccessful()) {
                clearPendingJoin(roomId);
                callback.onError(firebaseError(readTask.getException(), roomId));
                return;
            }
            if (!readTask.getResult().exists()) {
                clearPendingJoin(roomId);
                callback.onError(error(RepositoryError.Code.MISSING_ROOM,
                        "This room no longer exists", roomId));
                return;
            }
            ParsedRoom baseline = parseRoom(readTask.getResult());
            if (baseline.error != null) {
                clearPendingJoin(roomId);
                callback.onError(error(RepositoryError.Code.INVALID_ROOM,
                        baseline.error, roomId));
                return;
            }
            RoomRole existingRole = roleFor(baseline.room, uid);
            if (existingRole != RoomRole.SPECTATOR
                    || !baseline.room.getPlayerYellow().isEmpty()) {
                clearPendingJoin(roomId);
                callback.onSuccess(existingRole);
                return;
            }
            runJoinTransaction(roomReference, roomId, uid, baseline.room, callback);
        });
    }

    private void runJoinTransaction(DatabaseReference roomReference, String roomId, String uid,
                                    RoomData baseline,
                                    ResultCallback<RoomRole> callback) {
        AtomicReference<String> rejection = new AtomicReference<>("Room changed while joining");
        AtomicReference<RoomRole> resolvedRole = new AtomicReference<>();
        roomReference.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData currentData) {
                seedEmptyTransaction(currentData, baseline);
                MutableRoom parsed = parseMutableRoom(currentData);
                if (parsed.error != null) {
                    rejection.set(parsed.error);
                    return Transaction.abort();
                }
                RoomData room = parsed.room;
                if (uid.equals(room.getPlayerRed())) {
                    resolvedRole.set(RoomRole.RED);
                    return Transaction.abort();
                }
                if (uid.equals(room.getPlayerYellow())) {
                    resolvedRole.set(RoomRole.YELLOW);
                    return Transaction.abort();
                }
                if (!room.getPlayerYellow().isEmpty()) {
                    resolvedRole.set(RoomRole.SPECTATOR);
                    return Transaction.abort();
                }
                if (!room.getMoves().isEmpty()) {
                    rejection.set("A room cannot be joined after moves have started");
                    return Transaction.abort();
                }
                currentData.child("playerYellow").setValue(uid);
                currentData.child("updatedAt").setValue(ServerValue.TIMESTAMP);
                rejection.set(null);
                return Transaction.success(currentData);
            }

            @Override
            public void onComplete(DatabaseError databaseError, boolean committed,
                                   DataSnapshot snapshot) {
                clearPendingJoin(roomId);
                if (databaseError != null) {
                    callback.onError(databaseError(databaseError, roomId));
                    return;
                }
                if (!committed) {
                    if (resolvedRole.get() != null) {
                        callback.onSuccess(resolvedRole.get());
                        return;
                    }
                    callback.onError(error(RepositoryError.Code.CONFLICT,
                            rejection.get(), roomId));
                    return;
                }
                // Re-read committed data: transaction snapshots can contain estimated timestamps.
                getRoom(roomId, new ResultCallback<RoomSnapshot>() {
                    @Override public void onSuccess(RoomSnapshot room) {
                        callback.onSuccess(room.getRole());
                    }
                    @Override public void onError(RepositoryError failure) {
                        callback.onError(failure);
                    }
                });
            }
        }, false);
    }



    public synchronized String pendingCreateRoomId() {
        return pendingCreateRoomId;
    }

    public synchronized String pendingJoinRoomId() {
        return pendingJoinRoomId;
    }


    private synchronized void clearPendingCreate(String roomId) {
        if (roomId != null && roomId.equals(pendingCreateRoomId)) {
            pendingCreateRoomId = null;
        }
    }

    private synchronized void clearPendingJoin(String roomId) {
        if (roomId.equals(pendingJoinRoomId)) {
            pendingJoinRoomId = null;
        }
    }


    private static ParsedRoom parseRoom(DataSnapshot snapshot) {
        RoomData room;
        try {
            room = snapshot.getValue(RoomData.class);
        } catch (DatabaseException exception) {
            return new ParsedRoom(null, null, "Room fields have invalid types");
        }
        if (!hasExactFields(snapshot)) {
            return new ParsedRoom(room, null, "Room fields are missing or unexpected");
        }
        RoomValidation.Result validation = RoomValidation.validate(room);
        return validation.isValid()
                ? new ParsedRoom(room, validation, null)
                : new ParsedRoom(room, validation, validation.getError());
    }

    private static MutableRoom parseMutableRoom(MutableData data) {
        if (data == null || data.getValue() == null) {
            return new MutableRoom(null, null, "Room data is not available");
        }
        if (!hasExactFields(data)) {
            return new MutableRoom(null, null, "Room fields are missing or unexpected");
        }
        RoomData room;
        try {
            room = data.getValue(RoomData.class);
        } catch (DatabaseException exception) {
            return new MutableRoom(null, null, "Room fields have invalid types");
        }
        RoomValidation.Result validation = RoomValidation.validate(room);
        return validation.isValid()
                ? new MutableRoom(room, validation, null)
                : new MutableRoom(room, validation, validation.getError());
    }

    /**
     * Transactions may make an initial callback with an empty local cache. The prior server read
     * supplies a candidate for that attempt. Firebase's compare-and-retry protocol replaces it
     * with current server data before any stale candidate can commit.
     */
    private static void seedEmptyTransaction(MutableData data, RoomData baseline) {
        if (data.getValue() == null) {
            data.setValue(baseline);
        }
    }

    private static boolean hasExactFields(DataSnapshot snapshot) {
        return snapshot.getChildrenCount() == 7
                && snapshot.hasChild("schemaVersion")
                && snapshot.hasChild("name")
                && snapshot.hasChild("playerRed")
                && snapshot.hasChild("playerYellow")
                && snapshot.hasChild("moves")
                && snapshot.hasChild("createdAt")
                && snapshot.hasChild("updatedAt");
    }

    private static boolean hasExactFields(MutableData data) {
        return data.getChildrenCount() == 7
                && data.hasChild("schemaVersion")
                && data.hasChild("name")
                && data.hasChild("playerRed")
                && data.hasChild("playerYellow")
                && data.hasChild("moves")
                && data.hasChild("createdAt")
                && data.hasChild("updatedAt");
    }

    private static RoomRole roleFor(RoomData room, String uid) {
        if (uid.equals(room.getPlayerRed())) {
            return RoomRole.RED;
        }
        if (uid.equals(room.getPlayerYellow())) {
            return RoomRole.YELLOW;
        }
        return RoomRole.SPECTATOR;
    }

    private static boolean validRoomId(String roomId) {
        return roomId != null && !roomId.isEmpty()
                && roomId.indexOf('/') < 0 && roomId.indexOf('.') < 0
                && roomId.indexOf('#') < 0 && roomId.indexOf('$') < 0
                && roomId.indexOf('[') < 0 && roomId.indexOf(']') < 0;
    }

    private static RepositoryError databaseError(DatabaseError databaseError, String roomId) {
        RepositoryError.Code code;
        if (databaseError.getCode() == DatabaseError.PERMISSION_DENIED) {
            code = RepositoryError.Code.PERMISSION_DENIED;
        } else if (databaseError.getCode() == DatabaseError.DISCONNECTED
                || databaseError.getCode() == DatabaseError.NETWORK_ERROR) {
            code = RepositoryError.Code.NETWORK;
        } else {
            code = RepositoryError.Code.CANCELLED;
        }
        return error(code, databaseError.getMessage(), roomId);
    }

    private static RepositoryError firebaseError(Exception exception, String roomId) {
        String message = exception == null || exception.getLocalizedMessage() == null
                ? "Firebase operation failed" : exception.getLocalizedMessage();
        return error(RepositoryError.Code.UNKNOWN, message, roomId);
    }

    private static RepositoryError error(RepositoryError.Code code, String message,
                                         String roomId) {
        return new RepositoryError(code, message == null ? "Operation failed" : message, roomId);
    }

    private static Subscription once(Runnable remover) {
        return new Subscription() {
            private boolean closed;

            @Override
            public synchronized void close() {
                if (!closed) {
                    closed = true;
                    remover.run();
                }
            }
        };
    }

    private static final class ParsedRoom {
        private final RoomData room;
        private final RoomValidation.Result validation;
        private final String error;

        private ParsedRoom(RoomData room, RoomValidation.Result validation, String error) {
            this.room = room;
            this.validation = validation;
            this.error = error;
        }
    }

    private static final class MutableRoom {
        private final RoomData room;
        private final RoomValidation.Result validation;
        private final String error;

        private MutableRoom(RoomData room, RoomValidation.Result validation, String error) {
            this.room = room;
            this.validation = validation;
            this.error = error;
        }
    }

    public interface Subscription extends AutoCloseable {
        Subscription EMPTY = () -> { };

        @Override
        void close();
    }

    public interface ResultCallback<T> {
        void onSuccess(T result);

        void onError(RepositoryError error);
    }

    public interface AuthListener {
        void onAuthChanged(String uid);
    }

    public interface LobbyListener {
        void onRooms(List<RoomSummary> rooms);

        void onError(RepositoryError error);
    }

    public interface RoomListener {
        void onRoom(RoomSnapshot room);

        void onError(RepositoryError error);
    }
}
