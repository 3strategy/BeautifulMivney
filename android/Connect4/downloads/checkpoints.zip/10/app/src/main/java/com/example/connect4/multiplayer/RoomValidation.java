package com.example.connect4.multiplayer;

import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;

/** Strict validation and deterministic replay for Firebase room data. */
public final class RoomValidation {
    public static final int SCHEMA_VERSION = 1;
    public static final int MAX_NAME_LENGTH = 60;
    public static final int MAX_MOVES = 42;

    private RoomValidation() {
    }

    /** Replays persisted moves and returns either a derived status or a safe validation error. */
    public static Result validate(RoomData room) {
        if (room == null) {
            return Result.invalid("Room data is missing");
        }
        if (room.getSchemaVersion() != SCHEMA_VERSION) {
            return Result.invalid("Unsupported room schema");
        }

        String name = room.getName();
        if (name == null || name.isEmpty() || name.length() > MAX_NAME_LENGTH
                || !name.equals(name.trim())) {
            return Result.invalid("Room name must be trimmed and contain 1-60 characters");
        }

        String red = room.getPlayerRed();
        String yellow = room.getPlayerYellow();
        String moves = room.getMoves();
        if (red == null || red.isEmpty()) {
            return Result.invalid("Room has no Red player");
        }
        if (yellow == null) {
            return Result.invalid("Room has no Yellow seat field");
        }
        if (!yellow.isEmpty() && yellow.equals(red)) {
            return Result.invalid("Red and Yellow must be different users");
        }
        if (moves == null || moves.length() > MAX_MOVES || !moves.matches("[0-6]*")) {
            return Result.invalid("Move history must contain at most 42 columns from 0 to 6");
        }
        if (yellow.isEmpty() && !moves.isEmpty()) {
            return Result.invalid("A waiting room cannot contain moves");
        }
        if (room.getCreatedAt() <= 0 || room.getUpdatedAt() < room.getCreatedAt()) {
            return Result.invalid("Room timestamps are missing or out of order");
        }

        GameEngine engine = new GameEngine();
        for (int index = 0; index < moves.length(); index++) {
            int column = moves.charAt(index) - '0';
            if (!engine.apply(new GameAction(column))) {
                return Result.invalid("Move history is illegal at move " + (index + 1));
            }
        }

        GameState state = engine.snapshot();
        RoomStatus status;
        if (yellow.isEmpty()) {
            status = RoomStatus.WAITING;
        } else if (state.isTerminal()) {
            status = RoomStatus.FINISHED;
        } else {
            status = RoomStatus.PLAYING;
        }
        return Result.valid(state, status);
    }

    /** Immutable result of validating a Firebase room payload. */
    public static final class Result {
        private final GameState state;
        private final RoomStatus status;
        private final String error;

        private Result(GameState state, RoomStatus status, String error) {
            this.state = state;
            this.status = status;
            this.error = error;
        }

        private static Result valid(GameState state, RoomStatus status) {
            return new Result(state, status, null);
        }

        private static Result invalid(String error) {
            return new Result(null, null, error);
        }

        /** Reports whether all schema, seat, timestamp, and replay checks passed. */
        public boolean isValid() {
            return error == null;
        }

        /** Returns the replayed state, or {@code null} when validation failed. */
        public GameState getState() {
            return state;
        }

        public RoomStatus getStatus() {
            return status;
        }

        public String getError() {
            return error;
        }
    }
}
