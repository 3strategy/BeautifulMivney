package com.example.connect4;

import android.os.Bundle;
import android.content.Context;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;
import com.example.connect4.core.MctsPlayer;
import com.example.connect4.ai.ModelCatalog;
import com.example.connect4.ai.ComputerMoveService;
import com.example.connect4.databinding.ActivityMainBinding;

/** Coordinates the local game UI, retained session state, AI work, and online screen. */
public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private GameSetupFragment setup;
    private GameSession session;
    private boolean started;
    private OnlineController online;
    private ModelCatalog modelCatalog;

    /** Exposes the activity binding only to the package-local online controller. */
    ActivityMainBinding viewBinding() {
        return binding;
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setup = (GameSetupFragment) getSupportFragmentManager().findFragmentById(R.id.gameSetup);
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        session = new ViewModelProvider(this).get(GameSession.class);
        String catalogFailure = null;
        try {
            modelCatalog = ModelCatalog.load(getAssets());
        } catch (Exception failure) {
            modelCatalog = ModelCatalog.fallback();
            catalogFailure = "Model catalog unavailable · " + failure.getMessage();
        }
        boolean initializeModelStatus = false;
        if (!session.restored) {
            android.content.SharedPreferences saved = getPreferences(MODE_PRIVATE);
            session.mode = saved.getInt("mode", GameSession.MODE_LOCAL);
            if (session.mode < GameSession.MODE_LOCAL || session.mode > GameSession.MODE_ONLINE) {
                session.mode = GameSession.MODE_LOCAL;
            }
            session.humanSide = saved.getInt("side", GameState.RED);
            if (session.humanSide != GameState.RED && session.humanSide != GameState.YELLOW) {
                session.humanSide = GameState.RED;
            }
            session.roomId = saved.getString("room", null);
            session.selectedModelId = saved.getString(
                    "computer_player", modelCatalog.defaultModelId());
            String moves = saved.getString("moves", "");
            GameEngine restored = new GameEngine();
            for (int i = 0; i < moves.length(); i++) {
                if (!restored.apply(new GameAction(moves.charAt(i) - '0'))) break;
            }
            session.engine = restored;
            session.restored = true;
            initializeModelStatus = true;
        }
        if (modelCatalog.find(session.selectedModelId) == null) {
            session.selectedModelId = modelCatalog.defaultModelId();
            initializeModelStatus = true;
        }
        if (catalogFailure != null) {
            session.modelStatus = catalogFailure;
        } else if (initializeModelStatus) {
            session.modelStatus = selectedModel().displayName()
                    + " loads on the computer’s turn";
        }
        online = new OnlineController(this, binding, session, new OnlineController.Host() {
            @Override public void changed() { persist(); render(); }
            @Override public void received(com.example.connect4.multiplayer.RoomSnapshot room) {
                session.engine = new GameEngine(room.getGameState());
                persist();
                render();
            }
        });
        setup.configure(modelCatalog.entries().stream()
                .map(ModelCatalog.Entry::displayName).toArray(String[]::new),
                session.mode, session.humanSide - 1, selectedModelPosition(),
                new GameSetupFragment.Listener() {
            @Override public void onModeSelected(int position) {
                if (session.mode != position) {
                    session.mode = position;
                    session.modelStatus = selectedModel().displayName()
                            + " loads on the computer’s turn";
                    session.cancelComputerMove();
                    online.modeChanged();
                    if (position != GameSession.MODE_ONLINE) newGame();
                }
                render();
            }
            @Override public void onSideSelected(int position) {
                if (session.humanSide != position + 1) {
                    session.humanSide = position + 1;
                    newGame();
                }
                render();
            }
            @Override public void onComputerSelected(int position) {
                ModelCatalog.Entry selected = modelCatalog.entries().get(position);
                if (!selected.id().equals(session.selectedModelId)) {
                    session.selectedModelId = selected.id();
                    session.modelStatus = selected.displayName() + " loads on the computer’s turn";
                    session.cancelComputerMove();
                    if (session.mode == GameSession.MODE_MODEL) newGame();
                    else persist();
                }
                render();
            }
        });
        binding.board.setColumnListener(this::playColumn);
        binding.restart.setOnClickListener(v -> newGame());
        render();
    }

    com.example.connect4.databinding.FragmentGameSetupBinding setupBinding() {
        return setup.viewBinding();
    }

    private void newGame() {
        session.cancelComputerMove();
        if (session.mode == GameSession.MODE_ONLINE) { online.newRoom(); return; }
        session.engine = new GameEngine();
        persist();
        render();
    }


    private boolean humanTurn() {
        GameState state = session.engine.snapshot();
        if (session.mode == GameSession.MODE_ONLINE) return false;
        return started && !state.isTerminal() && !session.isComputerThinking()
                && (session.mode == GameSession.MODE_LOCAL
                || state.currentPlayer() == session.humanSide);
    }

    private void playColumn(int column) {
        if (!humanTurn()) return;
        if (session.engine.apply(new GameAction(column))) { persist(); render(); }
    }

    private void render() {
        GameState state = session.engine.snapshot();
        boolean online = session.mode == GameSession.MODE_ONLINE;
        setup.showMode(session.mode);
        binding.onlinePanel.setVisibility(online ? View.VISIBLE : View.GONE);
        binding.offlineGame.setVisibility(online ? View.GONE : View.VISIBLE);
        binding.restart.setText(R.string.new_game);
        binding.restart.setEnabled(true);
        String player = playerName(state.currentPlayer());
        if (state.isDraw()) {
            binding.status.setText(R.string.game_draw);
        } else if (state.isTerminal()) {
            binding.status.setText(getString(R.string.player_wins, playerName(state.winner())));
        } else {
            int message = session.isComputerThinking() ? R.string.player_thinking : R.string.player_to_play;
            binding.status.setText(getString(message, player));
        }
        if (session.mode == GameSession.MODE_LOCAL) {
            binding.aiStatus.setText(R.string.local_play_status);
        } else if (session.mode == GameSession.MODE_HEURISTIC && !session.hasComputerMoveFailed()) {
            binding.aiStatus.setText(R.string.heuristic_status);
        } else {
            binding.aiStatus.setText(session.modelStatus);
        }
        binding.board.show(state, humanTurn());
        if (online && this.online != null) this.online.render();
        binding.restart.setVisibility(binding.offlineGame.getVisibility());
        requestComputerMoveIfNeeded();
    }




    private String playerName(int player) {
        return getString(player == GameState.RED ? R.string.player_red : R.string.player_yellow);
    }

    /** Captures one turn before handing its immutable state to the computer worker. */
    private void requestComputerMoveIfNeeded() {
        GameState requestedState = session.engine.snapshot();
        if (!started || session.mode == GameSession.MODE_LOCAL
                || session.mode == GameSession.MODE_ONLINE || session.isComputerThinking()
                || session.hasComputerMoveFailed() || requestedState.isTerminal()
                || requestedState.currentPlayer() == session.humanSide) return;

        int requestedMode = session.mode;
        ModelCatalog.Entry selectedModel = selectedModel();
        Context applicationContext = getApplicationContext();
        binding.status.setText(getString(R.string.player_thinking, playerName(requestedState.currentPlayer())));
        session.requestComputerMove(
                () -> {
                    if (requestedMode == GameSession.MODE_MODEL) {
                        return ComputerMoveService.chooseModelMove(applicationContext, selectedModel,
                                requestedState, MctsPlayer.DEFAULT_PHONE_SIMULATIONS);
                    }
                    return ComputerMoveService.chooseHeuristicMove(requestedState);
                },
                result -> applyComputerMove(requestedState, result),
                failure -> {
                    session.modelStatus = "Computer move failed · " + failure.getMessage();
                    render();
                });
    }

    /** Receives a proposed action on the main thread; the live engine has the final say. */
    private void applyComputerMove(GameState requestedState, ComputerMoveService.Result result) {
        if (!started || !requestedState.equals(session.engine.snapshot())) return;
        session.modelStatus = result.status();
        if (!session.engine.apply(result.action())) {
            // The service already checked legality against this exact snapshot.
            throw new IllegalStateException("Computer action was rejected for an unchanged turn");
        }
        persist();
        render();
    }

    private void persist() {
        getPreferences(MODE_PRIVATE).edit().putInt("mode", session.mode).putInt("side", session.humanSide)
                .putString("moves", session.engine.snapshot().moves()).putString("room", session.roomId)
                .putString("computer_player", session.selectedModelId).apply();
    }

    private ModelCatalog.Entry selectedModel() {
        ModelCatalog.Entry selected = modelCatalog.find(session.selectedModelId);
        return selected == null ? modelCatalog.require(modelCatalog.defaultModelId()) : selected;
    }

    private int selectedModelPosition() {
        for (int index = 0; index < modelCatalog.entries().size(); index++) {
            if (modelCatalog.entries().get(index).id().equals(session.selectedModelId)) {
                return index;
            }
        }
        return 0;
    }

    @Override protected void onStart() { super.onStart(); started = true; online.start(); render(); }
    @Override protected void onStop() {
        started = false;
        session.cancelComputerMove();
        online.stop();
        persist();
        super.onStop();
    }

    @Override protected void onDestroy() { online.destroy(); super.onDestroy(); }
}
