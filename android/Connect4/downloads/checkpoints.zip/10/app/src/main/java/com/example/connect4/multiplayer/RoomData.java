package com.example.connect4.multiplayer;

/** Firebase representation of one Connect Four room. */
public class RoomData {
    private int schemaVersion;
    private String name;
    private String playerRed;
    private String playerYellow;
    private String moves;
    private long createdAt;
    private long updatedAt;

    /** Required by Firebase's object mapper. */
    public RoomData() {
    }

    public RoomData(int schemaVersion, String name, String playerRed,
                    String playerYellow, String moves, long createdAt, long updatedAt) {
        this.schemaVersion = schemaVersion;
        this.name = name;
        this.playerRed = playerRed;
        this.playerYellow = playerYellow;
        this.moves = moves;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getSchemaVersion() {
        return schemaVersion;
    }

    public void setSchemaVersion(int schemaVersion) {
        this.schemaVersion = schemaVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlayerRed() {
        return playerRed;
    }

    public void setPlayerRed(String playerRed) {
        this.playerRed = playerRed;
    }

    public String getPlayerYellow() {
        return playerYellow;
    }

    public void setPlayerYellow(String playerYellow) {
        this.playerYellow = playerYellow;
    }

    public String getMoves() {
        return moves;
    }

    public void setMoves(String moves) {
        this.moves = moves;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }
}
