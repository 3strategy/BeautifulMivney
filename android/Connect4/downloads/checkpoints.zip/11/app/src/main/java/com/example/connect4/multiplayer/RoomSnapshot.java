package com.example.connect4.multiplayer;

import com.example.connect4.core.GameState;

/** A validated room plus its locally replayed game snapshot. */
public final class RoomSnapshot {
    private final String roomId;
    private final RoomData room;
    private final GameState gameState;
    private final RoomRole role;
    private final RoomStatus status;

    RoomSnapshot(String roomId, RoomData room, GameState gameState,
                 RoomRole role, RoomStatus status) {
        this.roomId = roomId;
        this.room = room;
        this.gameState = gameState;
        this.role = role;
        this.status = status;
    }

    public String getRoomId() {
        return roomId;
    }

    public RoomData getRoom() {
        return room;
    }

    public GameState getGameState() {
        return gameState;
    }

    public RoomRole getRole() {
        return role;
    }

    public RoomStatus getStatus() {
        return status;
    }

    /** Reports whether this role owns the side to move in an active, validated room. */
    public boolean canMove() {
        if (status != RoomStatus.PLAYING || role == RoomRole.SPECTATOR) {
            return false;
        }
        int player = gameState.currentPlayer();
        return (role == RoomRole.RED && player == 1)
                || (role == RoomRole.YELLOW && player == 2);
    }
}
