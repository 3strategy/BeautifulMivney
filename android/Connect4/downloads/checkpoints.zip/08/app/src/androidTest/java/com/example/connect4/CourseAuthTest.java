package com.example.connect4;
import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.example.connect4.multiplayer.*;
import org.junit.Test;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.Assert.*;

/** Requires the local Firebase Auth emulator at host port 9099. */
public class CourseAuthTest {
    @Test public void accountSignOutAndSignInKeepTheSameUid() throws Exception {
        Context context=ApplicationProvider.getApplicationContext();
        FirebaseApp app=FirebaseApp.initializeApp(context,new FirebaseOptions.Builder()
                .setProjectId("demo-connect4").setApplicationId("1:123:android:course")
                .setApiKey("fake-key-for-emulator").build(),"course-"+UUID.randomUUID());
        try {
            FirebaseAuth auth=FirebaseAuth.getInstance(app);
            auth.useEmulator("10.0.2.2",9099);
            MultiplayerRepository repo=new MultiplayerRepository(auth);
            String email="course-"+UUID.randomUUID()+"@example.test";
            String uid=await(cb -> repo.createAccount(email,"course-test-password",cb));
            assertEquals(uid,repo.currentUid());
            repo.signOut(); assertNull(repo.currentUid());
            assertEquals(uid,await(cb -> repo.signIn(email,"course-test-password",cb)));
        } finally { app.delete(); }
    }
    private interface Operation { void run(MultiplayerRepository.ResultCallback<String> callback); }
    private static String await(Operation operation) throws Exception {
        CountDownLatch done=new CountDownLatch(1);
        AtomicReference<String> value=new AtomicReference<>(),error=new AtomicReference<>();
        operation.run(new MultiplayerRepository.ResultCallback<String>() {
            public void onSuccess(String result) { value.set(result);done.countDown(); }
            public void onError(RepositoryError failure) { error.set(failure.getMessage());done.countDown(); }
        });
        assertTrue("Auth callback timed out",done.await(20,TimeUnit.SECONDS));
        assertNull(error.get(),error.get());return value.get();
    }
}
