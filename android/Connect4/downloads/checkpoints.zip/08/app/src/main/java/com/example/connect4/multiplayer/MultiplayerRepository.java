package com.example.connect4.multiplayer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/** Owns Firebase authentication and closes its listeners explicitly. */
public final class MultiplayerRepository {
    private final FirebaseAuth auth;
    /** Uses the app registered by the teacher. */
    public MultiplayerRepository() { this(FirebaseAuth.getInstance()); }
    /** Allows isolated Auth emulator instances in tests. */
    public MultiplayerRepository(FirebaseAuth auth) { this.auth=auth; }

    /** Returns the authenticated Firebase user's UID, or {@code null} when signed out. */
    public String currentUid() {
        FirebaseUser user = auth.getCurrentUser();
        return user == null ? null : user.getUid();
    }

    /** Signs in with email/password and reports the resulting UID asynchronously. */
    public void signIn(String email, String password, ResultCallback<String> callback) {
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Email and password are required", null));
            return;
        }
        auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(result -> callback.onSuccess(result.getUser().getUid()))
                .addOnFailureListener(exception -> callback.onError(firebaseError(exception, null)));
    }

    /** Creates an email/password account and reports the resulting UID asynchronously. */
    public void createAccount(String email, String password, ResultCallback<String> callback) {
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            callback.onError(error(RepositoryError.Code.INVALID_ARGUMENT,
                    "Email and password are required", null));
            return;
        }
        auth.createUserWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(result -> callback.onSuccess(result.getUser().getUid()))
                .addOnFailureListener(exception -> callback.onError(firebaseError(exception, null)));
    }

    /** Clears the current Firebase authentication session. */
    public void signOut() {
        auth.signOut();
    }

    /** Subscribes to authentication changes; callers must close the returned subscription. */
    public Subscription subscribeAuth(AuthListener listener) {
        FirebaseAuth.AuthStateListener firebaseListener = firebaseAuth -> {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            listener.onAuthChanged(user == null ? null : user.getUid());
        };
        auth.addAuthStateListener(firebaseListener);
        return once(() -> auth.removeAuthStateListener(firebaseListener));
    }

    private static RepositoryError firebaseError(Exception exception, String roomId) {
        String message = exception == null || exception.getLocalizedMessage() == null
                ? "Firebase operation failed" : exception.getLocalizedMessage();
        return error(RepositoryError.Code.UNKNOWN, message, roomId);
    }

    private static RepositoryError error(RepositoryError.Code code, String message,
                                         String roomId) {
        return new RepositoryError(code, message == null ? "Operation failed" : message, roomId);
    }

    private static Subscription once(Runnable remover) {
        return new Subscription() {
            private boolean closed;

            @Override
            public synchronized void close() {
                if (!closed) {
                    closed = true;
                    remover.run();
                }
            }
        };
    }

    public interface Subscription extends AutoCloseable {
        Subscription EMPTY = () -> { };
        @Override void close();
    }
    public interface ResultCallback<T> {
        void onSuccess(T result);
        void onError(RepositoryError error);
    }
    public interface AuthListener { void onAuthChanged(String uid); }
}
