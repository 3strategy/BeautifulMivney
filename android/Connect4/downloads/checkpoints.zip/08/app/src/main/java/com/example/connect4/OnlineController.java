package com.example.connect4;

import android.view.View;
import com.example.connect4.databinding.ActivityMainBinding;
import com.example.connect4.multiplayer.*;

/** Connects the login controls to retained authentication state. */
final class OnlineController {
    interface Host { void changed(); }
    private final ActivityMainBinding ui;
    private final GameSession session;
    private final Host host;
    private boolean active;
    private MultiplayerRepository.Subscription auth = MultiplayerRepository.Subscription.EMPTY;
    private final Runnable refreshCallback = this::refreshScreen;

    OnlineController(android.app.Activity activity, ActivityMainBinding ui, GameSession session, Host host) {
        this.ui=ui; this.session=session; this.host=host;
        ui.signIn.setOnClickListener(v -> authenticate(false));
        ui.signUp.setOnClickListener(v -> authenticate(true));
        ui.signOut.setOnClickListener(v -> {
            session.onlineGeneration++;
            if (session.repository != null) session.repository.signOut();
            refreshScreen();
        });
    }

    /** Attaches a single auth listener while the online screen is visible. */
    void start() {
        if (active || session.mode != GameSession.MODE_ONLINE) return;
        active=true;
        session.refreshOnline=refreshCallback;
        try {
            if (session.repository==null) session.repository=new MultiplayerRepository();
            auth=session.repository.subscribeAuth(uid -> {
                if (!active) return;
                session.onlineUid=uid;
                refreshScreen();
            });
        } catch (IllegalStateException failure) {
            session.onlineMessage="Firebase setup unavailable. Add the registered Connect4 google-services.json and rebuild.";
        }
        refreshScreen();
    }

    /** Releases Activity-owned callbacks without signing the user out. */
    void stop() {
        active=false;
        auth.close();
        if (session.refreshOnline==refreshCallback) session.refreshOnline=null;
    }
    void modeChanged() {
        session.onlineGeneration++;
        if (session.mode==GameSession.MODE_ONLINE) start(); else stop();
    }
    private void refreshScreen() { if (active) host.changed(); }
    private void refreshLatestScreen() { if (session.refreshOnline!=null) session.refreshOnline.run(); }
    private void showError(RepositoryError error) { session.onlineMessage=error.getMessage(); }
    void destroy() { }

    /** Shows the session's identity and enables only available actions. */
    void render() {
        boolean signedIn=session.repository!=null && session.repository.currentUid()!=null;
        ui.authPanel.setVisibility(signedIn ? View.GONE : View.VISIBLE);
        ui.signOut.setVisibility(signedIn ? View.VISIBLE : View.GONE);
        ui.signIn.setEnabled(session.repository!=null && !session.authPending);
        ui.signUp.setEnabled(session.repository!=null && !session.authPending);
        ui.onlineStatus.setText(signedIn ? "Signed in: " + session.repository.currentUid() : session.onlineMessage);
    }

    private void authenticate(boolean create) {
        if (session.repository == null || session.authPending) return;
        session.authPending = true;
        String email = ui.email.getText().toString();
        String password = ui.password.getText().toString();
        ui.password.setText("");
        MultiplayerRepository.ResultCallback<String> callback = new MultiplayerRepository.ResultCallback<String>() {
            @Override public void onSuccess(String uid) {
                session.authPending = false;
                session.onlineMessage = "Signed in";
                refreshLatestScreen();
            }
            @Override public void onError(RepositoryError error) {
                session.authPending = false;
                showError(error);
                refreshLatestScreen();
            }
        };
        if (create) session.repository.createAccount(email, password, callback);
        else session.repository.signIn(email, password, callback);
        host.changed();
    }
}
