package com.example.connect4.multiplayer;

/** Carries a recoverable operation error to the screen. */
public final class RepositoryError {
    public enum Code { INVALID_ARGUMENT, UNKNOWN }
    private final Code code;
    private final String message;
    private final String roomId;
    RepositoryError(Code code, String message, String roomId) {
        this.code=code; this.message=message; this.roomId=roomId;
    }
    public Code getCode() { return code; }
    public String getMessage() { return message; }
    public String getRoomId() { return roomId; }
}
