package com.example.connect4;

import android.os.Bundle;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;

import com.example.connect4.databinding.ActivityMainBinding;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private GameEngine engine = new GameEngine();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        binding.board.setColumnListener(column -> {
            if (engine.apply(new GameAction(column))) render();
        });
        binding.restart.setOnClickListener(v -> {
            engine = new GameEngine();
            render();
        });
        render();
    }
    /** Presents the model; drawing does not change the game. */
    private void render() {
        GameState state = engine.snapshot();
        binding.board.show(state);
        if (state.isDraw()) binding.status.setText("Draw — board full");
        else if (state.isTerminal()) binding.status.setText(state.winner() == GameState.RED ? "Red wins!" : "Yellow wins!");
        else binding.status.setText(state.currentPlayer() == GameState.RED ? "Red to play" : "Yellow to play");
    }
}
