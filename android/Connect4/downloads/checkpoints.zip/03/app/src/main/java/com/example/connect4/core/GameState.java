package com.example.connect4.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** Immutable, detached snapshot of a Connect Four position. */
public final class GameState {
    public static final int ROWS = 6;
    public static final int COLUMNS = 7;
    public static final int EMPTY = 0;
    public static final int RED = 1;
    public static final int YELLOW = 2;

    private final int[][] board;
    private final int currentPlayer;
    private final int winner;
    private final boolean terminal;
    private final String moves;
    private final List<Cell> winningCells;

    GameState(
            int[][] board,
            int currentPlayer,
            int winner,
            boolean terminal,
            String moves,
            List<Cell> winningCells) {
        this.board = copyBoard(board);
        this.currentPlayer = currentPlayer;
        this.winner = winner;
        this.terminal = terminal;
        this.moves = Objects.requireNonNull(moves, "moves");
        this.winningCells = Collections.unmodifiableList(new ArrayList<>(winningCells));
    }

    /** Returns the occupant at a zero-based board coordinate. */
    public int cell(int row, int column) {
        checkCoordinates(row, column);
        return board[row][column];
    }

    /** Returns the player whose turn is next, even after a terminal move. */
    public int currentPlayer() {
        return currentPlayer;
    }

    /** Returns 0 when no player has won, including for an unfinished game or draw. */
    public int winner() {
        return winner;
    }

    /** Reports whether no more moves may be applied to this snapshot. */
    public boolean isTerminal() {
        return terminal;
    }

    /** Reports a terminal state with no winning player. */
    public boolean isDraw() {
        return terminal && winner == EMPTY;
    }

    /** Successful zero-based column actions, concatenated without separators. */
    public String moves() {
        return moves;
    }

    /** Returns the number of accepted moves represented by this state. */
    public int moveCount() {
        return moves.length();
    }

    /** Returns all cells participating in one or more winning four-in-a-row lines. */
    public List<Cell> winningCells() {
        return winningCells;
    }

    /** Legal actions in ascending-column order. Terminal positions have no actions. */
    public List<GameAction> legalActions() {
        if (terminal) {
            return Collections.emptyList();
        }
        List<GameAction> actions = new ArrayList<>(COLUMNS);
        for (int column = 0; column < COLUMNS; column++) {
            if (board[0][column] == EMPTY) {
                actions.add(new GameAction(column));
            }
        }
        return Collections.unmodifiableList(actions);
    }

    /** Returns a deep copy so callers cannot mutate this immutable snapshot. */
    public int[][] boardCopy() {
        return copyBoard(board);
    }

    private static int[][] copyBoard(int[][] source) {
        if (source == null || source.length != ROWS) {
            throw new IllegalArgumentException("board must have 6 rows");
        }
        int[][] result = new int[ROWS][COLUMNS];
        for (int row = 0; row < ROWS; row++) {
            if (source[row] == null || source[row].length != COLUMNS) {
                throw new IllegalArgumentException("board rows must have 7 columns");
            }
            result[row] = source[row].clone();
        }
        return result;
    }

    private static void checkCoordinates(int row, int column) {
        if (row < 0 || row >= ROWS || column < 0 || column >= COLUMNS) {
            throw new IndexOutOfBoundsException("cell outside 6x7 board");
        }
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GameState)) {
            return false;
        }
        GameState state = (GameState) other;
        return currentPlayer == state.currentPlayer
                && winner == state.winner
                && terminal == state.terminal
                && moves.equals(state.moves)
                && winningCells.equals(state.winningCells)
                && Arrays.deepEquals(board, state.board);
    }

    @Override
    public int hashCode() {
        int result = Arrays.deepHashCode(board);
        result = 31 * result + Objects.hash(currentPlayer, winner, terminal, moves, winningCells);
        return result;
    }

    /** Immutable board coordinate. */
    public static final class Cell {
        private final int row;
        private final int column;

        /** Creates a coordinate inside the standard 6-by-7 board. */
        public Cell(int row, int column) {
            checkCoordinates(row, column);
            this.row = row;
            this.column = column;
        }

        /** Returns the zero-based row, measured from the board's top edge. */
        public int row() {
            return row;
        }

        /** Returns the zero-based column, measured from the board's left edge. */
        public int column() {
            return column;
        }

        @Override
        public boolean equals(Object other) {
            if (!(other instanceof Cell)) {
                return false;
            }
            Cell cell = (Cell) other;
            return row == cell.row && column == cell.column;
        }

        @Override
        public int hashCode() {
            return Objects.hash(row, column);
        }

        @Override
        public String toString() {
            return "Cell{" + "row=" + row + ", column=" + column + '}';
        }
    }
}
