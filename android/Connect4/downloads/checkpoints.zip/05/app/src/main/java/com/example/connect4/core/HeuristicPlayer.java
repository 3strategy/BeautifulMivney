package com.example.connect4.core;

import java.util.List;

/** Deterministic fallback: win, block, then take the closest column to center. */
public final class HeuristicPlayer implements ComputerPlayer {
    private static final int[] CENTER_ORDER = {3, 2, 4, 1, 5, 0, 6};

    @Override
    public GameAction chooseAction(GameState state) {
        if (state == null) {
            throw new NullPointerException("state");
        }
        List<GameAction> legal = state.legalActions();
        if (legal.isEmpty()) {
            throw new IllegalArgumentException("Cannot choose an action without a legal move");
        }

        GameAction winning = immediateWinningAction(state, state.currentPlayer());
        if (winning != null) {
            return winning;
        }
        int opponent = state.currentPlayer() == GameState.RED ? GameState.YELLOW : GameState.RED;
        GameAction blocking = immediateWinningAction(state, opponent);
        if (blocking != null) {
            return blocking;
        }
        for (int column : CENTER_ORDER) {
            GameAction action = new GameAction(column);
            if (legal.contains(action)) {
                return action;
            }
        }
        throw new IllegalStateException("No preferred column matched a legal action");
    }

    /** Returns null when this side has no immediate winning action. */
    private static GameAction immediateWinningAction(GameState state, int player) {
        for (GameAction action : state.legalActions()) {
            if (GameEngine.wouldWin(state, action, player)) {
                return action;
            }
        }
        return null;
    }
}
