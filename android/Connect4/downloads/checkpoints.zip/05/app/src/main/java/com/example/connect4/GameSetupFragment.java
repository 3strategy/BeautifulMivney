package com.example.connect4;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import androidx.fragment.app.Fragment;
import com.example.connect4.databinding.FragmentGameSetupBinding;
import java.util.function.IntConsumer;

/** Owns the setup controls; the activity owns game state and responds to selections. */
public class GameSetupFragment extends Fragment {
    interface Listener {
        void onModeSelected(int position);
        void onSideSelected(int position);
    }

    private FragmentGameSetupBinding binding;
    private Listener listener;
    private boolean configured;
    private int mode;
    private int side;

    @Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle state) {
        binding = FragmentGameSetupBinding.inflate(inflater, container, false);
        if (configured) bindControls();
        return binding.getRoot();
    }

    void configure(int mode, int side, Listener listener) {
        this.listener = listener;
        configured = true;
        this.mode = mode;
        this.side = side;
        // Restored fragments can receive configuration before their view is recreated.
        if (binding != null) bindControls();
    }

    private void bindControls() {
        binding.mode.setAdapter(adapter(getResources().getStringArray(R.array.game_modes)));
        binding.side.setAdapter(adapter(getResources().getStringArray(R.array.player_sides)));
        binding.mode.setSelection(mode);
        binding.side.setSelection(side);
        binding.mode.setOnItemSelectedListener(selection(position -> this.listener.onModeSelected(position)));
        binding.side.setOnItemSelectedListener(selection(position -> this.listener.onSideSelected(position)));
        showMode(mode);
    }

    void showMode(int mode) {
        this.mode = mode;
        if (binding == null) return;
        binding.side.setVisibility(mode == GameSession.MODE_HEURISTIC ? View.VISIBLE : View.GONE);
    }

    private ArrayAdapter<String> adapter(String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), R.layout.spinner_item, items);
        adapter.setDropDownViewResource(R.layout.spinner_item);
        return adapter;
    }

    private AdapterView.OnItemSelectedListener selection(IntConsumer action) {
        return new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (listener != null) action.accept(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        };
    }

    FragmentGameSetupBinding viewBinding() { return binding; }

    @Override public void onDestroyView() {
        listener = null;
        binding = null;
        super.onDestroyView();
    }
}
