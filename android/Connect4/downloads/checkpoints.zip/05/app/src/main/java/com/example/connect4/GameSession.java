package com.example.connect4;

import androidx.lifecycle.ViewModel;
import com.example.connect4.core.GameEngine;

/** Retains the game across Activity recreation, without keeping a View or Activity. */
public final class GameSession extends ViewModel {
    public static final int MODE_LOCAL = 0;
    public static final int MODE_HEURISTIC = 1;
    public int mode = MODE_LOCAL;
    public int humanSide = com.example.connect4.core.GameState.RED;
    public GameEngine engine = new GameEngine();
    public boolean restored;
}
