package com.example.connect4.core;

/** A replaceable computer opponent. Human input and online transport use other paths. */
@FunctionalInterface
public interface ComputerPlayer {
    /**
     * Chooses one legal action for the player to move in this detached snapshot.
     * The caller runs this blocking calculation on a worker thread, then checks
     * that the turn is still current before applying the action to the live engine.
     * Implementations must not mutate the live game or access Android views.
     *
     * @throws IllegalArgumentException if the snapshot has no legal actions
     * @throws java.util.concurrent.CancellationException if calculation is interrupted
     */
    GameAction chooseAction(GameState snapshot);
}
