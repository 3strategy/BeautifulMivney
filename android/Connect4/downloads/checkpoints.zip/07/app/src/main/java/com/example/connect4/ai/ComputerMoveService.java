package com.example.connect4.ai;

import android.content.Context;
import com.example.connect4.core.ComputerPlayer;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameState;
import com.example.connect4.core.HeuristicPlayer;
import com.example.connect4.core.MctsPlayer;
import java.util.concurrent.CancellationException;

/**
 * Connects an opponent, asks for one action, and returns the action with its status.
 * All methods run synchronously on the computer worker, never on the UI thread.
 * Only the controller may apply the returned action to the live game.
 */
public final class ComputerMoveService {
    private ComputerMoveService() { }

    public static Result chooseHeuristicMove(GameState snapshot) {
        return new Result(chooseLegalAction(new HeuristicPlayer(), snapshot),
                "Heuristic · win, block, then center");
    }

    /** Opens, validates, uses and closes one model on the same worker thread. */
    public static Result chooseModelMove(
            Context context, ModelCatalog.Entry model, GameState snapshot, int simulations) {
        if (simulations < 1) throw new IllegalArgumentException("simulations must be positive");
        if (snapshot.legalActions().isEmpty()) {
            throw new IllegalArgumentException("Cannot request a move without a legal action");
        }
        throwIfInterrupted();
        try (TfliteEvaluator evaluator = new TfliteEvaluator(context, model.assets())) {
            ComputerPlayer player = new MctsPlayer(evaluator, simulations);
            GameAction action = chooseLegalAction(player, snapshot);
            return new Result(action, evaluator.modelDescription()
                    + " · MCTS " + simulations + " simulations");
        } catch (CancellationException cancelled) {
            // Restart/backgrounding is not a broken model and must not produce a fallback move.
            throw cancelled;
        } catch (Exception | LinkageError failure) {
            throwIfInterrupted();
            String reason = failure.getMessage();
            if (reason == null || reason.isEmpty()) reason = failure.getClass().getSimpleName();
            return new Result(chooseLegalAction(new HeuristicPlayer(), snapshot),
                    model.displayName() + " · Heuristic fallback · " + reason);
        }
    }

    private static GameAction chooseLegalAction(ComputerPlayer player, GameState snapshot) {
        throwIfInterrupted();
        GameAction action = player.chooseAction(snapshot);
        throwIfInterrupted();
        if (!snapshot.legalActions().contains(action)) {
            throw new IllegalStateException("Computer player returned an illegal action");
        }
        return action;
    }

    private static void throwIfInterrupted() {
        if (Thread.currentThread().isInterrupted()) {
            throw new CancellationException("Computer move cancelled");
        }
    }

    /** One completed calculation; model scores never cross the controller boundary. */
    public static final class Result {
        private final GameAction action;
        private final String status;

        private Result(GameAction action, String status) {
            this.action = action;
            this.status = status;
        }

        public GameAction action() { return action; }

        public String status() { return status; }
    }
}
