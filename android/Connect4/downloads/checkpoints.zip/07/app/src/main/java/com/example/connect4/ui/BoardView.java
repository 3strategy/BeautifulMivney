package com.example.connect4.ui;

import com.example.connect4.core.GameState;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Draws a six-by-seven board and reports column taps to its controller. */
public final class BoardView extends View {
    private static final int ROWS = GameState.ROWS;
    private static final int COLUMNS = GameState.COLUMNS;
    private GameState state;
    private boolean inputEnabled;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ColumnListener listener;

    /** Receives a zero-based column; the View does not apply game rules. */
    public interface ColumnListener { void onColumn(int column); }

    /** Called by Android when the custom View is inflated from XML. */
    public BoardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setContentDescription("Connect Four board. Tap a column to drop a disc.");
    }

    /** Connects the Activity's response to a board tap. */
    public void setColumnListener(ColumnListener listener) { this.listener = listener; }

    /** Replaces the snapshot and requests a redraw. */
    public void show(GameState state, boolean enabled) {
        inputEnabled = enabled;
        this.state = state;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float size = cellSize();
        paint.setColor(0xff1565c0);
        canvas.drawRect(0, 0, size * COLUMNS, size * ROWS, paint);
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMNS; column++) {
                int player = state == null ? GameState.EMPTY : state.cell(row, column);
                paint.setColor(player == GameState.RED ? 0xffd32f2f
                        : player == GameState.YELLOW ? 0xffffc107 : 0xffeeeeee);
                canvas.drawCircle((column + .5f) * size, (row + .5f) * size,
                        size * .38f, paint);
                if (state != null) {
                    for (GameState.Cell cell : state.winningCells()) {
                        if (cell.row() == row && cell.column() == column) {
                            paint.setStyle(Paint.Style.STROKE);
                            paint.setStrokeWidth(size * .07f);
                            paint.setColor(0xffffffff);
                            canvas.drawCircle((column + .5f) * size, (row + .5f) * size,
                                    size * .29f, paint);
                            paint.setStyle(Paint.Style.FILL);
                        }
                    }
                }
            }
        }
    }

    /** Uses the same geometry for drawing and hit testing. */
    private float cellSize() {
        return Math.min(getWidth() / (float) COLUMNS, getHeight() / (float) ROWS);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!inputEnabled) return false;
        if (event.getAction() == MotionEvent.ACTION_UP) {
            float size = cellSize();
            float x = event.getX(), y = event.getY();
            if (size > 0 && x >= 0 && x < size * COLUMNS && y >= 0 && y < size * ROWS) {
                performClick();
                if (listener != null) listener.onColumn((int) (x / size));
            }
        }
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}
