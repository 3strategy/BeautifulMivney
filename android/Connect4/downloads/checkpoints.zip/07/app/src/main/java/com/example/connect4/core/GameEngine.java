package com.example.connect4.core;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The authoritative mutable Connect Four rules engine. */
public final class GameEngine {
    private final int[][] board;
    private final StringBuilder moves;
    private int currentPlayer;
    private int winner;
    private boolean terminal;
    private List<GameState.Cell> winningCells;

    /** Creates a new empty game with Red to move first. */
    public GameEngine() {
        board = new int[GameState.ROWS][GameState.COLUMNS];
        moves = new StringBuilder();
        currentPlayer = GameState.RED;
        winner = GameState.EMPTY;
        winningCells = new ArrayList<>();
    }

    /**
     * Copies a trusted, immutable snapshot for restoration or search.
     * GameState is constructed inside core; untrusted saved/network move histories
     * must instead be replayed through apply(), as RoomValidation does.
     */
    public GameEngine(GameState state) {
        if (state == null) {
            throw new NullPointerException("state");
        }
        board = state.boardCopy();
        moves = new StringBuilder(state.moves());
        currentPlayer = state.currentPlayer();
        winner = state.winner();
        terminal = state.isTerminal();
        winningCells = new ArrayList<>(state.winningCells());
    }

    /** Returns a detached immutable snapshot suitable for rendering or AI simulation. */
    public GameState snapshot() {
        return new GameState(
                board,
                currentPlayer,
                winner,
                terminal,
                moves.toString(),
                winningCells);
    }

    /**
     * Applies a legal action and returns true. Invalid, full-column, and terminal
     * actions return false without changing the game.
     */
    // TWIN-ID: CONNECT4.APPLY_MOVE (TWIN-PYTHON: ml/game_env.py::apply_move)
    public boolean apply(GameAction action) {
        if (action == null || terminal) {
            return false;
        }
        int column = action.column();
        if (column < 0 || column >= GameState.COLUMNS) {
            return false;
        }
        int landingRow = findLandingRow(board, column);
        if (landingRow < 0) {
            return false;
        }

        int movingPlayer = currentPlayer;
        board[landingRow][column] = movingPlayer;
        moves.append(column);
        currentPlayer = opponent(movingPlayer);

        winningCells = findWinningCells(board, movingPlayer);
        if (!winningCells.isEmpty()) {
            winner = movingPlayer;
            terminal = true;
        } else if (moves.length() == GameState.ROWS * GameState.COLUMNS) {
            // TWIN-ID: CONNECT4.TERMINAL_CHECK (TWIN-PYTHON: ml/game_env.py::is_terminal)
            terminal = true;
        }
        return true;
    }

    /**
     * Tests a hypothetical drop for either side without changing the snapshot.
     * The heuristic uses this for both winning moves and opponent threats, so
     * gravity and win detection remain the same rules used by apply().
     */
    public static boolean wouldWin(GameState state, GameAction action, int player) {
        if (player != GameState.RED && player != GameState.YELLOW) {
            throw new IllegalArgumentException("player must be Red or Yellow");
        }
        if (state.isTerminal() || action == null
                || action.column() < 0 || action.column() >= GameState.COLUMNS) {
            return false;
        }
        int[][] board = state.boardCopy();
        int row = findLandingRow(board, action.column());
        if (row < 0) {
            return false;
        }
        board[row][action.column()] = player;
        return !findWinningCells(board, player).isEmpty();
    }

    private static int findLandingRow(int[][] board, int column) {
        for (int row = GameState.ROWS - 1; row >= 0; row--) {
            if (board[row][column] == GameState.EMPTY) {
                return row;
            }
        }
        return -1;
    }

    private static int opponent(int player) {
        return player == GameState.RED ? GameState.YELLOW : GameState.RED;
    }

    // TWIN-ID: CONNECT4.WIN_CHECK (TWIN-PYTHON: ml/game_env.py::winner)
    private static List<GameState.Cell> findWinningCells(int[][] board, int player) {
        int[][] directions = {{0, 1}, {1, 0}, {1, 1}, {1, -1}};
        Set<GameState.Cell> result = new LinkedHashSet<>();
        for (int[] direction : directions) {
            int rowStep = direction[0];
            int columnStep = direction[1];
            for (int row = 0; row < GameState.ROWS; row++) {
                for (int column = 0; column < GameState.COLUMNS; column++) {
                    int endRow = row + 3 * rowStep;
                    int endColumn = column + 3 * columnStep;
                    if (endRow < 0 || endRow >= GameState.ROWS
                            || endColumn < 0 || endColumn >= GameState.COLUMNS) {
                        continue;
                    }
                    boolean connected = true;
                    for (int offset = 0; offset < 4; offset++) {
                        if (board[row + offset * rowStep][column + offset * columnStep]
                                != player) {
                            connected = false;
                            break;
                        }
                    }
                    if (connected) {
                        for (int offset = 0; offset < 4; offset++) {
                            result.add(new GameState.Cell(
                                    row + offset * rowStep,
                                    column + offset * columnStep));
                        }
                    }
                }
            }
        }
        return new ArrayList<>(result);
    }
}
