package com.example.connect4.ai;

import com.example.connect4.core.ComputerPlayer;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameState;
import com.example.connect4.core.HeuristicPlayer;
import java.util.concurrent.CancellationException;

/**
 * Connects an opponent, asks for one action, and returns the action with its status.
 * All methods run synchronously on the computer worker, never on the UI thread.
 * Only the controller may apply the returned action to the live game.
 */
public final class ComputerMoveService {
    private ComputerMoveService() { }

    public static Result chooseHeuristicMove(GameState snapshot) {
        return new Result(chooseLegalAction(new HeuristicPlayer(), snapshot),
                "Heuristic · win, block, then center");
    }

    private static GameAction chooseLegalAction(ComputerPlayer player, GameState snapshot) {
        throwIfInterrupted();
        GameAction action = player.chooseAction(snapshot);
        throwIfInterrupted();
        if (!snapshot.legalActions().contains(action)) {
            throw new IllegalStateException("Computer player returned an illegal action");
        }
        return action;
    }

    private static void throwIfInterrupted() {
        if (Thread.currentThread().isInterrupted()) {
            throw new CancellationException("Computer move cancelled");
        }
    }

    /** One completed calculation; model scores never cross the controller boundary. */
    public static final class Result {
        private final GameAction action;
        private final String status;

        private Result(GameAction action, String status) {
            this.action = action;
            this.status = status;
        }

        public GameAction action() { return action; }

        public String status() { return status; }
    }
}
