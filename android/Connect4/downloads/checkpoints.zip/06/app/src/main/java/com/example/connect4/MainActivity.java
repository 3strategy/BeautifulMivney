package com.example.connect4;

import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;
import com.example.connect4.ai.ComputerMoveService;

import com.example.connect4.databinding.ActivityMainBinding;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private GameSession session;
    private GameSetupFragment setup;
    private boolean started;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        session = new ViewModelProvider(this).get(GameSession.class);
        setup = (GameSetupFragment) getSupportFragmentManager().findFragmentById(R.id.gameSetup);
        if (!session.restored) {
            session.mode = getPreferences(MODE_PRIVATE).getInt("mode", GameSession.MODE_LOCAL);
            if (session.mode < 0 || session.mode > GameSession.MODE_HEURISTIC) session.mode = GameSession.MODE_LOCAL;
            session.humanSide = getPreferences(MODE_PRIVATE).getInt("side", GameState.RED);
            if (session.humanSide != GameState.RED && session.humanSide != GameState.YELLOW) session.humanSide = GameState.RED;
            String moves = getPreferences(MODE_PRIVATE).getString("moves", "");
            GameEngine restored = new GameEngine();
            for (int i = 0; i < moves.length(); i++) {
                if (!restored.apply(new GameAction(moves.charAt(i) - '0'))) break;
            }
            session.engine = restored;
            session.restored = true;
        }
        setup.configure(session.mode, session.humanSide - 1, new GameSetupFragment.Listener() {
            @Override public void onModeSelected(int position) {
                if (session.mode != position) { session.mode = position; newGame(); }
                setup.showMode(session.mode);
            }
            @Override public void onSideSelected(int position) {
                if (session.humanSide != position + 1) { session.humanSide = position + 1; newGame(); }
            }
        });
        binding.board.setColumnListener(column -> {
            if (!humanTurn()) return;
            if (session.engine.apply(new GameAction(column))) { persist(); render(); }
        });
        binding.restart.setOnClickListener(v -> newGame());
        render();
    }
    /** Resets the game after changing a player or pressing New game. */
    private void newGame() {
        session.cancelComputerMove();
        session.engine = new GameEngine();
        persist();
        render();
    }

    private boolean humanTurn() {
        return started && !session.isComputerThinking() && !session.engine.snapshot().isTerminal()
                && (session.mode == GameSession.MODE_LOCAL
                || session.engine.snapshot().currentPlayer() == session.humanSide);
    }

    /** Presents the model; drawing does not change the game. */
    private void render() {
        GameState state = session.engine.snapshot();
        binding.board.show(state);
        if (state.isDraw()) binding.status.setText("Draw — board full");
        else if (state.isTerminal()) binding.status.setText(state.winner() == GameState.RED ? "Red wins!" : "Yellow wins!");
        else binding.status.setText(state.currentPlayer() == GameState.RED ? "Red to play" : "Yellow to play");
        if (session.isComputerThinking()) binding.status.setText("Computer is thinking…");
        binding.aiStatus.setText(session.modelStatus);
        requestComputerMoveIfNeeded();
    }

    /** Saves only accepted column history; the engine reconstructs the rest. */
    private void persist() {
        getPreferences(MODE_PRIVATE).edit().putString("moves", session.engine.snapshot().moves())
                .putInt("mode", session.mode).putInt("side", session.humanSide).apply();
    }

    @Override protected void onStart() { super.onStart(); started = true; render(); }

    @Override protected void onStop() {
        started = false;
        session.cancelComputerMove();
        persist();
        super.onStop();
    }

    ActivityMainBinding viewBinding() { return binding; }
    com.example.connect4.databinding.FragmentGameSetupBinding setupBinding() { return setup.viewBinding(); }

    /** Captures one position; the worker never receives the live engine. */
    private void requestComputerMoveIfNeeded() {
        GameState requestedState = session.engine.snapshot();
        if (!started || session.mode == GameSession.MODE_LOCAL || requestedState.isTerminal()
                || session.isComputerThinking() || session.hasComputerMoveFailed()
                || requestedState.currentPlayer() == session.humanSide) return;
        binding.status.setText("Computer is thinking…");
        session.requestComputerMove(
                () -> ComputerMoveService.chooseHeuristicMove(requestedState),
                result -> applyComputerMove(requestedState, result),
                failure -> { session.modelStatus = "Computer move failed · " + failure.getMessage(); render(); });
    }

    /** Accepts only a result for the still-current position, on the main thread. */
    private void applyComputerMove(GameState requestedState, ComputerMoveService.Result result) {
        if (!started || !requestedState.equals(session.engine.snapshot())) return;
        if (!session.engine.apply(result.action())) throw new IllegalStateException("Illegal computer action");
        session.modelStatus = result.status();
        persist();
        render();
    }
}
