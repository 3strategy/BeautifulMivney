package com.example.connect4;
import android.content.Context;
import android.view.MotionEvent;
import android.widget.TextView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import com.example.connect4.ui.BoardView;

/** Exercises real input -> Activity -> engine -> rendered outcome. */
@RunWith(AndroidJUnit4.class)
public class CourseFlowTest {
    @Test public void verticalWinBlocksFurtherInputAndRestarts() {
        ApplicationProvider.<Context>getApplicationContext()
                .getSharedPreferences("MainActivity", Context.MODE_PRIVATE).edit().clear().commit();
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> {
                BoardView board = activity.findViewById(R.id.board);
                float size = Math.min(board.getWidth()/7f,board.getHeight()/6f);
                assertTrue("Board must be laid out", size > 0);
                for (char col : "0101010".toCharArray()) tap(board,(col-'0'+.5f)*size,size/2);
                TextView status = activity.findViewById(R.id.status);
                assertEquals("Red wins!",status.getText().toString());
                tap(board,3.5f*size,size/2);
                assertEquals("Red wins!",status.getText().toString());
                activity.findViewById(R.id.restart).performClick();
                assertEquals("Red to play",status.getText().toString());
            });
        }
    }
    private static void tap(BoardView board,float x,float y) {
        MotionEvent event=MotionEvent.obtain(0,0,MotionEvent.ACTION_UP,x,y,0);
        try { board.dispatchTouchEvent(event); } finally { event.recycle(); }
    }
}
