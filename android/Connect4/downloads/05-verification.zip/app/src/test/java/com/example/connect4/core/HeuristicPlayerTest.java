package com.example.connect4.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

public class HeuristicPlayerTest {
    private final HeuristicPlayer player = new HeuristicPlayer();

    @Test
    public void takesImmediateWinBeforeAnyOtherPreference() {
        assertEquals(new GameAction(0), player.chooseAction(play("010101")));
    }

    @Test
    public void blocksImmediateOpponentWin() {
        assertEquals(new GameAction(0), player.chooseAction(play("01010")));
    }

    @Test
    public void prefersCenterThenDeterministicallyMovesOutward() {
        assertEquals(new GameAction(3), player.chooseAction(new GameEngine().snapshot()));
        assertEquals(new GameAction(2), player.chooseAction(play("333333")));
    }

    @Test
    public void rejectsTerminalState() {
        assertThrows(IllegalArgumentException.class,
                () -> player.chooseAction(play("0101010")));
    }

    private static GameState play(String moves) {
        GameEngine engine = new GameEngine();
        for (int index = 0; index < moves.length(); index++) {
            engine.apply(new GameAction(moves.charAt(index) - '0'));
        }
        return engine.snapshot();
    }
}
