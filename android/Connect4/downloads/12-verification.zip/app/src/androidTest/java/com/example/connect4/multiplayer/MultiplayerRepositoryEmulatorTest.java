package com.example.connect4.multiplayer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.junit.After;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

@RunWith(AndroidJUnit4.class)
public class MultiplayerRepositoryEmulatorTest {
    private static final String HOST = "10.0.2.2";
    private static final String PASSWORD = "connect4-test-password";
    private static final String DEMO_DATABASE_URL =
            "https://demo-connect4-default-rtdb.firebaseio.com";
    private final List<FirebaseApp> testApps = new ArrayList<>();

    private Client red;
    private Client yellowCandidate;
    private Client spectatorCandidate;
    private Client secondRedSession;

    @Before
    public void setUp() throws Exception {
        Assume.assumeTrue("opt-in Firebase emulator test",
                Boolean.parseBoolean(InstrumentationRegistry.getArguments().getString("firebaseEmulators", "false")));
        String run = UUID.randomUUID().toString();
        red = client("red-" + run, "red-" + run + "@example.test");
        yellowCandidate = client("yellow-" + run, "yellow-" + run + "@example.test");
        spectatorCandidate = client("spectator-" + run,
                "spectator-" + run + "@example.test");
        secondRedSession = client("red2-" + run, red.email);

        MultiplayerRepositoryEmulatorTest.<String>await(
                callback -> red.repository.createAccount(red.email, PASSWORD, callback));
        MultiplayerRepositoryEmulatorTest.<String>await(callback -> yellowCandidate.repository.createAccount(
                yellowCandidate.email, PASSWORD, callback));
        MultiplayerRepositoryEmulatorTest.<String>await(callback -> spectatorCandidate.repository.createAccount(
                spectatorCandidate.email, PASSWORD, callback));
        MultiplayerRepositoryEmulatorTest.<String>await(
                callback -> secondRedSession.repository.signIn(red.email, PASSWORD, callback));
    }

    @After
    public void tearDown() {
        for (FirebaseApp app : testApps) {
            app.delete();
        }
        testApps.clear();
    }

    @Test
    public void concurrentJoinReturningRolesAndMoveRaceStayConsistent() throws Exception {
        String roomId = await(callback -> red.repository.createRoom(
                "Repository emulator test", callback));
        RoomSnapshot waiting = await(callback -> red.repository.getRoom(roomId, callback));
        assertEquals(RoomStatus.WAITING, waiting.getStatus());
        assertEquals(RoomRole.RED, waiting.getRole());

        AsyncResult<RoomRole> firstClaim = begin(callback ->
                yellowCandidate.repository.joinRoom(roomId, callback));
        AsyncResult<RoomRole> secondClaim = begin(callback ->
                spectatorCandidate.repository.joinRoom(roomId, callback));
        RoomRole firstRole = firstClaim.await();
        RoomRole secondRole = secondClaim.await();
        assertTrue((firstRole == RoomRole.YELLOW && secondRole == RoomRole.SPECTATOR)
                || (firstRole == RoomRole.SPECTATOR && secondRole == RoomRole.YELLOW));

        Client yellow = firstRole == RoomRole.YELLOW ? yellowCandidate : spectatorCandidate;
        Client spectator = firstRole == RoomRole.SPECTATOR
                ? yellowCandidate : spectatorCandidate;
        assertEquals(RoomRole.RED,
                MultiplayerRepositoryEmulatorTest.<RoomRole>await(
                        callback -> red.repository.joinRoom(roomId, callback)));
        assertEquals(RoomRole.YELLOW,
                MultiplayerRepositoryEmulatorTest.<RoomRole>await(
                        callback -> yellow.repository.joinRoom(roomId, callback)));
        assertEquals(RoomRole.SPECTATOR,
                MultiplayerRepositoryEmulatorTest.<RoomRole>await(
                        callback -> spectator.repository.joinRoom(roomId, callback)));

        assertEquals("3", MultiplayerRepositoryEmulatorTest.<String>await(
                callback -> red.repository.submitMove(
                roomId, 3, "", callback)));
        assertEquals("34", MultiplayerRepositoryEmulatorTest.<String>await(
                callback -> yellow.repository.submitMove(
                roomId, 4, "3", callback)));

        AsyncResult<String> moveA = begin(callback -> red.repository.submitMove(
                roomId, 2, "34", callback));
        AsyncResult<String> moveB = begin(callback -> secondRedSession.repository.submitMove(
                roomId, 5, "34", callback));
        int accepted = moveA.successCount() + moveB.successCount();
        assertEquals(1, accepted);

        RoomSnapshot finalRoom = await(callback -> red.repository.getRoom(roomId, callback));
        assertTrue(finalRoom.getRoom().getMoves().equals("342")
                || finalRoom.getRoom().getMoves().equals("345"));
    }

    @Test
    public void completeGameConvergesForPlayersAndSpectator() throws Exception {
        String id=await(cb -> red.repository.createRoom("Course complete game",cb));
        assertEquals(RoomRole.YELLOW, MultiplayerRepositoryEmulatorTest.<RoomRole>await(cb -> yellowCandidate.repository.joinRoom(id,cb)));
        assertEquals(RoomRole.SPECTATOR, MultiplayerRepositoryEmulatorTest.<RoomRole>await(cb -> spectatorCandidate.repository.joinRoom(id,cb)));
        CountDownLatch endings=new CountDownLatch(3);
        List<MultiplayerRepository.Subscription> subscriptions=new ArrayList<>();
        List<AtomicReference<RoomSnapshot>> observed=new ArrayList<>();
        for(Client client:new Client[]{red,yellowCandidate,spectatorCandidate}) {
            AtomicReference<RoomSnapshot> latest=new AtomicReference<>();
            observed.add(latest);
            subscriptions.add(client.repository.subscribeRoom(id,new MultiplayerRepository.RoomListener(){
                public void onRoom(RoomSnapshot room) {
                    RoomSnapshot previous=latest.getAndSet(room);
                    if(room.getGameState().isTerminal() && (previous==null || !previous.getGameState().isTerminal())) endings.countDown();
                }
                public void onError(RepositoryError error) { }
            }));
        }
        try {
            String history="";
            for(char column:"0011223".toCharArray()) {
                String expected=history;
                Client player=history.length()%2==0 ? red : yellowCandidate;
                history=await(cb -> player.repository.submitMove(id,column-'0',expected,cb));
            }
            assertTrue("All clients must observe the win",endings.await(15,TimeUnit.SECONDS));
            for(AtomicReference<RoomSnapshot> observedRoom:observed) {
                assertEquals("0011223",observedRoom.get().getRoom().getMoves());
                assertEquals(1,observedRoom.get().getGameState().winner());
            }
            AsyncResult<String> spectatorMove=begin(cb -> spectatorCandidate.repository.submitMove(id,4,"0011223",cb));
            assertEquals(0,spectatorMove.successCount());
        } finally { for(MultiplayerRepository.Subscription subscription:subscriptions) subscription.close(); }
    }

    @Test
    public void reconnectObservesRemoteMoveAndRejectsOldPrefix() throws Exception {
        String id=await(cb -> red.repository.createRoom("Course reconnect",cb));
        MultiplayerRepositoryEmulatorTest.<RoomRole>await(cb -> yellowCandidate.repository.joinRoom(id,cb));
        assertEquals("3",MultiplayerRepositoryEmulatorTest.<String>await(cb -> red.repository.submitMove(id,3,"",cb)));
        CountDownLatch connected=new CountDownLatch(1),disconnected=new CountDownLatch(1),updated=new CountDownLatch(1);
        java.util.concurrent.atomic.AtomicBoolean goingOffline=new java.util.concurrent.atomic.AtomicBoolean();
        MultiplayerRepository.Subscription connection=red.repository.subscribeConnection(new MultiplayerRepository.ConnectionListener(){
            public void onConnectionChanged(boolean online) {
                if(online) connected.countDown();
                else if(goingOffline.get()) disconnected.countDown();
            }
            public void onError(RepositoryError error) { }
        });
        MultiplayerRepository.Subscription room=red.repository.subscribeRoom(id,new MultiplayerRepository.RoomListener(){
            public void onRoom(RoomSnapshot snapshot) { if("34".equals(snapshot.getRoom().getMoves())) updated.countDown(); }
            public void onError(RepositoryError error) { }
        });
        try {
            assertTrue(connected.await(10,TimeUnit.SECONDS));
            goingOffline.set(true);red.database.goOffline();
            assertTrue(disconnected.await(10,TimeUnit.SECONDS));
            assertEquals("34",MultiplayerRepositoryEmulatorTest.<String>await(cb -> yellowCandidate.repository.submitMove(id,4,"3",cb)));
            red.database.goOnline();
            assertEquals("34",MultiplayerRepositoryEmulatorTest.<RoomSnapshot>await(cb -> red.repository.getRoom(id,cb)).getRoom().getMoves());
            assertTrue("Reconnected listener must receive server history",updated.await(15,TimeUnit.SECONDS));
            assertEquals(0,MultiplayerRepositoryEmulatorTest.<String>begin(cb -> red.repository.submitMove(id,2,"3",cb)).successCount());
        } finally { red.database.goOnline();connection.close();room.close(); }
    }

    private Client client(String appName, String email) {
        Context context = ApplicationProvider.getApplicationContext();
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey("fake-api-key-" + appName)
                .setApplicationId("1:1234567890:android:connect4test")
                .setProjectId("demo-connect4")
                .setDatabaseUrl(DEMO_DATABASE_URL)
                .build();
        FirebaseApp app = FirebaseApp.initializeApp(
                context, options, "connect4-test-" + appName);
        testApps.add(app);
        FirebaseAuth auth = FirebaseAuth.getInstance(app);
        FirebaseDatabase database = FirebaseDatabase.getInstance(app, DEMO_DATABASE_URL);
        auth.useEmulator(HOST, 9099);
        database.useEmulator(HOST, 9000);
        return new Client(email, new MultiplayerRepository(auth, database), database);
    }

    private static <T> T await(Consumer<MultiplayerRepository.ResultCallback<T>> operation)
            throws Exception {
        return begin(operation).await();
    }

    private static <T> AsyncResult<T> begin(
            Consumer<MultiplayerRepository.ResultCallback<T>> operation) {
        AsyncResult<T> result = new AsyncResult<>();
        operation.accept(result.callback);
        return result;
    }

    private static final class Client {
        private final String email;
        private final MultiplayerRepository repository;
        private final FirebaseDatabase database;

        private Client(String email, MultiplayerRepository repository, FirebaseDatabase database) {
            this.database = database;
            this.email = email;
            this.repository = repository;
        }
    }

    private static final class AsyncResult<T> {
        private final CountDownLatch latch = new CountDownLatch(1);
        private final AtomicReference<T> value = new AtomicReference<>();
        private final AtomicReference<RepositoryError> error = new AtomicReference<>();
        private final MultiplayerRepository.ResultCallback<T> callback =
                new MultiplayerRepository.ResultCallback<T>() {
                    @Override
                    public void onSuccess(T result) {
                        value.set(result);
                        latch.countDown();
                    }

                    @Override
                    public void onError(RepositoryError failure) {
                        error.set(failure);
                        latch.countDown();
                    }
                };

        private T await() throws Exception {
            assertTrue("Firebase callback timed out", latch.await(15, TimeUnit.SECONDS));
            assertEquals(error.get() == null ? null : error.get().getMessage(), null, error.get());
            assertNotNull(value.get());
            return value.get();
        }

        private int successCount() throws Exception {
            assertTrue("Firebase callback timed out", latch.await(15, TimeUnit.SECONDS));
            return error.get() == null && value.get() != null ? 1 : 0;
        }
    }
}
