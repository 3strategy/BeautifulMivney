package com.example.connect4.core;

/** Position scores for search, not move instructions. Contains no Android dependencies. */
public interface PolicyValueEvaluator {
    /** Evaluates a non-terminal state from its current player's perspective. */
    Evaluation evaluate(GameState state);

    /** Immutable model output: one raw score per column and a bounded position value. */
    final class Evaluation {
        private final float[] policyLogits;
        private final float value;

        /** Validates and defensively copies one model evaluation. */
        public Evaluation(float[] policyLogits, float value) {
            if (policyLogits == null || policyLogits.length != GameState.COLUMNS) {
                throw new IllegalArgumentException("policy must contain 7 logits");
            }
            for (float logit : policyLogits) {
                if (!Float.isFinite(logit)) {
                    throw new IllegalArgumentException("policy logits must be finite");
                }
            }
            if (!Float.isFinite(value) || value < -1.0f || value > 1.0f) {
                throw new IllegalArgumentException("value must be finite and in [-1, 1]");
            }
            this.policyLogits = policyLogits.clone();
            this.value = value;
        }

        public float[] policyLogits() {
            return policyLogits.clone();
        }

        public float value() {
            return value;
        }
    }
}
