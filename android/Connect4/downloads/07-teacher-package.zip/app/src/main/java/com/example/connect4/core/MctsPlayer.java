package com.example.connect4.core;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CancellationException;

/** Deterministic AlphaZero-style PUCT search over authoritative Java states. */
public final class MctsPlayer implements ComputerPlayer {
    public static final int DEFAULT_PHONE_SIMULATIONS = 128;
    private static final double DEFAULT_C_PUCT = 1.5;

    private final PolicyValueEvaluator evaluator;
    private final int simulations;
    private final double cPuct;

    /** Creates a phone-oriented search using the standard exploration constant. */
    public MctsPlayer(PolicyValueEvaluator evaluator, int simulations) {
        this(evaluator, simulations, DEFAULT_C_PUCT);
    }

    /** Creates a deterministic PUCT search with explicit search and exploration budgets. */
    public MctsPlayer(PolicyValueEvaluator evaluator, int simulations, double cPuct) {
        if (evaluator == null) {
            throw new NullPointerException("evaluator");
        }
        if (simulations < 1) {
            throw new IllegalArgumentException("simulations must be positive");
        }
        if (!Double.isFinite(cPuct) || cPuct < 0.0) {
            throw new IllegalArgumentException("cPuct must be finite and nonnegative");
        }
        this.evaluator = evaluator;
        this.simulations = simulations;
        this.cPuct = cPuct;
    }

    @Override
    public GameAction chooseAction(GameState state) {
        if (state == null) {
            throw new NullPointerException("state");
        }
        if (state.isTerminal() || state.legalActions().isEmpty()) {
            throw new IllegalArgumentException("Cannot choose an action without a legal move");
        }
        Node root = new Node(state, -1, 1.0);
        for (int simulation = 0; simulation < simulations; simulation++) {
            if (Thread.currentThread().isInterrupted()) {
                throw new CancellationException("MCTS search interrupted");
            }
            runSimulation(root);
        }
        Node best = null;
        for (Node child : root.children) {
            if (best == null || child.visits > best.visits
                    || (child.visits == best.visits && child.action < best.action)) {
                best = child;
            }
        }
        if (Thread.currentThread().isInterrupted()) {
            throw new CancellationException("MCTS search interrupted");
        }
        return best == null ? state.legalActions().get(0) : new GameAction(best.action);
    }

    private void runSimulation(Node root) {
        List<Node> path = new ArrayList<>();
        Node node = root;
        path.add(node);
        while (node.expanded && !node.state.isTerminal()) {
            node = selectChild(node);
            path.add(node);
        }

        double value;
        if (node.state.isTerminal()) {
            value = terminalValue(node.state);
        } else {
            PolicyValueEvaluator.Evaluation evaluation = evaluator.evaluate(node.state);
            expand(node, evaluation.policyLogits());
            value = evaluation.value();
        }

        for (int index = path.size() - 1; index >= 0; index--) {
            Node visited = path.get(index);
            visited.visits++;
            visited.valueSum += value;
            value = -value;
        }
    }

    private Node selectChild(Node parent) {
        Node best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        double parentScale = Math.sqrt(parent.visits);
        for (Node child : parent.children) {
            double qFromParent = child.visits == 0 ? 0.0 : -child.valueSum / child.visits;
            double exploration = cPuct * child.prior * parentScale / (1.0 + child.visits);
            double score = qFromParent + exploration;
            if (score > bestScore || (score == bestScore && child.action < best.action)) {
                best = child;
                bestScore = score;
            }
        }
        return best;
    }

    private static void expand(Node node, float[] logits) {
        List<GameAction> legal = node.state.legalActions();
        double maxLogit = Double.NEGATIVE_INFINITY;
        for (GameAction action : legal) {
            maxLogit = Math.max(maxLogit, logits[action.column()]);
        }
        double sum = 0.0;
        double[] weights = new double[GameState.COLUMNS];
        for (GameAction action : legal) {
            double weight = Math.exp(logits[action.column()] - maxLogit);
            weights[action.column()] = weight;
            sum += weight;
        }
        for (GameAction action : legal) {
            GameEngine simulation = new GameEngine(node.state);
            if (!simulation.apply(action)) {
                throw new IllegalStateException("legal action was rejected by GameEngine");
            }
            node.children.add(new Node(
                    simulation.snapshot(),
                    action.column(),
                    weights[action.column()] / sum));
        }
        node.expanded = true;
    }

    private static double terminalValue(GameState state) {
        if (state.winner() == GameState.EMPTY) {
            return 0.0;
        }
        return state.winner() == state.currentPlayer() ? 1.0 : -1.0;
    }

    private static final class Node {
        final GameState state;
        final int action;
        final double prior;
        final List<Node> children = new ArrayList<>();
        int visits;
        double valueSum;
        boolean expanded;

        Node(GameState state, int action, double prior) {
            this.state = state;
            this.action = action;
            this.prior = prior;
        }
    }
}
