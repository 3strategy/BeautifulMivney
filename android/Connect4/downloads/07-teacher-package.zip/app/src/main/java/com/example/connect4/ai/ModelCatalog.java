package com.example.connect4.ai;

import android.content.res.AssetManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Stable model IDs and explicit model/sidecar pairs supplied by one asset registry. */
public final class ModelCatalog {
    public static final String ASSET_NAME = "player_catalog.json";
    public static final String DEFAULT_MODEL_ID = "main";

    private final String defaultModelId;
    private final List<Entry> entries;

    private ModelCatalog(String defaultModelId, List<Entry> entries) {
        this.defaultModelId = defaultModelId;
        this.entries = Collections.unmodifiableList(new ArrayList<>(entries));
    }

    /** Loads and validates the complete model registry packaged in application assets. */
    public static ModelCatalog load(AssetManager assets) throws Exception {
        byte[] bytes;
        try (InputStream input = assets.open(ASSET_NAME);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            bytes = output.toByteArray();
        }
        JSONObject json = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        if (json.getInt("schema_version") != 1) {
            throw new IllegalArgumentException("Unsupported model catalog version");
        }
        // Preserve the shipped JSON keys while naming Java objects for their model role.
        String defaultId = validId(json.getString("default_player_id"));
        JSONArray models = json.getJSONArray("players");
        if (models.length() == 0) throw new IllegalArgumentException("Model catalog is empty");
        List<Entry> result = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        for (int index = 0; index < models.length(); index++) {
            JSONObject model = models.getJSONObject(index);
            String id = validId(model.getString("id"));
            if (!ids.add(id)) throw new IllegalArgumentException("Duplicate model id " + id);
            String displayName = model.getString("display_name").trim();
            if (displayName.isEmpty() || displayName.length() > 80 || hasControlCharacter(displayName)) {
                throw new IllegalArgumentException("Invalid model display name");
            }
            TfliteEvaluator.AssetPair pair = new TfliteEvaluator.AssetPair(
                    model.getString("model_asset"),
                    model.getString("metadata_asset"),
                    displayName);
            result.add(new Entry(id, displayName, pair));
        }
        if (!ids.contains(defaultId)) {
            throw new IllegalArgumentException("Default model is not in catalog");
        }
        return new ModelCatalog(defaultId, result);
    }

    /** Provides the legacy single-model configuration if the catalog cannot be read. */
    public static ModelCatalog fallback() {
        List<Entry> entries = new ArrayList<>();
        entries.add(new Entry(
                DEFAULT_MODEL_ID,
                "Current model",
                TfliteEvaluator.DEFAULT_ASSETS));
        return new ModelCatalog(DEFAULT_MODEL_ID, entries);
    }

    /** Returns the configured model identifier selected for a fresh session. */
    public String defaultModelId() { return defaultModelId; }

    /** Returns immutable model entries in the order intended for the computer-player picker. */
    public List<Entry> entries() { return entries; }

    /** Finds an entry by its stable identifier, or returns {@code null} if it is absent. */
    public Entry find(String id) {
        for (Entry entry : entries) if (entry.id().equals(id)) return entry;
        return null;
    }

    /** Finds an entry or rejects an unknown identifier. */
    public Entry require(String id) {
        Entry entry = find(id);
        if (entry == null) throw new IllegalArgumentException("Unknown model id " + id);
        return entry;
    }

    private static String validId(String id) {
        if (id == null || id.isEmpty() || id.length() > 40) {
            throw new IllegalArgumentException("Invalid model id");
        }
        for (int index = 0; index < id.length(); index++) {
            char character = id.charAt(index);
            boolean safe = character >= 'a' && character <= 'z'
                    || character >= '0' && character <= '9'
                    || index > 0 && (character == '_' || character == '-');
            if (!safe) throw new IllegalArgumentException("Invalid model id");
        }
        return id;
    }

    private static boolean hasControlCharacter(String value) {
        for (int index = 0; index < value.length(); index++) {
            if (Character.isISOControl(value.charAt(index))) return true;
        }
        return false;
    }

    /** One named model choice and the files required to evaluate it. */
    public static final class Entry {
        private final String id;
        private final String displayName;
        private final TfliteEvaluator.AssetPair assets;

        Entry(String id, String displayName, TfliteEvaluator.AssetPair assets) {
            this.id = id;
            this.displayName = displayName;
            this.assets = assets;
        }

        public String id() { return id; }

        public String displayName() { return displayName; }

        public TfliteEvaluator.AssetPair assets() { return assets; }
    }
}
