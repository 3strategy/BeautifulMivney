package com.example.connect4.core;

/** Converts immutable game states to the policy/value model contract. */
public final class StateEncoder {
    private StateEncoder() {
    }

    /**
     * Encodes a position as the contract's NHWC {@code [1, 6, 7, 2]} tensor.
     * Plane zero holds the player to move; plane one holds that player's opponent.
     */
    // TWIN-ID: CONNECT4.STATE_ENCODING (TWIN-PYTHON: ml/game_env.py::encode)
    public static float[][][][] encode(GameState state) {
        if (state == null) {
            throw new NullPointerException("state");
        }
        float[][][][] encoded = new float[1][GameState.ROWS][GameState.COLUMNS][2];
        int current = state.currentPlayer();
        int opponent = current == GameState.RED ? GameState.YELLOW : GameState.RED;
        for (int row = 0; row < GameState.ROWS; row++) {
            for (int column = 0; column < GameState.COLUMNS; column++) {
                int cell = state.cell(row, column);
                if (cell == current) {
                    encoded[0][row][column][0] = 1.0f;
                } else if (cell == opponent) {
                    encoded[0][row][column][1] = 1.0f;
                }
            }
        }
        return encoded;
    }

    /** Returns a seven-item mask whose true entries are currently playable columns. */
    // TWIN-ID: CONNECT4.LEGAL_ACTION_MASK (TWIN-PYTHON: ml/game_env.py::legal_mask)
    public static boolean[] legalMask(GameState state) {
        if (state == null) {
            throw new NullPointerException("state");
        }
        boolean[] mask = new boolean[GameState.COLUMNS];
        for (GameAction action : state.legalActions()) {
            mask[action.column()] = true;
        }
        return mask;
    }
}
