package com.example.connect4.ai;

import android.content.Context;
import com.example.connect4.core.GameState;
import com.example.connect4.core.PolicyValueEvaluator;
import com.example.connect4.core.StateEncoder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.Tensor;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/** CPU interpreter owned and used by a single AI worker. No network is required. */
public final class TfliteEvaluator implements PolicyValueEvaluator, AutoCloseable {
    public static final AssetPair DEFAULT_ASSETS = new AssetPair(
            "policy_value.tflite", "policy_value.json", null);

    private final Interpreter interpreter;
    private final String signature;
    private final String inputName;
    private final String policyName;
    private final String valueName;
    private final String kind;
    private final String displayName;
    private final String trainingSummary;

    public TfliteEvaluator(Context context) throws Exception {
        this(context, DEFAULT_ASSETS);
    }

    public TfliteEvaluator(Context context, AssetPair assets) throws Exception {
        if (context == null) throw new NullPointerException("context");
        if (assets == null) throw new NullPointerException("assets");
        byte[] model;
        JSONObject metadata;
        try (InputStream input = context.getAssets().open(assets.modelAsset())) {
            model = readBytes(input);
        }
        try (InputStream input = context.getAssets().open(assets.metadataAsset())) {
            metadata = new JSONObject(new String(readBytes(input), StandardCharsets.UTF_8));
        }
        require("connect4".equals(metadata.getString("game")), "Wrong game");
        require(metadata.getInt("contract_version") == 1, "Wrong contract version");
        kind = metadata.getString("model_kind");
        require(kind.equals("mock") || kind.equals("trained"), "Unknown model kind");
        String defaultName = assets.fallbackDisplayName() != null
                ? assets.fallbackDisplayName()
                : (kind.equals("mock") ? "Mock / untrained" : "Trained");
        displayName = metadata.optString("display_name", defaultName).trim();
        require(!displayName.isEmpty() && displayName.length() <= 100,
                "Invalid model display name");
        JSONObject provenance = metadata.optJSONObject("training_provenance");
        int cycles = provenance == null ? -1 : provenance.optInt("cycles_completed", -1);
        int updates = provenance == null ? -1 : provenance.optInt("optimizer_updates_total", -1);
        trainingSummary = cycles >= 0 && updates >= 0
                ? cycles + " cycles / " + updates + " updates"
                : "";
        StringBuilder hash = new StringBuilder();
        for (byte item : MessageDigest.getInstance("SHA-256").digest(model)) hash.append(String.format("%02x", item & 255));
        require(hash.toString().equals(metadata.getString("model_sha256")), "Model hash mismatch");
        JSONObject input = metadata.getJSONObject("input");
        JSONObject policy = metadata.getJSONObject("outputs").getJSONObject("policy_logits");
        JSONObject value = metadata.getJSONObject("outputs").getJSONObject("value");
        checkMetadata(input, new int[]{1, 6, 7, 2});
        checkMetadata(policy, new int[]{1, 7});
        checkMetadata(value, new int[]{1, 1});
        require("NHWC".equals(input.getString("layout")), "Wrong layout");
        require("unnormalized_logits_one_per_column".equals(policy.getString("meaning")), "Wrong policy meaning");
        require("player_to_move".equals(value.getString("perspective")), "Wrong value perspective");
        JSONArray range = value.getJSONArray("range");
        require(range.length() == 2 && range.getDouble(0) == -1 && range.getDouble(1) == 1, "Wrong value range");
        signature = metadata.getString("signature_key");
        inputName = input.getString("name");
        policyName = policy.getString("name");
        valueName = value.getString("name");
        ByteBuffer bytes = ByteBuffer.allocateDirect(model.length).order(ByteOrder.nativeOrder());
        bytes.put(model).rewind();
        Interpreter loaded = new Interpreter(bytes, new Interpreter.Options().setNumThreads(2));
        try {
            require(Arrays.asList(loaded.getSignatureKeys()).contains(signature), "Missing signature");
            require(Arrays.equals(loaded.getSignatureInputs(signature), new String[]{inputName}), "Wrong signature inputs");
            require(loaded.getSignatureOutputs(signature).length == 2, "Wrong signature outputs");
            checkTensor(loaded.getInputTensorFromSignature(inputName, signature), new int[]{1, 6, 7, 2});
            checkTensor(loaded.getOutputTensorFromSignature(policyName, signature), new int[]{1, 7});
            checkTensor(loaded.getOutputTensorFromSignature(valueName, signature), new int[]{1, 1});
        } catch (Exception exception) {
            loaded.close();
            throw exception;
        }
        interpreter = loaded;
    }

    /** Describes the model only; search budgets belong to the caller that runs MCTS. */
    public String modelDescription() {
        String kindLabel = kind.equals("mock") ? "Mock / untrained" : "Trained";
        return displayName + (displayName.equals(kindLabel) ? "" : " · " + kindLabel)
                + (trainingSummary.isEmpty() ? "" : " · " + trainingSummary);
    }

    public String modelKind() { return kind; }

    public String displayName() { return displayName; }

    public String trainingSummary() { return trainingSummary; }

    @Override public Evaluation evaluate(GameState state) {
        if (state.isTerminal()) throw new IllegalArgumentException("Do not evaluate terminal positions");
        float[][] policy = new float[1][7];
        float[][] value = new float[1][1];
        Map<String, Object> inputs = new HashMap<>();
        Map<String, Object> outputs = new HashMap<>();
        inputs.put(inputName, StateEncoder.encode(state));
        outputs.put(policyName, policy);
        outputs.put(valueName, value);
        interpreter.runSignature(inputs, outputs, signature);
        return new Evaluation(policy[0], value[0][0]);
    }

    private static void checkMetadata(JSONObject tensor, int[] expected) throws Exception {
        require("float32".equals(tensor.getString("dtype")), "Wrong metadata dtype");
        JSONArray shape = tensor.getJSONArray("shape");
        require(shape.length() == expected.length, "Wrong metadata shape");
        for (int i = 0; i < expected.length; i++) require(shape.getInt(i) == expected[i], "Wrong metadata shape");
    }

    private static void checkTensor(Tensor tensor, int[] shape) {
        require(tensor.dataType() == DataType.FLOAT32 && Arrays.equals(tensor.shape(), shape), "Incompatible model tensor");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }

    private static byte[] readBytes(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
        return output.toByteArray();
    }

    @Override public void close() { interpreter.close(); }

    /** Validated leaf asset names keep an explicit model/sidecar pair together. */
    public static final class AssetPair {
        private final String modelAsset;
        private final String metadataAsset;
        private final String fallbackDisplayName;

        public AssetPair(String modelAsset, String metadataAsset, String fallbackDisplayName) {
            this.modelAsset = validAssetName(modelAsset, ".tflite");
            this.metadataAsset = validAssetName(metadataAsset, ".json");
            this.fallbackDisplayName = fallbackDisplayName;
        }

        public String modelAsset() { return modelAsset; }

        public String metadataAsset() { return metadataAsset; }

        String fallbackDisplayName() { return fallbackDisplayName; }

        private static String validAssetName(String name, String suffix) {
            if (name == null || !name.endsWith(suffix) || name.length() > 100) {
                throw new IllegalArgumentException("Invalid model asset name");
            }
            for (int index = 0; index < name.length(); index++) {
                char character = name.charAt(index);
                boolean safe = character >= 'a' && character <= 'z'
                        || character >= 'A' && character <= 'Z'
                        || character >= '0' && character <= '9'
                        || character == '_' || character == '-' || character == '.';
                if (!safe) throw new IllegalArgumentException("Invalid model asset name");
            }
            return name;
        }
    }
}
