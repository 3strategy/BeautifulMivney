package com.example.connect4;
import androidx.test.core.app.ActivityScenario;
import org.junit.Test;
import static org.junit.Assert.*;
public class CourseGoogleSetupTest {
    @Test public void absentOAuthConfigReturnsARecoverableError() {
        try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> {
                if(activity.getResources().getIdentifier("default_web_client_id","string",activity.getPackageName())!=0) return;
                new GoogleSignIn(activity).signIn(new GoogleSignIn.Callback() {
                    public void token(String token) { fail("No OAuth config should not return a token"); }
                    public void error(String message) { assertTrue(message.contains("OAuth configuration")); }
                });
            });
        }
    }
}
