package com.example.connect4;
import android.content.Context;
import androidx.lifecycle.ViewModelProvider;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import static org.junit.Assert.*;

public class CourseRestoreTest {
    @Test public void validPrefixSurvivesRecreationAndNewActivity() {
        Context context=ApplicationProvider.getApplicationContext();
        context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE)
                .edit().clear().putString("moves","01010106").commit();
        try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)) {
            s.onActivity(a -> assertEquals("0101010",new ViewModelProvider(a).get(GameSession.class).engine.snapshot().moves()));
            s.recreate();
            s.onActivity(a -> assertTrue(new ViewModelProvider(a).get(GameSession.class).engine.snapshot().isTerminal()));
        }
        try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)) {
            s.onActivity(a -> assertEquals("0101010",new ViewModelProvider(a).get(GameSession.class).engine.snapshot().moves()));
        }
        context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).edit().clear().commit();
    }
}
