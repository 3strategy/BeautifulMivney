package com.example.connect4;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.Button;
import androidx.lifecycle.ViewModelProvider;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.connect4.multiplayer.*;
import com.example.connect4.ui.BoardView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Supplier;
import org.junit.Assume;
import org.junit.Test;
import static org.junit.Assert.*;

/** Run the same test concurrently on two devices with role=red/yellow and the same runId. */
public class CourseCrossDeviceTest {
    @Test public void twoScreensAndSpectatorFinishTheSameGame() throws Exception {
        Assume.assumeTrue(Boolean.parseBoolean(InstrumentationRegistry.getArguments().getString("crossDevice","false")));
        String role=InstrumentationRegistry.getArguments().getString("role");
        String run=InstrumentationRegistry.getArguments().getString("runId");
        boolean red="red".equals(role);
        Context context=ApplicationProvider.getApplicationContext();
        context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).edit().clear().commit();
        Client client=new Client(role+run);
        Client spectator=null;
        MultiplayerRepository.Subscription watched=null;
        CountDownLatch spectatorFinished=new CountDownLatch(1);
        try(ActivityScenario<MainActivity> screen=ActivityScenario.launch(MainActivity.class)) {
            screen.onActivity(activity -> {
                session(activity).repository=client.repo;
                activity.setupBinding().mode.setSelection(GameSession.MODE_ONLINE);
            });
            waitFor(() -> onScreen(screen,a -> session(a).connected && session(a).reconciled),"connected lobby");
            if(red) {
                screen.onActivity(a -> {
                    a.viewBinding().roomName.setText(run);
                    a.viewBinding().createRoom.performClick();
                });
            } else {
                waitFor(() -> onScreen(screen,a -> {
                    for(int i=0;i<a.viewBinding().rooms.getChildCount();i++) {
                        Button room=(Button)a.viewBinding().rooms.getChildAt(i);
                        if(room.getText().toString().startsWith(run+" ·")) { room.performClick();return true; }
                    }
                    return false;
                }),"room from other device");
            }
            waitFor(() -> onScreen(screen,a -> session(a).room!=null
                    && session(a).room.getStatus()==RoomStatus.PLAYING),"two occupied seats");
            if(red) {
                AtomicReference<String> roomId=new AtomicReference<>();
                screen.onActivity(a -> roomId.set(session(a).roomId));
                spectator=new Client("spectator"+run);
                Client third=spectator;
                assertEquals(RoomRole.SPECTATOR,CourseCrossDeviceTest.<RoomRole>await(cb -> third.repo.joinRoom(roomId.get(),cb)));
                watched=third.repo.subscribeRoom(roomId.get(),new MultiplayerRepository.RoomListener() {
                    public void onRoom(RoomSnapshot room) {
                        if("0011223".equals(room.getRoom().getMoves()) && room.getGameState().winner()==1) spectatorFinished.countDown();
                    }
                    public void onError(RepositoryError error) { }
                });
            }
            int[] columns=red ? new int[]{0,1,2,3} : new int[]{0,1,2};
            for(int index=0;index<columns.length;index++) {
                int expectedBefore=2*index+(red?0:1);
                waitFor(() -> onScreen(screen,a -> session(a).room!=null
                        && session(a).connected && session(a).reconciled
                        && session(a).room.canMove()
                        && session(a).room.getGameState().moveCount()==expectedBefore),"turn "+expectedBefore);
                int column=columns[index];
                screen.onActivity(a -> {
                    BoardView board=a.viewBinding().board;
                    float cell=Math.min(board.getWidth()/7f,board.getHeight()/6f);
                    MotionEvent tap=MotionEvent.obtain(0,0,MotionEvent.ACTION_UP,(column+.5f)*cell,.5f*cell,0);
                    try { assertTrue(board.dispatchTouchEvent(tap)); } finally { tap.recycle(); }
                });
                waitFor(() -> onScreen(screen,a -> session(a).room.getGameState().moveCount()>expectedBefore),"accepted move");
                if(!red && index==0) screen.recreate();
            }
            AtomicReference<String> diagnostic=new AtomicReference<>();
            try {
                waitFor(() -> onScreen(screen,a -> {
                    GameSession s=session(a);
                    diagnostic.set("history="+(s.room==null?"null":s.room.getRoom().getMoves())+" connected="+s.connected+" reconciled="+s.reconciled+" message="+s.onlineMessage);
                    return s.room!=null && s.room.getGameState().isTerminal();
                }),"shared result");
            } catch(AssertionError failure) { throw new AssertionError(diagnostic.get(),failure); }
            screen.onActivity(a -> {
                assertEquals("0011223",session(a).room.getRoom().getMoves());
                assertEquals("Red wins!",a.viewBinding().status.getText().toString());
            });
            if(red) assertTrue("Spectator result",spectatorFinished.await(15,TimeUnit.SECONDS));
        } finally {
            if(watched!=null) watched.close();
            if(spectator!=null) spectator.close();
            client.close();
        }
    }
    private interface ScreenCheck { boolean test(MainActivity activity); }
    private static boolean onScreen(ActivityScenario<MainActivity> screen,ScreenCheck check) {
        AtomicBoolean result=new AtomicBoolean();screen.onActivity(a -> result.set(check.test(a)));return result.get();
    }
    private static GameSession session(MainActivity activity) { return new ViewModelProvider(activity).get(GameSession.class); }
    private static void waitFor(Supplier<Boolean> condition,String what) throws Exception {
        long end=System.currentTimeMillis()+30000;
        while(System.currentTimeMillis()<end) { if(condition.get()) return;Thread.sleep(50); }
        fail("Timed out: "+what);
    }
    private static <T> T await(Consumer<MultiplayerRepository.ResultCallback<T>> operation) throws Exception {
        CountDownLatch done=new CountDownLatch(1);AtomicReference<T> value=new AtomicReference<>();AtomicReference<String> error=new AtomicReference<>();
        operation.accept(new MultiplayerRepository.ResultCallback<T>() {
            public void onSuccess(T result) { value.set(result);done.countDown(); }
            public void onError(RepositoryError failure) { error.set(failure.getMessage());done.countDown(); }
        });
        assertTrue(done.await(20,TimeUnit.SECONDS));assertNull(error.get(),error.get());return value.get();
    }
    private static final class Client {
        final FirebaseApp app;
        final FirebaseDatabase database;
        final MultiplayerRepository repo;
        Client(String name) throws Exception {
            name=name+UUID.randomUUID();
            app=FirebaseApp.initializeApp(ApplicationProvider.getApplicationContext(),new FirebaseOptions.Builder()
                    .setProjectId("demo-connect4").setApiKey("fake-cross-"+name)
                    .setApplicationId("1:123:android:cross").build(),name);
            FirebaseAuth auth=FirebaseAuth.getInstance(app);auth.useEmulator("10.0.2.2",9099);
            database=FirebaseDatabase.getInstance(app,"https://demo-connect4-default-rtdb.firebaseio.com");
            database.useEmulator("10.0.2.2",9000);
            repo=new MultiplayerRepository(auth,database);
            String email=name+"@example.test";
            CourseCrossDeviceTest.<String>await(cb -> repo.createAccount(email,"cross-device-password",cb));
        }
        void close() { database.goOffline();app.delete(); }
    }
}
