package com.example.connect4;

import androidx.lifecycle.ViewModelProvider;
import androidx.test.core.app.ActivityScenario;
import com.example.connect4.multiplayer.CourseRoomFixture;
import com.example.connect4.multiplayer.RoomSnapshot;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.Test;
import static org.junit.Assert.*;

public class OnlineSnapshotOrderTest {
    @Test public void lateReadCannotUndoALiveWinButAnotherRoomCanStartEmpty() {
        try (ActivityScenario<MainActivity> screen = ActivityScenario.launch(MainActivity.class)) {
            screen.onActivity(activity -> {
                GameSession session = new ViewModelProvider(activity).get(GameSession.class);
                session.room = null;
                AtomicReference<RoomSnapshot> rendered = new AtomicReference<>();
                OnlineController controller = new OnlineController(activity, activity.viewBinding(), session,
                        new OnlineController.Host() {
                            public void changed() { }
                            public void received(RoomSnapshot room) { rendered.set(room); }
                        });
                controller.receiveRoom(CourseRoomFixture.room("one", "0011223"));
                controller.receiveRoom(CourseRoomFixture.room("one", "001122"));
                assertEquals("0011223", rendered.get().getRoom().getMoves());
                assertTrue(rendered.get().getGameState().isTerminal());
                controller.receiveRoom(CourseRoomFixture.room("two", ""));
                assertEquals("", rendered.get().getRoom().getMoves());
                controller.destroy();
            });
        }
    }
}
