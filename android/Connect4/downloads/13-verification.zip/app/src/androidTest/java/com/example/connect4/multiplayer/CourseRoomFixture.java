package com.example.connect4.multiplayer;

/** Test-only valid server snapshots for deliberately out-of-order delivery. */
public final class CourseRoomFixture {
    public static RoomSnapshot room(String id, String moves) {
        RoomData data = new RoomData();
        data.setSchemaVersion(1);
        data.setName("Fixture");
        data.setPlayerRed("red");
        data.setPlayerYellow("yellow");
        data.setMoves(moves);
        data.setCreatedAt(1);
        data.setUpdatedAt(2);
        RoomValidation.Result result = RoomValidation.validate(data);
        if (!result.isValid()) throw new AssertionError(result.getError());
        return new RoomSnapshot(id, data, result.getState(), RoomRole.YELLOW, result.getStatus());
    }
}
