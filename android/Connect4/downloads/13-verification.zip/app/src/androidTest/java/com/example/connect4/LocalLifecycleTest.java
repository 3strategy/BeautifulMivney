package com.example.connect4;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import android.view.MotionEvent;
import android.view.View;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import com.example.connect4.ai.ComputerMoveService;
import com.example.connect4.core.GameEngine;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Device checks for retained local state and cancellation at the Activity boundary. */
@RunWith(AndroidJUnit4.class)
public class LocalLifecycleTest {
    @Test
    public void modelCatalogSelectionUsesStableIdAcrossRecreation() {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> {
                activity.setupBinding().side.setSelection(0);
                activity.setupBinding().mode.setSelection(GameSession.MODE_MODEL);
                activity.setupBinding().computerPlayer.setSelection(1);
            });
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            scenario.onActivity(activity -> {
                assertEquals("early-a100", session(activity).selectedModelId);
                assertEquals(View.VISIBLE, activity.setupBinding().computerPlayer.getVisibility());
                assertEquals(1, activity.setupBinding().computerPlayer.getSelectedItemPosition());
            });

            scenario.recreate();
            scenario.onActivity(activity -> {
                assertEquals(GameSession.MODE_MODEL,
                        activity.setupBinding().mode.getSelectedItemPosition());
                assertEquals("early-a100", session(activity).selectedModelId);
                assertEquals(1, activity.setupBinding().computerPlayer.getSelectedItemPosition());
            });
        }
    }

    @Test
    public void localMoveSurvivesRecreationAndBackgroundResume() {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> {
                session(activity).mode = 0;
                activity.setupBinding().mode.setSelection(0);
                session(activity).engine = new GameEngine();
                activity.viewBinding().restart.performClick();
            });
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            scenario.onActivity(activity -> {
                View board = activity.viewBinding().board;
                MotionEvent tap = MotionEvent.obtain(0, 0, MotionEvent.ACTION_UP,
                        board.getWidth() / 2f, board.getHeight() / 2f, 0);
                try {
                    assertTrue(board.dispatchTouchEvent(tap));
                } finally {
                    tap.recycle();
                }
                assertEquals("3", session(activity).engine.snapshot().moves());
                assertEquals("Yellow to play", status(activity));
            });

            scenario.onActivity(activity -> activity.viewBinding().restart.performClick());
            onView(withId(android.R.id.button2)).inRoot(isDialog()).perform(click());
            scenario.onActivity(activity -> assertEquals("3", session(activity).engine.snapshot().moves()));

            scenario.recreate();
            scenario.onActivity(activity -> {
                assertEquals(0, activity.setupBinding().mode.getSelectedItemPosition());
                assertEquals("Yellow to play", status(activity));
                assertEquals("3", session(activity).engine.snapshot().moves());
            });

            scenario.moveToState(Lifecycle.State.CREATED);
            scenario.moveToState(Lifecycle.State.RESUMED);
            scenario.onActivity(activity -> {
                assertEquals("Yellow to play", status(activity));
                assertEquals("3", session(activity).engine.snapshot().moves());
            });
        }
    }

    @Test
    public void restartCancelsPendingComputerMove() throws Exception {
        CountDownLatch running = new CountDownLatch(1);
        CountDownLatch interrupted = new CountDownLatch(1);

        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> {
                session(activity).mode = GameSession.MODE_LOCAL;
                activity.setupBinding().mode.setSelection(GameSession.MODE_LOCAL);
            });
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            scenario.onActivity(activity -> {
                session(activity).engine = new GameEngine();
                session(activity).engine.apply(new com.example.connect4.core.GameAction(3));
                session(activity).requestComputerMove(() -> {
                    running.countDown();
                    try {
                        Thread.sleep(TimeUnit.MINUTES.toMillis(1));
                    } catch (InterruptedException expected) {
                        interrupted.countDown();
                        Thread.currentThread().interrupt();
                    }
                    return ComputerMoveService.chooseHeuristicMove(new GameEngine().snapshot());
                }, result -> { throw new AssertionError("Cancelled move delivered"); },
                        failure -> { throw new AssertionError("Cancelled failure delivered", failure); });
            });

            assertTrue("AI work did not start", running.await(5, TimeUnit.SECONDS));
            scenario.onActivity(activity -> activity.viewBinding().restart.performClick());
            onView(withId(android.R.id.button1)).inRoot(isDialog()).perform(click());
            assertTrue("Restart did not interrupt AI work", interrupted.await(5, TimeUnit.SECONDS));

            scenario.onActivity(activity -> {
                GameSession session = session(activity);
                assertFalse(session.isComputerThinking());
                assertEquals("", session.engine.snapshot().moves());
            });
        }
    }

    @Test
    public void landscapeFitsBoardAndPreservesMovesAcrossRotation() throws Exception {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            rotate(scenario, android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT,
                    android.content.res.Configuration.ORIENTATION_PORTRAIT);
            scenario.onActivity(activity -> activity.setupBinding().mode.setSelection(GameSession.MODE_LOCAL));
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            scenario.onActivity(activity -> {
                session(activity).engine = new GameEngine();
                activity.viewBinding().restart.performClick();
            });
            scenario.onActivity(activity -> tapColumn(activity, 0));

            rotate(scenario, android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE,
                    android.content.res.Configuration.ORIENTATION_LANDSCAPE);
            scenario.onActivity(activity -> {
                assertEquals("0", session(activity).engine.snapshot().moves());
                View board = activity.viewBinding().board;
                android.graphics.Rect visible = new android.graphics.Rect();
                assertTrue(board.getGlobalVisibleRect(visible));
                assertEquals(board.getWidth(), visible.width());
                assertEquals(board.getHeight(), visible.height());
                View screen = activity.viewBinding().main;
                int usableHeight = screen.getHeight() - screen.getPaddingTop() - screen.getPaddingBottom();
                assertTrue("Landscape must devote at least 80% of usable height to the board",
                        board.getHeight() >= usableHeight * .80f);
                assertEquals("Board must retain its drawing/hit-test aspect ratio",
                        7f / 6f, board.getWidth() / (float) board.getHeight(), .02f);
                View restart = activity.viewBinding().restart;
                assertTrue(restart.getGlobalVisibleRect(visible));
                assertEquals(restart.getHeight(), visible.height());
                android.graphics.Rect gameBounds = new android.graphics.Rect();
                activity.viewBinding().offlineGame.getGlobalVisibleRect(gameBounds);
                assertFalse("Restart must not consume board-panel space",
                        android.graphics.Rect.intersects(visible, gameBounds));
                android.graphics.Rect turnBounds = new android.graphics.Rect();
                android.graphics.Rect detailBounds = new android.graphics.Rect();
                activity.viewBinding().status.getGlobalVisibleRect(turnBounds);
                activity.viewBinding().aiStatus.getGlobalVisibleRect(detailBounds);
                assertTrue("Turn and play status must share a row",
                        turnBounds.top < detailBounds.bottom && detailBounds.top < turnBounds.bottom);
                tapColumn(activity, 6);
                assertEquals("06", session(activity).engine.snapshot().moves());
            });
            rotate(scenario, android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT,
                    android.content.res.Configuration.ORIENTATION_PORTRAIT);
            scenario.onActivity(activity -> assertEquals("06", session(activity).engine.snapshot().moves()));
        }
    }

    private static void tapColumn(MainActivity activity, int column) {
        View board = activity.viewBinding().board;
        MotionEvent tap = MotionEvent.obtain(0, 0, MotionEvent.ACTION_UP,
                (column + .5f) * board.getWidth() / 7f, board.getHeight() / 2f, 0);
        try { assertTrue(board.dispatchTouchEvent(tap)); }
        finally { tap.recycle(); }
    }

    private static void rotate(ActivityScenario<MainActivity> scenario, int requested, int expected)
            throws Exception {
        scenario.onActivity(activity -> activity.setRequestedOrientation(requested));
        java.util.concurrent.atomic.AtomicBoolean ready = new java.util.concurrent.atomic.AtomicBoolean();
        for (int attempt = 0; attempt < 100; attempt++) {
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            scenario.onActivity(activity -> ready.set(
                    activity.getResources().getConfiguration().orientation == expected
                    && activity.viewBinding().board.getWidth() > 0));
            if (ready.get()) return;
            Thread.sleep(50);
        }
        throw new AssertionError("Activity did not reach requested orientation");
    }

    private static String status(MainActivity activity) {
        return activity.viewBinding().status.getText().toString();
    }

    private static GameSession session(MainActivity activity) {
        return new ViewModelProvider(activity).get(GameSession.class);
    }
}
