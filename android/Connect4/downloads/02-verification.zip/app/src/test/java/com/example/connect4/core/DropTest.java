package com.example.connect4.core;
import org.junit.Test;
import static org.junit.Assert.*;
public class DropTest {
    @Test public void gravityInvalidInputAndDetachedSnapshot() {
        GameEngine game = new GameEngine();
        GameState empty = game.snapshot();
        assertFalse(game.apply(new GameAction(-1)));
        assertFalse(game.apply(new GameAction(7)));
        assertFalse(game.apply(null));
        for (int i=0;i<6;i++) assertTrue(game.apply(new GameAction(3)));
        assertEquals(GameState.RED, game.snapshot().cell(5,3));
        assertEquals(GameState.YELLOW, game.snapshot().cell(4,3));
        assertFalse(game.apply(new GameAction(3)));
        assertEquals(GameState.RED, game.snapshot().currentPlayer());
        assertEquals(GameState.EMPTY, empty.cell(5,3));
    }
}
