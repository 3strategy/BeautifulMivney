package com.example.connect4.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertThrows;

import java.util.concurrent.CancellationException;
import org.junit.Test;

/** Both implementations obey the same state-in/action-out contract. */
public class ComputerPlayerTest {
    private final ComputerPlayer[] players = {
            new HeuristicPlayer(),
            new MctsPlayer(state -> new PolicyValueEvaluator.Evaluation(new float[7], 0), 16)
    };

    @Test public void choosesLegalActionsForBothSidesWithoutChangingTheGame() {
        for (ComputerPlayer player : players) {
            GameEngine game = new GameEngine();
            for (int turn = 0; turn < 12 && !game.snapshot().isTerminal(); turn++) {
                GameState before = game.snapshot();
                GameAction action = player.chooseAction(before);
                assertTrue(before.legalActions().contains(action));
                assertEquals(before, game.snapshot());
                assertTrue(game.apply(action));
                assertEquals(turn, before.moveCount());
            }
        }
    }

    @Test public void interruptionDoesNotProduceAnAction() {
        for (ComputerPlayer player : players) {
            Thread.currentThread().interrupt();
            try {
                assertThrows(CancellationException.class,
                        () -> player.chooseAction(new GameEngine().snapshot()));
            } finally {
                Thread.interrupted();
            }
        }
    }
}
