package com.example.connect4.core;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;

public class GameEngineTest {
    @Test
    public void gravityAlternatesPlayersAndRecordsCompactHistory() {
        GameEngine engine = play("33");
        GameState state = engine.snapshot();

        assertEquals(GameState.RED, state.cell(5, 3));
        assertEquals(GameState.YELLOW, state.cell(4, 3));
        assertEquals(GameState.RED, state.currentPlayer());
        assertEquals("33", state.moves());
        assertEquals(2, state.moveCount());
    }

    @Test
    public void invalidAndFullColumnMovesLeaveWholeStateUnchanged() {
        GameEngine engine = play("000000");
        GameState before = engine.snapshot();

        assertFalse(engine.apply(new GameAction(-1)));
        assertEquals(before, engine.snapshot());
        assertFalse(engine.apply(new GameAction(7)));
        assertEquals(before, engine.snapshot());
        assertFalse(engine.apply(new GameAction(0)));
        assertEquals(before, engine.snapshot());
        assertFalse(engine.apply(null));
        assertEquals(before, engine.snapshot());
    }

    @Test
    public void detectsVerticalWinAndAdvancesTurn() {
        GameState state = play("0101010").snapshot();

        assertWin(state, GameState.RED, GameState.YELLOW,
                new GameState.Cell(2, 0), new GameState.Cell(3, 0),
                new GameState.Cell(4, 0), new GameState.Cell(5, 0));
    }

    @Test
    public void detectsHorizontalWinAtLeftBoundary() {
        GameState state = play("342211650").snapshot();

        assertWin(state, GameState.RED, GameState.YELLOW,
                new GameState.Cell(5, 0), new GameState.Cell(5, 1),
                new GameState.Cell(5, 2), new GameState.Cell(5, 3));
    }

    @Test
    public void detectsBothDiagonalDirectionsAtBoundaries() {
        GameState downRight = play("130315605411450024546152540042").snapshot();
        assertWin(downRight, GameState.YELLOW, GameState.RED,
                new GameState.Cell(2, 1), new GameState.Cell(3, 2),
                new GameState.Cell(4, 3), new GameState.Cell(5, 4));

        GameState downLeft = play("331546634615526").snapshot();
        assertWin(downLeft, GameState.RED, GameState.YELLOW,
                new GameState.Cell(2, 6), new GameState.Cell(3, 5),
                new GameState.Cell(4, 4), new GameState.Cell(5, 3));
    }

    @Test
    public void finalCellDrawHasNoWinnerAndRejectsFurtherMoves() {
        GameEngine engine = play("051434605223061623660540405114233565141232");
        GameState state = engine.snapshot();

        assertTrue(state.isTerminal());
        assertTrue(state.isDraw());
        assertEquals(GameState.EMPTY, state.winner());
        assertEquals(GameState.RED, state.currentPlayer());
        assertTrue(state.legalActions().isEmpty());
        assertFalse(engine.apply(new GameAction(0)));
        assertEquals(state, engine.snapshot());
    }

    @Test
    public void winOnFinalCellWinsBeforeBoardCanBeDeclaredDraw() {
        GameState state = play("430312363514266141646452040520335600522115").snapshot();

        assertWin(state, GameState.YELLOW, GameState.RED,
                new GameState.Cell(0, 3), new GameState.Cell(0, 4),
                new GameState.Cell(0, 5), new GameState.Cell(0, 6));
        assertFalse(state.isDraw());
    }

    @Test
    public void snapshotIsDetachedAndCollectionsAreImmutable() {
        GameEngine engine = play("30");
        GameState snapshot = engine.snapshot();
        int[][] board = snapshot.boardCopy();
        board[5][3] = GameState.EMPTY;

        assertEquals(GameState.RED, snapshot.cell(5, 3));
        assertNotSame(board, snapshot.boardCopy());
        assertThrows(UnsupportedOperationException.class,
                () -> snapshot.legalActions().clear());
        assertThrows(UnsupportedOperationException.class,
                () -> snapshot.winningCells().clear());

        assertTrue(engine.apply(new GameAction(3)));
        assertEquals(GameState.EMPTY, snapshot.cell(4, 3));
    }

    @Test
    public void constructorCopiesAndDetachesSnapshot() {
        GameState original = play("303122").snapshot();
        GameEngine restored = new GameEngine(original);

        assertEquals(original, restored.snapshot());
        assertTrue(restored.apply(new GameAction(4)));
        assertFalse(original.equals(restored.snapshot()));
    }

    @Test
    public void copiedTerminalPositionsPreserveResultAndRejectMoves() {
        for (String history : new String[]{"0101010", "051434605223061623660540405114233565141232"}) {
            GameState original = play(history).snapshot();
            GameEngine copy = new GameEngine(original);
            assertEquals(original, copy.snapshot());
            assertFalse(copy.apply(new GameAction(2)));
            assertEquals(original, copy.snapshot());
        }
    }

    @Test
    public void hypotheticalWinsUseTheSameRulesInEveryDirection() {
        String[] wins = {"0101010", "342211650", "130315605411450024546152540042",
                "331546634615526", "430312363514266141646452040520335600522115"};
        for (String history : wins) {
            GameEngine game = play(history.substring(0, history.length() - 1));
            GameState before = game.snapshot();
            GameAction action = new GameAction(history.charAt(history.length() - 1) - '0');
            assertTrue(GameEngine.wouldWin(before, action, before.currentPlayer()));
            assertEquals(before, game.snapshot());
            assertTrue(game.apply(action));
            assertEquals(before.currentPlayer(), game.snapshot().winner());
        }
    }

    @Test
    public void hypotheticalOpponentDropIsOnlyAnAnalysisAndRejectsIllegalActions() {
        GameState state = play("01010").snapshot();
        assertTrue(GameEngine.wouldWin(state, new GameAction(0), GameState.RED));
        assertFalse(GameEngine.wouldWin(state, new GameAction(0), GameState.YELLOW));
        assertEquals(GameState.YELLOW, state.currentPlayer());
        assertEquals("01010", state.moves());
        assertFalse(GameEngine.wouldWin(state, new GameAction(-1), GameState.RED));
        assertFalse(GameEngine.wouldWin(state, new GameAction(7), GameState.RED));
        assertFalse(GameEngine.wouldWin(play("000000").snapshot(), new GameAction(0), GameState.RED));
        assertFalse(GameEngine.wouldWin(play("0101010").snapshot(), new GameAction(1), GameState.YELLOW));
    }

    private static GameEngine play(String moves) {
        GameEngine engine = new GameEngine();
        for (int index = 0; index < moves.length(); index++) {
            assertTrue("move " + index + " should be legal",
                    engine.apply(new GameAction(moves.charAt(index) - '0')));
        }
        return engine;
    }

    private static void assertWin(
            GameState state, int winner, int nextPlayer, GameState.Cell... winningCells) {
        assertTrue(state.isTerminal());
        assertFalse(state.isDraw());
        assertEquals(winner, state.winner());
        assertEquals(nextPlayer, state.currentPlayer());
        assertEquals(Arrays.asList(winningCells), state.winningCells());
        assertEquals(Collections.emptyList(), state.legalActions());
    }
}
