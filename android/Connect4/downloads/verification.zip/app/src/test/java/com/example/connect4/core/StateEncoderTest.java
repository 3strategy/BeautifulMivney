package com.example.connect4.core;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class StateEncoderTest {
    @Test
    public void encodesPlanesRelativeToPlayerToMove() {
        GameEngine engine = new GameEngine();
        engine.apply(new GameAction(3));
        GameState state = engine.snapshot();

        float[][][][] encoded = StateEncoder.encode(state);
        assertEquals(1, encoded.length);
        assertEquals(6, encoded[0].length);
        assertEquals(7, encoded[0][0].length);
        assertEquals(2, encoded[0][0][0].length);
        assertArrayEquals(new float[] {0.0f, 1.0f}, encoded[0][5][3], 0.0f);
        assertArrayEquals(new float[] {0.0f, 0.0f}, encoded[0][5][2], 0.0f);
    }

    @Test
    public void terminalWinnerIsOnOpponentPlaneAfterTurnAdvances() {
        GameState state = play("0101010");
        float[][][][] encoded = StateEncoder.encode(state);

        assertEquals(GameState.YELLOW, state.currentPlayer());
        assertArrayEquals(new float[] {0.0f, 1.0f}, encoded[0][2][0], 0.0f);
        assertArrayEquals(new float[] {1.0f, 0.0f}, encoded[0][5][1], 0.0f);
        assertArrayEquals(new boolean[7], StateEncoder.legalMask(state));
    }

    @Test
    public void legalMaskExcludesOnlyFullColumnBeforeTerminal() {
        GameState state = play("000000");
        assertArrayEquals(
                new boolean[] {false, true, true, true, true, true, true},
                StateEncoder.legalMask(state));
    }

    private static GameState play(String moves) {
        GameEngine engine = new GameEngine();
        for (int index = 0; index < moves.length(); index++) {
            engine.apply(new GameAction(moves.charAt(index) - '0'));
        }
        return engine.snapshot();
    }
}
