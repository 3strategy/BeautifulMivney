package com.example.connect4.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import java.util.concurrent.CancellationException;
import org.junit.Test;

public class MctsPlayerTest {
    private static final PolicyValueEvaluator UNIFORM = state ->
            new PolicyValueEvaluator.Evaluation(new float[7], 0.0f);

    @Test
    public void findsForcedImmediateWinUsingExactTerminalValue() {
        MctsPlayer player = new MctsPlayer(UNIFORM, 96);
        assertEquals(new GameAction(0), player.chooseAction(play("010101")));
    }

    @Test
    public void blocksOpponentsForcedImmediateWin() {
        MctsPlayer player = new MctsPlayer(UNIFORM, 700);
        assertEquals(new GameAction(0), player.chooseAction(play("01010")));
    }

    @Test
    public void backsUpLeafValueFromTheCorrectPerspective() {
        PolicyValueEvaluator evaluator = state -> {
            float value = 0.0f;
            if (state.moveCount() == 1) {
                value = state.cell(5, 5) == GameState.RED ? -1.0f : 1.0f;
            }
            return new PolicyValueEvaluator.Evaluation(new float[7], value);
        };
        MctsPlayer player = new MctsPlayer(evaluator, 96);

        assertEquals(new GameAction(5), player.chooseAction(new GameEngine().snapshot()));
    }

    @Test
    public void masksIllegalPolicyLogitsAndUsesLegalPriors() {
        GameState state = play("000000");
        PolicyValueEvaluator evaluator = ignored -> new PolicyValueEvaluator.Evaluation(
                new float[] {100.0f, 0.0f, 0.0f, 0.0f, 10.0f, 0.0f, 0.0f}, 0.0f);
        MctsPlayer player = new MctsPlayer(evaluator, 64);

        assertEquals(new GameAction(4), player.chooseAction(state));
    }

    @Test
    public void equalVisitCountsChooseLowestColumn() {
        MctsPlayer player = new MctsPlayer(UNIFORM, 8);
        assertEquals(new GameAction(0), player.chooseAction(new GameEngine().snapshot()));
    }

    @Test
    public void neverEvaluatesTerminalState() {
        MctsPlayer player = new MctsPlayer(state -> {
            throw new AssertionError("terminal state must not reach evaluator");
        }, 8);

        assertThrows(IllegalArgumentException.class,
                () -> player.chooseAction(play("0101010")));
    }

    @Test
    public void evaluationRejectsInvalidModelOutputs() {
        assertThrows(IllegalArgumentException.class,
                () -> new PolicyValueEvaluator.Evaluation(new float[6], 0.0f));
        assertThrows(IllegalArgumentException.class,
                () -> new PolicyValueEvaluator.Evaluation(
                        new float[] {0, 0, 0, Float.NaN, 0, 0, 0}, 0.0f));
        assertThrows(IllegalArgumentException.class,
                () -> new PolicyValueEvaluator.Evaluation(new float[7], Float.POSITIVE_INFINITY));
        assertThrows(IllegalArgumentException.class,
                () -> new PolicyValueEvaluator.Evaluation(new float[7], 1.01f));
    }

    @Test
    public void interruptedSearchAbortsBeforeModelEvaluation() {
        MctsPlayer player = new MctsPlayer(state -> {
            throw new AssertionError("interrupted search must not evaluate");
        }, 8);
        Thread.currentThread().interrupt();
        try {
            assertThrows(CancellationException.class,
                    () -> player.chooseAction(new GameEngine().snapshot()));
        } finally {
            // JUnit reuses its worker thread, so do not leak the test's interrupt flag.
            Thread.interrupted();
        }
    }

    private static GameState play(String moves) {
        GameEngine engine = new GameEngine();
        for (int index = 0; index < moves.length(); index++) {
            engine.apply(new GameAction(moves.charAt(index) - '0'));
        }
        return engine.snapshot();
    }
}
