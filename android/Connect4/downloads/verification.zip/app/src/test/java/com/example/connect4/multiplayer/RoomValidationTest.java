package com.example.connect4.multiplayer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class RoomValidationTest {
    @Test
    public void waitingRoomReplaysAsEmptyWaitingState() {
        RoomValidation.Result result = RoomValidation.validate(room("", ""));

        assertTrue(result.isValid());
        assertEquals(RoomStatus.WAITING, result.getStatus());
        assertEquals("", result.getState().moves());
    }

    @Test
    public void completeWinReplaysAsFinished() {
        RoomValidation.Result result = RoomValidation.validate(room("yellow", "0101010"));

        assertTrue(result.isValid());
        assertEquals(RoomStatus.FINISHED, result.getStatus());
        assertEquals(1, result.getState().winner());
    }

    @Test
    public void rejectsMoveAfterWin() {
        RoomValidation.Result result = RoomValidation.validate(room("yellow", "01010102"));

        assertFalse(result.isValid());
        assertTrue(result.getError().contains("move 8"));
    }

    @Test
    public void rejectsOverfilledColumn() {
        RoomValidation.Result result = RoomValidation.validate(room("yellow", "0000000"));

        assertFalse(result.isValid());
        assertTrue(result.getError().contains("move 7"));
    }

    @Test
    public void rejectsHistoryBeforeYellowJoins() {
        RoomValidation.Result result = RoomValidation.validate(room("", "3"));

        assertFalse(result.isValid());
        assertTrue(result.getError().contains("waiting room"));
    }

    private static RoomData room(String yellow, String moves) {
        return new RoomData(1, "Class game", "red", yellow, moves, 1000, 1000);
    }
}
