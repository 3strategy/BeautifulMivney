package com.example.connect4.ai;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.GameState;
import java.util.concurrent.CancellationException;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ComputerMoveServiceTest {
    private final Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();

    @Test public void modelReturnsAnActionAndReportsTheActualSearchBudget() throws Exception {
        GameState snapshot = new GameEngine().snapshot();
        ModelCatalog.Entry model = ModelCatalog.load(context.getAssets()).require("untrained-baseline");
        ComputerMoveService.Result result = ComputerMoveService.chooseModelMove(context, model, snapshot, 8);
        assertTrue(snapshot.legalActions().contains(result.action()));
        assertTrue(result.status().contains("Mock / untrained"));
        assertTrue(result.status().contains("MCTS 8 simulations"));
        assertFalse(result.status().contains("fallback"));
    }

    @Test public void missingModelFallsBackWithAVisibleReason() {
        ModelCatalog.Entry missing = new ModelCatalog.Entry("missing", "Missing model",
                new TfliteEvaluator.AssetPair("missing.tflite", "missing.json", "Missing model"));
        ComputerMoveService.Result result = ComputerMoveService.chooseModelMove(
                context, missing, new GameEngine().snapshot(), 8);
        assertEquals(new GameAction(3), result.action());
        assertTrue(result.status().startsWith("Missing model · Heuristic fallback · "));
    }

    @Test public void incompatibleModelFallsBackBeforeSearch() {
        Context invalidContext = new ContextWrapper(context) {
            @Override public AssetManager getAssets() {
                return InstrumentationRegistry.getInstrumentation().getContext().getAssets();
            }
        };
        ComputerMoveService.Result result = ComputerMoveService.chooseModelMove(invalidContext,
                ModelCatalog.fallback().require(ModelCatalog.DEFAULT_MODEL_ID),
                new GameEngine().snapshot(), 8);
        assertEquals(new GameAction(3), result.action());
        assertTrue(result.status().contains("Heuristic fallback · Wrong game"));
    }

    @Test public void cancellationDoesNotFallBack() {
        Thread.currentThread().interrupt();
        try {
            assertThrows(CancellationException.class, () -> ComputerMoveService.chooseModelMove(
                    context, ModelCatalog.fallback().require(ModelCatalog.DEFAULT_MODEL_ID),
                    new GameEngine().snapshot(), 8));
        } finally {
            Thread.interrupted();
        }
    }
}
