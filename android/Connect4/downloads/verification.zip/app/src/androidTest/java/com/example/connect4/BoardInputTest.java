package com.example.connect4;

import static org.junit.Assert.assertEquals;

import android.view.MotionEvent;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.connect4.core.GameEngine;
import com.example.connect4.ui.BoardView;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class BoardInputTest {
    @Test public void tapsUseDrawnBoardBoundsWhenTheViewHasExtraSpace() {
        InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> {
            BoardView board = new BoardView(
                    InstrumentationRegistry.getInstrumentation().getTargetContext(), null);
            board.layout(0, 0, 700, 300); // Drawn cells are 50px; board width is 350px.
            board.show(new GameEngine().snapshot(), true);
            AtomicInteger selected = new AtomicInteger(-1);
            board.setColumnListener(selected::set);

            tap(board, 349, 150);
            assertEquals(6, selected.get());
            for (float[] outside : new float[][]{{350, 150}, {699, 150}, {-1, 150}, {25, -1}, {25, 300}}) {
                selected.set(-1);
                tap(board, outside[0], outside[1]);
                assertEquals(-1, selected.get());
            }
            board.show(new GameEngine().snapshot(), false);
            tap(board, 25, 150);
            assertEquals(-1, selected.get());
        });
    }

    private static void tap(BoardView board, float x, float y) {
        MotionEvent event = MotionEvent.obtain(0, 0, MotionEvent.ACTION_UP, x, y, 0);
        try {
            board.onTouchEvent(event);
        } finally {
            event.recycle();
        }
    }
}
