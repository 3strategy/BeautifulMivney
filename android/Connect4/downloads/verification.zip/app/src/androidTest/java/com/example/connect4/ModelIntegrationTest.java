package com.example.connect4;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.connect4.core.PolicyValueEvaluator;
import com.example.connect4.ai.ModelCatalog;
import com.example.connect4.ai.TfliteEvaluator;
import com.example.connect4.core.GameAction;
import com.example.connect4.core.GameEngine;
import com.example.connect4.core.MctsPlayer;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real packaged model/native runtime smoke check, independent of model strength. */
@RunWith(AndroidJUnit4.class)
public class ModelIntegrationTest {
    @Test public void packagedModelEvaluatesAndSearchesLegalMoves() throws Exception {
        verifyPackagedModel(catalog().require("main"), false);
    }

    @Test public void packagedEarlyModelEvaluatesAndSearchesLegalMoves() throws Exception {
        verifyPackagedModel(catalog().require("early-a100"), true);
    }

    @Test public void packagedUntrainedBaselineEvaluatesAndSearchesLegalMoves() throws Exception {
        ModelCatalog.Entry entry = catalog().require("untrained-baseline");
        try (TfliteEvaluator evaluator = new TfliteEvaluator(
                InstrumentationRegistry.getInstrumentation().getTargetContext(), entry.assets())) {
            assertEquals("mock", evaluator.modelKind());
            assertTrue(evaluator.modelDescription().contains("Mock / untrained"));
            PolicyValueEvaluator.Evaluation result = evaluator.evaluate(new GameEngine().snapshot());
            assertEquals(7, result.policyLogits().length);
            assertTrue(Float.isFinite(result.value()));
        }
    }

    private static void verifyPackagedModel(
            ModelCatalog.Entry entry, boolean early) throws Exception {
        try (TfliteEvaluator evaluator = new TfliteEvaluator(
                InstrumentationRegistry.getInstrumentation().getTargetContext(), entry.assets())) {
            assertTrue(evaluator.modelKind().equals("mock") || evaluator.modelKind().equals("trained"));
            if (early) {
                assertEquals("trained", evaluator.modelKind());
                assertTrue(evaluator.displayName().toLowerCase(java.util.Locale.ROOT).contains("early"));
                assertFalse(evaluator.trainingSummary().isEmpty());
            }
            assertFalse(evaluator.modelDescription().contains("simulations"));
            GameEngine engine = new GameEngine();
            for (int turn = 0; turn < 12 && !engine.snapshot().isTerminal(); turn++) {
                PolicyValueEvaluator.Evaluation result = evaluator.evaluate(engine.snapshot());
                assertEquals(7, result.policyLogits().length);
                assertTrue(Float.isFinite(result.value()));
                GameAction move = new MctsPlayer(evaluator, 32).chooseAction(engine.snapshot());
                assertTrue(engine.apply(move));
            }
        }
    }

    private static ModelCatalog catalog() throws Exception {
        return ModelCatalog.load(InstrumentationRegistry.getInstrumentation()
                .getTargetContext().getAssets());
    }
}
