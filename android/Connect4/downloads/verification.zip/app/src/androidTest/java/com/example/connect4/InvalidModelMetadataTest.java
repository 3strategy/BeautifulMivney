package com.example.connect4;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.connect4.ai.TfliteEvaluator;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Uses test-APK assets to prove incompatible metadata is rejected before inference. */
@RunWith(AndroidJUnit4.class)
public class InvalidModelMetadataTest {
    @Test
    public void assetPairRejectsPathsAndWrongExtensions() {
        assertThrows(IllegalArgumentException.class,
                () -> new TfliteEvaluator.AssetPair("../model.tflite", "model.json", null));
        assertThrows(IllegalArgumentException.class,
                () -> new TfliteEvaluator.AssetPair("model.bin", "model.json", null));
        assertThrows(IllegalArgumentException.class,
                () -> new TfliteEvaluator.AssetPair("model.tflite", "folder/model.json", null));
    }

    @Test
    public void wrongGameMetadataIsRejected() {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        AssetManager invalidAssets = InstrumentationRegistry.getInstrumentation()
                .getContext().getAssets();
        Context invalidModelContext = new ContextWrapper(target) {
            @Override
            public AssetManager getAssets() {
                return invalidAssets;
            }
        };

        IllegalArgumentException failure = assertThrows(
                IllegalArgumentException.class,
                () -> new TfliteEvaluator(invalidModelContext));
        assertEquals("Wrong game", failure.getMessage());
    }
}
