package com.example.connect4;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import android.os.Looper;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.connect4.ai.ComputerMoveService;
import com.example.connect4.core.GameEngine;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Exercises real worker/main-thread delivery, including workers that ignore cancellation. */
@RunWith(AndroidJUnit4.class)
public class ComputerMoveLifecycleTest {
    @Test public void cancelledResultCannotReachTheNextTurn() throws Exception {
        verifyCancelledCompletion(false);
    }

    @Test public void cancelledFailureCannotFailTheNextTurn() throws Exception {
        verifyCancelledCompletion(true);
    }

    @Test public void activeFailureClearsBusyStateAndCanBeReset() throws Exception {
        GameSession session = new GameSession();
        CountDownLatch failureDelivered = new CountDownLatch(1);
        AtomicBoolean moveDelivered = new AtomicBoolean();
        try {
            onMain(() -> session.requestComputerMove(() -> {
                throw new IllegalStateException("Test calculation failed");
            }, result -> moveDelivered.set(true), failure -> failureDelivered.countDown()));
            assertTrue(failureDelivered.await(5, TimeUnit.SECONDS));
            assertFalse(moveDelivered.get());
            onMain(() -> {
                assertFalse(session.isComputerThinking());
                assertTrue(session.hasComputerMoveFailed());
                session.cancelComputerMove();
                assertFalse(session.hasComputerMoveFailed());
            });
        } finally {
            onMain(session::onCleared);
        }
    }

    private void verifyCancelledCompletion(boolean failOldRequest) throws Exception {
        GameSession session = new GameSession();
        CountDownLatch oldStarted = new CountDownLatch(1);
        CountDownLatch releaseOld = new CountDownLatch(1);
        CountDownLatch currentDelivered = new CountDownLatch(1);
        AtomicBoolean oldDelivered = new AtomicBoolean();
        AtomicBoolean newFailed = new AtomicBoolean();
        AtomicBoolean calculationOffMain = new AtomicBoolean();
        AtomicBoolean deliveryOnMain = new AtomicBoolean();
        try {
            onMain(() -> session.requestComputerMove(() -> {
                oldStarted.countDown();
                // Simulate native inference that finishes despite Future.cancel(true).
                boolean released = false;
                while (!released) {
                    try {
                        released = releaseOld.await(5, TimeUnit.SECONDS);
                        if (!released) throw new IllegalStateException("Test worker timed out");
                    } catch (InterruptedException ignored) {
                        // Deliberately continue, so the request ID must reject this completion.
                    }
                }
                if (failOldRequest) throw new IllegalStateException("Obsolete model failed");
                return ComputerMoveService.chooseHeuristicMove(new GameEngine().snapshot());
            }, result -> oldDelivered.set(true), failure -> oldDelivered.set(true)));
            assertTrue(oldStarted.await(5, TimeUnit.SECONDS));
            onMain(() -> {
                session.cancelComputerMove();
                session.requestComputerMove(() -> {
                    calculationOffMain.set(Looper.myLooper() != Looper.getMainLooper());
                    return ComputerMoveService.chooseHeuristicMove(new GameEngine().snapshot());
                }, result -> {
                    deliveryOnMain.set(Looper.myLooper() == Looper.getMainLooper());
                    currentDelivered.countDown();
                }, failure -> {
                    newFailed.set(true);
                    currentDelivered.countDown();
                });
            });
            releaseOld.countDown();
            assertTrue(currentDelivered.await(5, TimeUnit.SECONDS));
            assertFalse(oldDelivered.get());
            assertFalse(newFailed.get());
            assertTrue(calculationOffMain.get());
            assertTrue(deliveryOnMain.get());
            onMain(() -> {
                assertFalse(session.isComputerThinking());
                assertFalse(session.hasComputerMoveFailed());
            });
        } finally {
            releaseOld.countDown();
            onMain(session::onCleared);
        }
    }

    private static void onMain(Runnable action) {
        InstrumentationRegistry.getInstrumentation().runOnMainSync(action);
    }
}
