const fs = require('node:fs');
const path = require('node:path');

const [, , inputPath, outputPath] = process.argv;
if (!inputPath || !outputPath) {
  console.error('Usage: node merge-rules.cjs <exported-live-rules.json> <merged-output.json>');
  process.exit(2);
}

const current = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
const fragment = JSON.parse(fs.readFileSync(
  path.join(__dirname, 'connect4.rules.fragment.json'), 'utf8'));
if (!current.rules || typeof current.rules !== 'object' || Array.isArray(current.rules)) {
  throw new Error('Input must be a Firebase rules export with a top-level "rules" object.');
}
if (Object.prototype.hasOwnProperty.call(current.rules, 'Connect4Rtdb')) {
  throw new Error('Input already contains Connect4Rtdb; review it manually instead of overwriting it.');
}

current.rules.Connect4Rtdb = fragment.Connect4Rtdb;
fs.writeFileSync(outputPath, `${JSON.stringify(current, null, 2)}\n`, 'utf8');
console.log(`Wrote reviewed merge candidate to ${outputPath}`);
