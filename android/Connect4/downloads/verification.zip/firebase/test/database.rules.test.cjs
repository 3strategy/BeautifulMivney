const { after, afterEach, before, describe, test } = require('node:test');
const assert = require('node:assert/strict');
const {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
} = require('@firebase/rules-unit-testing');
const {
  get,
  ref,
  runTransaction,
  serverTimestamp,
  set,
  update,
} = require('firebase/database');
const fs = require('node:fs');
const path = require('node:path');

const PROJECT_ID = 'demo-connect4';
const ROOT = 'Connect4Rtdb/games';
const rulesFile = process.env.CONNECT4_RULES_FILE ||
  path.join(__dirname, '..', 'emulator.rules.json');
let environment;

function db(uid) {
  return uid
    ? environment.authenticatedContext(uid).database()
    : environment.unauthenticatedContext().database();
}

function room(overrides = {}) {
  return {
    schemaVersion: 1,
    name: 'Class game',
    playerRed: 'red-user',
    playerYellow: '',
    moves: '',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    ...overrides,
  };
}

async function seed(roomId, data) {
  await environment.withSecurityRulesDisabled(async context => {
    await set(ref(context.database(), `${ROOT}/${roomId}`), data);
  });
}

describe('Connect4 RTDB rules', () => {
  before(async () => {
    environment = await initializeTestEnvironment({
      projectId: PROJECT_ID,
      database: {
        rules: fs.readFileSync(rulesFile, 'utf8'),
      },
    });
  });

  afterEach(async () => environment.clearDatabase());
  after(async () => environment.cleanup());

  test('requires authentication to read or create rooms', async () => {
    await assertFails(get(ref(db(), ROOT)));
    await assertFails(set(ref(db(), `${ROOT}/room-a`), room()));
    await assertSucceeds(get(ref(db('viewer'), ROOT)));
  });

  test('keeps the existing shared-instance wildcard from opening Connect4', async () => {
    await seed('room-a', {
      schemaVersion: 1,
      name: 'Existing',
      playerRed: 'red-user',
      playerYellow: '',
      moves: '',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
    await assertFails(get(ref(db(), `${ROOT}/room-a`)));
    await assertFails(set(ref(db(), `${ROOT}/room-a`), null));
    await assertSucceeds(set(ref(db(), 'TicTacToeRtdb/lesson-room'), { untouched: true }));
    assert.deepEqual((await get(ref(db(), 'TicTacToeRtdb/lesson-room'))).val(),
      { untouched: true });
  });

  test('preserves representative existing Users and per-user wildcard access', async () => {
    await assertSucceeds(set(ref(db('owner'), 'Users/owner/profile'), { name: 'Owner' }));
    await assertFails(set(ref(db('other'), 'Users/owner/profile'), { name: 'Other' }));
    await assertSucceeds(set(ref(db('owner'), 'lesson*owner/value'), 1));
    await assertFails(set(ref(db('other'), 'lesson*owner/value'), 2));
  });

  test('binds a valid creation to Red and rejects malformed creation', async () => {
    await assertSucceeds(set(ref(db('red-user'), `${ROOT}/room-a`), room()));
    await assertFails(set(ref(db('other-user'), `${ROOT}/room-b`), room()));
    await assertFails(set(ref(db('red-user'), `${ROOT}/room-c`),
      room({ name: ' '.repeat(2), extra: true })));
  });

  test('only one different user can claim Yellow in a concurrent race', async () => {
    await assertSucceeds(set(ref(db('red-user'), `${ROOT}/room-a`), room()));
    const claim = async uid => {
      const roomRef = ref(db(uid), `${ROOT}/room-a`);
      const baseline = (await get(roomRef)).val();
      return runTransaction(roomRef, current => {
      current ??= structuredClone(baseline);
      if (current && current.playerYellow === '') {
        current.playerYellow = uid;
        current.updatedAt = serverTimestamp();
        return current;
      }
      return undefined;
      });
    };

    const results = await Promise.allSettled([claim('yellow-a'), claim('yellow-b')]);
    const committed = results.filter(result =>
      result.status === 'fulfilled' && result.value.committed).length;
    assert.equal(committed, 1);
    const stored = (await get(ref(db('viewer'), `${ROOT}/room-a`))).val();
    assert.ok(stored.playerYellow === 'yellow-a' || stored.playerYellow === 'yellow-b');
    assert.notEqual(stored.playerYellow, stored.playerRed);
  });

  test('allows only the seated player on the matching turn to append one column', async () => {
    const now = Date.now();
    await seed('room-a', room({
      playerYellow: 'yellow-user',
      createdAt: now,
      updatedAt: now,
    }));

    await assertFails(update(ref(db('yellow-user'), `${ROOT}/room-a`),
      { moves: '3', updatedAt: serverTimestamp() }));
    await assertFails(update(ref(db('spectator'), `${ROOT}/room-a`),
      { moves: '3', updatedAt: serverTimestamp() }));
    await assertSucceeds(update(ref(db('red-user'), `${ROOT}/room-a`),
      { moves: '3', updatedAt: serverTimestamp() }));
    await assertFails(update(ref(db('red-user'), `${ROOT}/room-a`),
      { moves: '34', updatedAt: serverTimestamp() }));
    await assertSucceeds(update(ref(db('yellow-user'), `${ROOT}/room-a`),
      { moves: '34', updatedAt: serverTimestamp() }));
  });

  test('rejects stale overwrites, resets, deletion and immutable-field changes', async () => {
    const now = Date.now();
    await seed('room-a', room({
      playerYellow: 'yellow-user',
      moves: '3',
      createdAt: now,
      updatedAt: now,
    }));

    await assertFails(update(ref(db('yellow-user'), `${ROOT}/room-a`),
      { moves: '2', updatedAt: serverTimestamp() }));
    await assertFails(update(ref(db('yellow-user'), `${ROOT}/room-a`),
      { name: 'Renamed', moves: '32', updatedAt: serverTimestamp() }));
    await assertFails(set(ref(db('red-user'), `${ROOT}/room-a`), null));
    await assertFails(update(ref(db('yellow-user'), `${ROOT}/room-a`),
      { moves: '', updatedAt: serverTimestamp() }));
  });

  test('two sessions for one UID cannot commit from the same move prefix', async () => {
    const now = Date.now();
    await seed('room-a', room({
      playerYellow: 'yellow-user',
      createdAt: now,
      updatedAt: now,
    }));
    const move = async column => {
      const roomRef = ref(db('red-user'), `${ROOT}/room-a`);
      const baseline = (await get(roomRef)).val();
      return runTransaction(roomRef, current => {
        current ??= structuredClone(baseline);
        if (current.moves !== '') return undefined;
        current.moves = String(column);
        current.updatedAt = serverTimestamp();
        return current;
      });
    };

    const results = await Promise.allSettled([move(2), move(4)]);
    const committed = results.filter(result =>
      result.status === 'fulfilled' && result.value.committed).length;
    assert.equal(committed, 1);
    assert.match((await get(ref(db('viewer'), `${ROOT}/room-a/moves`))).val(), /^[24]$/);
  });
});
