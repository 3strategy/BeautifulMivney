from course import *
from concurrent.futures import ThreadPoolExecutor
import time
ADB=r'C:\Users\3stra\AppData\Local\Android\Sdk\platform-tools\adb.exe'
def adb(serial,*args):
    return subprocess.run([ADB,'-s',serial,*args],capture_output=True,text=True,timeout=120,check=True).stdout
run='Course-'+str(int(time.time()))
devices=[('emulator-5554','red'),('emulator-5556','yellow')]
def prepare(pair):
    serial,role=pair
    for port in ['9000','9099']: adb(serial,'reverse','tcp:'+port,'tcp:'+port)
    adb(serial,'install','-r',str(ROOT/'app/build/outputs/apk/debug/app-debug.apk'))
    adb(serial,'install','-r',str(ROOT/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'))
with ThreadPoolExecutor(max_workers=2) as pool: list(pool.map(prepare,devices))
processes=[]
for serial,role in devices:
    log=(WORK/f'cross-device-{role}.log').open('w',encoding='utf-8')
    p=subprocess.Popen([ADB,'-s',serial,'shell','am','instrument','-w','-r','-e','class','com.example.connect4.CourseCrossDeviceTest','-e','crossDevice','true','-e','role',role,'-e','runId',run,'com.example.connect4.test/androidx.test.runner.AndroidJUnitRunner'],stdout=log,stderr=subprocess.STDOUT)
    processes.append((p,log,role))
for p,log,role in processes:
    try: p.wait(timeout=100)
    except subprocess.TimeoutExpired: p.kill();p.wait()
    log.close()
    result=(WORK/f'cross-device-{role}.log').read_text(encoding='utf-8')
    print(role,result[-4000:])
if not all('OK (1 test)' in (WORK/f'cross-device-{role}.log').read_text(encoding='utf-8') for _,role in devices):
    raise SystemExit('Cross-device check failed; inspect role logs')
print('Two-device UI game and third-client spectator passed:',run)
