package com.example.connect4.multiplayer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.junit.After;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

@RunWith(AndroidJUnit4.class)
public class MultiplayerRepositoryEmulatorTest {
    private static final String HOST = "10.0.2.2";
    private static final String PASSWORD = "connect4-test-password";
    private static final String DEMO_DATABASE_URL =
            "https://demo-connect4-default-rtdb.firebaseio.com";
    private final List<FirebaseApp> testApps = new ArrayList<>();

    private Client red;
    private Client yellowCandidate;
    private Client spectatorCandidate;
    private Client secondRedSession;

    @Before
    public void setUp() throws Exception {
        Assume.assumeTrue("opt-in Firebase emulator test",
                Boolean.parseBoolean(InstrumentationRegistry.getArguments().getString("firebaseEmulators", "false")));
        String run = UUID.randomUUID().toString();
        red = client("red-" + run, "red-" + run + "@example.test");
        yellowCandidate = client("yellow-" + run, "yellow-" + run + "@example.test");
        spectatorCandidate = client("spectator-" + run,
                "spectator-" + run + "@example.test");
        secondRedSession = client("red2-" + run, red.email);

        MultiplayerRepositoryEmulatorTest.<String>await(
                callback -> red.repository.createAccount(red.email, PASSWORD, callback));
        MultiplayerRepositoryEmulatorTest.<String>await(callback -> yellowCandidate.repository.createAccount(
                yellowCandidate.email, PASSWORD, callback));
        MultiplayerRepositoryEmulatorTest.<String>await(callback -> spectatorCandidate.repository.createAccount(
                spectatorCandidate.email, PASSWORD, callback));
        MultiplayerRepositoryEmulatorTest.<String>await(
                callback -> secondRedSession.repository.signIn(red.email, PASSWORD, callback));
    }

    @After
    public void tearDown() {
        for (FirebaseApp app : testApps) {
            app.delete();
        }
        testApps.clear();
    }

    @Test
    public void concurrentJoinKeepsOneYellowAndOneSpectator() throws Exception {
        String roomId = await(callback -> red.repository.createRoom(
                "Repository emulator test", callback));
        RoomSnapshot waiting = await(callback -> red.repository.getRoom(roomId, callback));
        assertEquals(RoomStatus.WAITING, waiting.getStatus());
        assertEquals(RoomRole.RED, waiting.getRole());

        AsyncResult<RoomRole> firstClaim = begin(callback ->
                yellowCandidate.repository.joinRoom(roomId, callback));
        AsyncResult<RoomRole> secondClaim = begin(callback ->
                spectatorCandidate.repository.joinRoom(roomId, callback));
        RoomRole firstRole = firstClaim.await();
        RoomRole secondRole = secondClaim.await();
        assertTrue((firstRole == RoomRole.YELLOW && secondRole == RoomRole.SPECTATOR)
                || (firstRole == RoomRole.SPECTATOR && secondRole == RoomRole.YELLOW));

        Client yellow = firstRole == RoomRole.YELLOW ? yellowCandidate : spectatorCandidate;
        Client spectator = firstRole == RoomRole.SPECTATOR
                ? yellowCandidate : spectatorCandidate;
        assertEquals(RoomRole.RED,
                MultiplayerRepositoryEmulatorTest.<RoomRole>await(
                        callback -> red.repository.joinRoom(roomId, callback)));
        assertEquals(RoomRole.YELLOW,
                MultiplayerRepositoryEmulatorTest.<RoomRole>await(
                        callback -> yellow.repository.joinRoom(roomId, callback)));
        assertEquals(RoomRole.SPECTATOR,
                MultiplayerRepositoryEmulatorTest.<RoomRole>await(
                        callback -> spectator.repository.joinRoom(roomId, callback)));

        assertEquals(RoomStatus.PLAYING, MultiplayerRepositoryEmulatorTest.<RoomSnapshot>await(
                callback -> spectator.repository.getRoom(roomId,callback)).getStatus());
    }

    private Client client(String appName, String email) {
        Context context = ApplicationProvider.getApplicationContext();
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey("fake-api-key")
                .setApplicationId("1:1234567890:android:connect4test")
                .setProjectId("demo-connect4")
                .setDatabaseUrl(DEMO_DATABASE_URL)
                .build();
        FirebaseApp app = FirebaseApp.initializeApp(
                context, options, "connect4-test-" + appName);
        testApps.add(app);
        FirebaseAuth auth = FirebaseAuth.getInstance(app);
        FirebaseDatabase database = FirebaseDatabase.getInstance(app, DEMO_DATABASE_URL);
        auth.useEmulator(HOST, 9099);
        database.useEmulator(HOST, 9000);
        return new Client(email, new MultiplayerRepository(auth, database));
    }

    private static <T> T await(Consumer<MultiplayerRepository.ResultCallback<T>> operation)
            throws Exception {
        return begin(operation).await();
    }

    private static <T> AsyncResult<T> begin(
            Consumer<MultiplayerRepository.ResultCallback<T>> operation) {
        AsyncResult<T> result = new AsyncResult<>();
        operation.accept(result.callback);
        return result;
    }

    private static final class Client {
        private final String email;
        private final MultiplayerRepository repository;

        private Client(String email, MultiplayerRepository repository) {
            this.email = email;
            this.repository = repository;
        }
    }

    private static final class AsyncResult<T> {
        private final CountDownLatch latch = new CountDownLatch(1);
        private final AtomicReference<T> value = new AtomicReference<>();
        private final AtomicReference<RepositoryError> error = new AtomicReference<>();
        private final MultiplayerRepository.ResultCallback<T> callback =
                new MultiplayerRepository.ResultCallback<T>() {
                    @Override
                    public void onSuccess(T result) {
                        value.set(result);
                        latch.countDown();
                    }

                    @Override
                    public void onError(RepositoryError failure) {
                        error.set(failure);
                        latch.countDown();
                    }
                };

        private T await() throws Exception {
            assertTrue("Firebase callback timed out", latch.await(15, TimeUnit.SECONDS));
            assertEquals(error.get() == null ? null : error.get().getMessage(), null, error.get());
            assertNotNull(value.get());
            return value.get();
        }

        private int successCount() throws Exception {
            assertTrue("Firebase callback timed out", latch.await(15, TimeUnit.SECONDS));
            return error.get() == null && value.get() != null ? 1 : 0;
        }
    }
}
